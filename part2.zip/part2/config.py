# Lattice Configurations #

# Cache directory location for Lattice.
lattice_cache_path = "cache/lattice"

# The input directory where input files can be found.
lattice_inputs_path = "inputs/lattice"

# Output path for Lattice.
lattice_outputs_path = "outputs/lattice"

# The directory which contains the Lattice program.
lattice_path = "bin"

# The executable file's name.
lattice_executable = "Bamboo-Lattice"

# Output files to be renamed and saved.
lattice_results = ["Bamboo-Lattice.cax", "Bamboo-Lattice.form",
                   "Bamboo-Lattice.kine", "Bamboo-Lattice.out"]


# ReadBLattice Configurations #

# Define file types need to be concatenated.
# Note: Files types mentioned in this variable must be contained in the
# lattice_results global variable.
files_to_cat = ["cax", "form", "kine"]

# The directory which contains `readb_executable'.
readb_path = "bin"

# The executable file's name.
readb_executable = "ReadBLattice"

# Cache directory location for ReadBLattice.
readb_cache_path = "cache/readb"

# The input file's location.
readb_input = "inputs/readb/inp.dat"

# Location where results are saved.
readb_outputs_path = "outputs/readb"


# Core Configurations #

# Cache directory location for Bamboo-Core.
core_cache_path = "cache/core"

# The input directory where input files can be found.
core_inputs_path = "inputs/core"

# The CR files name.(Case sensitive)
core_cr_inputs = ["CR_KIN", "CR_FORM", "CR_XS"]

# According to the manual, "BUCI.DAT" is an optional input file.
core_optional_inputs = ["BUCI.DAT"]

# The directory which contains `core_executable'.
core_path = "bin"

# The executable file's name.
core_executable = "Bamboo-Core"

# Location where results are saved.
core_outputs_path = "outputs/core"

# Output files or directories to be saved.(Case sensitive)
# Note: LILAC directory will be saved automatically, so you don't need
# put "LILAC" in this variable.
core_outputs = ["OUTPUT.DAT", "BORON.DAT", "BUCO.DAT", "VisIt", "KININFO",
                "VIOLET"]

# According to the manual, files listed here are optional output files.
core_optional_outputs = ["PRPOWER.DAT", "PRFLUX.DAT", "DETFILE.DAT", "RECOE.DAT",
                         "FLAB.DAT", "CPARA.DAT", "PPARA.DAT", "main.bt"]


# Transient Configurations #

# Cache directory for Bamboo-Transient.
trans_cache_path = "cache/transient"

# The input directory where input files can be found.
trans_inputs_path = "inputs/transient"

# Input files supposed to be placed in `trans_inputs_path'.
trans_inputs = {"dirs": [], "files": ["transient.xml"]}

# The directory which contains `trans_executable'.
trans_path = "bin"

# The executable file's name.
trans_executable = "Bamboo-Transient"

# Location where results are saved.
trans_outputs_path = "outputs/transient"

# Output files or directory to be saved.(Case sensitive)
trans_outputs = {"files": ["OUTPUT.LOG", "OUTPUT.TIMELIST", "OUTPUT.POWER"]}
