#!/bin/sh

pyexe=python
if which python3 >/dev/null 2>&1; then
    pyexe=python3
fi

update_lilac=true
if [ -n "$1" ]; then
    if $update_lilac; then
        $pyexe bamboo lattice  -j $1 && \
        $pyexe bamboo readb && \
        $pyexe bamboo core 1 --update
    else
        $pyexe bamboo core 1
    fi
else
    if $update_lilac; then
        $pyexe bamboo lattice  && \
        $pyexe bamboo readb && \
        $pyexe bamboo core 1 --update
    else
        $pyexe bamboo core 1
    fi
fi
