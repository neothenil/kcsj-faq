import math

from . import const


def simple_mesh(pin, mesh_num_max, mesh_num_min):
    pin_radii = [i for i in pin.radii]
    pin_mats = [i for i in pin.mats]
    if pin.boundaries:
        R = max(pin.boundaries)
        boundary_index = pin.radii.index(R)
        tail_radii = pin_radii[boundary_index+1:]
        tail_mats = pin_mats[boundary_index+1:]
        head_radii = pin_radii[:boundary_index+1]
        head_mats = pin_mats[:boundary_index+1]
        added_radii = [round((i/mesh_num_max)**0.5*R, const.precision)
                for i in range(1, mesh_num_max)]
        new_head_radii = sorted(set(head_radii + added_radii))
        new_head_mats = []
        for radius in new_head_radii:
            for index, old_radius in enumerate(head_radii):
                if old_radius >= radius:
                    new_head_mats.append(head_mats[index])
                    break
        return new_head_radii + tail_radii, new_head_mats + tail_mats
    else:
        R = pin_radii.pop(0)
        mat = pin_mats.pop(0)
        prepended_radii = [round((i/mesh_num_min)**0.5*R, const.precision)
                for i in range(1, mesh_num_min+1)]
        prepended_mats = [mat] * mesh_num_min
        return prepended_radii + pin_radii, prepended_mats + pin_mats


def simple_mesh_box(box):
    dimensions = box.dimensions.copy()
    max_dimension = max(dimensions)
    mats = box.mats.copy()
    added_dimensions = [round(i/const.box_mesh_num*max_dimension,
        const.precision) for i in range(1, const.box_mesh_num)]
    new_dimensions = sorted(set(dimensions + added_dimensions))
    new_mats = []
    for dim in new_dimensions:
        for index, old_dim in enumerate(dimensions):
            if old_dim >= dim:
                new_mats.append(mats[index])
                break
    return new_dimensions, new_mats


def mesh_from_list(fixed_points, base_length):
    result = []
    prev_point = 0.0
    for i in range(len(fixed_points)):
        num_segment = math.ceil((fixed_points[i] - prev_point) / base_length)
        segment_length = round((fixed_points[i]-prev_point)/num_segment,
                const.precision)
        for j in range(1, num_segment+1):
            point = round(prev_point + j * segment_length,
                    const.precision)
            result.append(point)
        prev_point = fixed_points[i]
    return result
