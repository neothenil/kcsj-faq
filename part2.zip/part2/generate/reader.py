import os
import xml.etree.ElementTree as ET

from . import const
from .component import Lattice, Pin, Segment, Material, AxialRef, RadialRef
from .errors import InputFileError, ModFileError, SettingsError


def row_text(string):
    """Parse a string as row text. Return a list of strings."""
    return string.split()


def matrix_text(string):
    """Parse a string as matrix text. Return a list of list of stings."""
    matrix = string.split('\n')
    matrix = [i.split() for i in matrix]
    matrix = [i for i in matrix if i]
    return matrix


def matrix_shape(matrix):
    len_x = len(matrix)
    if len_x == 0:
        raise AttributeError('Argument must be a 2D list')
    len_y = len(matrix[0])
    for inner_list in matrix:
        if len(inner_list) != len_y:
            raise AttributeError('Length of inner list not a const')
    return len_x, len_y


class ElementType:
    """
    `ElementType` is an abstract class for all of the particular element types.
    When it comes to "element type", it means an element with geometry and
    material specification, obtained from a file in the `mods` directory. An
    element can be one of a fuel, a fixed absorber, a plug, a detector, a
    control rod, an axial reflector or a radial reflector.
    """
    def __init__(self, text, name):
        self.root = ET.fromstring(text)
        self.name = name
        self.parse()

    @classmethod
    def fromfile(cls, filepath):
        with open(filepath) as f:
            text = f.read()
        filename = os.path.basename(filepath)
        name = '.'.join(filename.split('.')[:-1])
        return cls(text, name)

    def __eq__(self, other):
        if not isinstance(other, ElementType):
            return False
        return self.type == other.type and self.name == other.name

    def parse(self):
        pass


class SetAttrMixin:
    """
    Bundle of set_* methods and find_* methods for concrete `ElementType`.
    """
    def set_materials(self):
        material_tags = self.root.findall('material')
        self.materials = []
        for material_tag in material_tags:
            matid = material_tag.get('id')
            nu_density = {}
            for nuclide in material_tag.findall('nuclide'):
                alias = nuclide.get('alias')
                if alias in nu_density:
                    raise ModFileError('Conflicted nuclide: {}'.format(alias))
                nu_density[nuclide.get('alias')] = \
                    float(nuclide.get('density'))
            self.materials.append(Material(matid, nu_density))

    def set_pins(self):
        pin_tags = self.root.findall('pin')
        self.pins = []
        for pin_tag in pin_tags:
            pin_id = int(pin_tag.get('id'))
            radii = pin_tag.find('radius').text
            radii = row_text(radii)
            radii = list(map(float, radii))
            matid = pin_tag.find('matid').text
            matid = row_text(matid)
            mats = [self.find_material(i) for i in matid]
            pin_type = pin_tag.get('type')
            self.pins.append(Pin(pin_id, radii, mats, pin_type))

    def set_lattices(self):
        lattice_tags = self.root.findall('lattice')
        self.lattices = []
        for lattice_tag in lattice_tags:
            lattice_id = lattice_tag.get('id')
            pin_size = float(lattice_tag.get('pin_size'))
            pin_id_layout = matrix_text(lattice_tag.text)
            layout = []
            for line in pin_id_layout:
                pin_line = []
                for pin_id in line:
                    pin_line.append(self.find_pin(pin_id))
                layout.append(pin_line)
            self.lattices.append(Lattice(lattice_id, pin_size, layout))

    def set_segments(self):
        segment_tags = self.root.findall('segment')
        self.segments = []
        for segment_tag in segment_tags:
            height = round(float(segment_tag.get('height')), const.precision)
            lattice_id = segment_tag.get('lattice')
            self.segments.append(
                Segment(height, self.find_lattice(lattice_id)))

    def set_total_height(self):
        total_height = 0.0
        for segment in self.segments:
            total_height += segment.height
        self.total_height = round(total_height, const.precision)

    # def set_spacers(self):
    #     spacer_tags = self.root.findall('spacer')
    #     self.spacers = []
    #     for spacer_tag in spacer_tags:
    #         spacer_id = spacer_tag.get('id')
    #         volumne = float(spacer_tag.get('volume'))
    #         height = float(spacer_tag.get('height'))
    #         material = self.find_material(spacer_tag.get('matid'))
    #         self.spacers.append(Spacer(spacer_id, volumne, height, material))

    # def set_spacer_layout(self):
    #     spacer_layout_tag = self.root.find('spacer_layout')
    #     locations = []
    #     spacers = []
    #     for location in spacer_layout_tag.find('location').text.split():
    #         locations.append(float(location))
    #     for spacer in spacer_layout_tag.find('spacerid').text.split():
    #         spacers.append(self.find_spacer(spacer))
    #     self.spacer_layout = SpacerLayout(locations, spacers)

    def set_axialrefs(self):
        ref_top = self.root.find('ref_top')
        if ref_top is None:
            ref1 = None
        else:
            heights = []
            mats = []
            for height in ref_top.find('height').text.split():
                heights.append(round(float(height), const.precision))
            for matid in ref_top.find('matid').text.split():
                mat = self.find_material(matid)
                mats.append(mat)
            if len(heights) != len(mats):
                raise ModFileError("height num does not match matid num in "
                        "{}".format(self.name))
            ref1 = AxialRef(heights, mats, "top")
        ref_bottom = self.root.find('ref_bottom')
        if ref_bottom is None:
            ref2 = None
        else:
            heights = []
            mats = []
            for height in ref_bottom.find('height').text.split():
                heights.append(round(float(height), const.precision))
            for matid in ref_bottom.find('matid').text.split():
                mat = self.find_material(matid)
                mats.append(mat)
            if len(heights) != len(mats):
                raise ModFileError("height num does not match matid num in "
                        "{}".format(self.name))
            ref2 = AxialRef(heights, mats, "bottom")
        self.ref_top = ref1
        self.ref_bottom = ref2

    def set_radial_ref(self):
        baffle = self.root.find('baffle')
        baffle_width = round(float(baffle.attrib['width']),
                const.precision)
        baffle_mat = baffle.attrib['matid']
        baffle_mat = self.find_material(baffle_mat)
        gap_attr = baffle.get('gap')
        if gap_attr:
            gap_width = round(float(gap_attr), const.precision)
            baffle_height = gap_width + baffle_width
            heights = [gap_width, baffle_height]
            mats = [None, baffle_mat]
        else:
            heights = [baffle_height]
            mats = [baffle_mat]
        self.radial_ref = RadialRef(heights, mats)

    def find_material(self, matid):
        if matid == 'None':
            return None
        for mat in self.materials:
            if mat.id == matid:
                return mat
        # Add another for block to search in registered materials.
        raise ModFileError('Unrecognizable material: {} in {}'.format(
            matid, self.name))

    def find_pin(self, pin_id):
        if const.placeholder.match(pin_id):
            return None
        pin_id = int(pin_id)
        for pin in self.pins:
            if pin.id == pin_id:
                return pin
        raise ModFileError('Unrecognizable pin: {} in {}'.format(
            pin_id, self.name))

    def find_lattice(self, lattice_id):
        for lattice in self.lattices:
            if lattice.id == lattice_id:
                return lattice
        raise ModFileError('Unrecognizable lattice: {} in {}'.format(
            lattice_id, self.name))

    # def find_spacer(self, spacer_id):
    #     for spacer in self.spacers:
    #         if spacer.id == spacer_id:
    #             return spacer
    #     raise ModFileError('Unrecognizable spacer: {}'.format(spacer_id))


class FuelElementType(ElementType, SetAttrMixin):
    """
    `FuelElementType` is a concrete `ElementType` for fuel. It reads files in
    `mods/fuel` directory.

    Attributes:
    - type: 'fuel'
    - lattices: All found lattices.
    - segments: Specify axial segments of the core. (from top to bottom)
    - pins: All found pins.
    - materials: All found materials.
    - total_height: Sum of height of each segment.
    """
    def parse(self):
        self.type = 'fuel'
        self.set_materials()
        self.set_pins()
        self.set_lattices()
        self.set_segments()
        self.set_total_height()
        for lattice in self.lattices:
            lattice.members[const.FU] = lattice.id


class AbsorberElementType(ElementType, SetAttrMixin):
    """
    `AbsorberElementType` is a concrete `ElementType` for absorber. It reads
    files in `mods/fixed_absorber` directory.

    Attributes:
    - type: 'fixed_absorber'
    - lattices: All found lattices.
    - segments: Specify axial segments of the core. (from top to bottom)
    - pins: All found pins.
    - materials: All found materials.
    - total_height: Sum of height of each segment.
    """
    def parse(self):
        self.type = 'fixed_absorber'
        self.set_materials()
        self.set_pins()
        self.set_lattices()
        self.set_segments()
        self.set_total_height()
        for lattice in self.lattices:
            lattice.members[const.AB] = lattice.id


class ControlRodElementType(ElementType, SetAttrMixin):
    """
    `ControlRodElementType` is a concrete `ElementType` for control rod. It
    reads files in `mods/control_rod` directory.

    Attributes:
    - type: 'control_rod'
    - lattices: All found lattices.
    - segments: Specify axial segments of the core. (from top to bottom)
    - pins: All found pins.
    - materials: All found materials.
    - total_height: Sum of height of each segment.
    """
    def parse(self):
        self.type = 'control_rod'
        self.set_materials()
        self.set_pins()
        self.set_lattices()
        self.set_segments()
        self.set_total_height()
        for lattice in self.lattices:
            lattice.members[const.CR] = lattice.id


class DetectorElementType(ElementType, SetAttrMixin):
    """
    `DetectorElementType` is a concrete `ElementType` for detector. It reads
    files in `mods/detector` directory.

    Attributes:
    - type: 'detector'
    - lattices: All found lattices.
    - segments: Specify axial segments of the core. (from top to bottom)
    - pins: All found pins.
    - materials: All found materials.
    - total_height: Sum of height of each segment.
    """
    def parse(self):
        self.type = 'detector'
        self.set_materials()
        self.set_pins()
        self.set_lattices()
        self.set_segments()
        self.set_total_height()
        for lattice in self.lattices:
            lattice.members[const.DE] = lattice.id


class PlugElementType(ElementType, SetAttrMixin):
    """
    `PlugElementType` is a concrete `ElementType` for plug. It reads files in
    `mods/plug` directory.

    Attributes:
    - type: 'plug'
    - lattices: All found lattices.
    - segments: Specify axial segments of the core. (from top to bottom)
    - pins: All found pins.
    - materials: All found materials.
    - total_height: Sum of height of each segment.
    """
    def parse(self):
        self.type = 'plug'
        self.set_materials()
        self.set_pins()
        self.set_lattices()
        self.set_segments()
        self.set_total_height()
        for lattice in self.lattices:
            lattice.members[const.PG] = lattice.id


class RadialRefElementType(ElementType, SetAttrMixin):
    """
    `RadialRefElementType` is a concrete `ElementType` for radial reflector. It
    reads files in `mods/radial_reflector` directory.

    Attributes:
    - type: 'radial_reflector'
    - materials: All found materials.
    - radial_ref: Radial reflector composed only of baffle.
    """
    def parse(self):
        self.type = 'radial_reflector'
        self.set_materials()
        self.set_radial_ref()


class AxialRefElementType(ElementType, SetAttrMixin):
    """
    `AxialRefElementType` is a concrete `ElementType` for axial reflector. It
    reads files in `mods/axial_reflector` directory.

    Attributes:
    - type: 'axial_reflector'
    - materials: All found materials.
    - ref_top: Axial reflector in the top. `None` if does not exist.
    - ref_bottom: Axial reflector in the bottom. `None` if does not exist.
    """
    def parse(self):
        self.type = 'axial_reflector'
        self.set_materials()
        self.set_axialrefs()


class ElementEntity:
    """
    `ElementEntity` is the entity or object of a particular `ElementType`.
    Compared with `ElementType`, it has a `name` attribute which corresponds
    to the name given by the user in the input file, and a `model` attribute
    which is an instance of a concrete class of `ElementType`.
    """

    mod_dir = 'mods'
    loaded_models = []
    dirname_to_class = {'fuel': FuelElementType,
                        'fixed_absorber': AbsorberElementType,
                        'control_rod': ControlRodElementType,
                        'detector': DetectorElementType,
                        'plug': PlugElementType,
                        'radial_reflector': RadialRefElementType,
                        'axial_reflector': AxialRefElementType
                        }

    def __init__(self, name, dirname, modname):
        self.name = name
        self.dirname = dirname
        self.modname = modname
        self.path = os.path.join(self.mod_dir, dirname, modname+'.xml')
        # Used by non-reflector mod. Default to 0.
        self.rotation = 0
        # Used by control rod.
        self.base = None
        self.step = None
        self.offset = None
        self.cluster_id = None

    def load(self):
        """Return and set `model` attribute to an instance of `ElementType`."""
        if hasattr(self, 'model'):
            return self.model

        cls = self.__class__
        for loaded_model in cls.loaded_models:
            if self.modname == loaded_model.name and \
                    self.dirname == loaded_model.type:
                self.model = loaded_model
                return loaded_model

        new_model = cls.dirname_to_class[self.dirname].fromfile(self.path)
        cls.loaded_models.append(new_model)
        self.model = new_model
        return new_model

    def __repr__(self):
        return 'ElementEntity({!r})'.format(self.name)


class InputReader:

    def __init__(self, text):
        self.root = ET.fromstring(text)
        self.cycle = int(self.root.get('cycle')) if self.root.get('cycle') \
            else None
        self.core = self.root.find('core')
        self.operation = self.root.find('operation')

    def set_attr(self, archive):
        self.archive = archive
        # Set other attributes through method.
        self.set_assemblies()
        self.set_pitch()
        self.set_clusters()
        self.set_layouts()
        self.set_power()
        self.set_pressure()
        self.set_flow()

    @classmethod
    def fromfile(cls, filepath):
        with open(filepath) as f:
            text = f.read()
        return cls(text)

    def set_power(self):
        operation_tag = self.operation
        rated_tag = operation_tag.find('rated')
        power_tag = rated_tag.find('power')
        self.power = round(float(power_tag.text), const.precision)
        return self.power

    def set_pressure(self):
        rated_tag = self.operation.find('rated')
        pressure_tag = rated_tag.find('pressure')
        self.pressure = round(float(pressure_tag.text), const.precision)
        return self.pressure

    def set_flow(self):
        rated_tag = self.operation.find('rated')
        flow_tag = rated_tag.find('flow')
        self.flow = round(float(flow_tag.text), const.precision)
        return self.flow

    def set_assemblies(self):
        asm_tags = self.core.findall('assembly')
        self.assemblies = []
        for asm_tag in asm_tags:
            local_type = asm_tag.get('type')
            local_modname = asm_tag.get('model')
            local_name = asm_tag.get('name')
            if (not local_type) or (not local_modname and not local_name):
                raise InputFileError('Attribute error in assembly tag')
            if local_modname:
                asm_names = row_text(asm_tag.text)
                for asm_name in asm_names:
                    for asm in self.assemblies:
                        if asm.name == asm_name and asm.dirname == local_type:
                            raise InputFileError('Duplicated assembly name: '
                                    '{}'.format(asm_name))
                    self.assemblies.append(ElementEntity(asm_name, local_type,
                                                    local_modname))
            else:
                try:
                    asm = self.archive['input_assemblies'][local_name]
                except IndexError:
                    raise InputFileError('Assembly not found: {}'
                            .format(local_name))
                self.assemblies.append(asm['entity'])

    def find_assembly(self, asm_name, type_name, modify=True):
        """
        Find assembly by name and type.  Argument `asm_name` must not be
        placeholder.
        """
        for asm in self.assemblies:
            if asm.name == asm_name and asm.dirname == type_name:
                return asm
        if self.cycle == 1:
            raise InputFileError('Assembly not found: {}'.format(asm_name))
        try:
            asm = self.archive['input_assemblies'][asm_name]['entity']
        except IndexError:
            raise InputFileError('Assembly not found: {}'
                    .format(asm_name))
        if asm.dirname != type_name:
            raise InputFileError('Assembly not found: {}'.format(asm_name))
        if modify:
            self.assemblies.append(asm)
        return asm

    def find_axialrefs(self):
        for asm in self.assemblies:
            if asm.dirname == "axial_reflector":
                axialref_reader = asm.load()
                return axialref_reader.ref_top, axialref_reader.ref_bottom
        else:
            return None, None

    def find_radialref(self):
        for asm in self.assemblies:
            if asm.dirname == 'radial_reflector':
                radialref_reader = asm.load()
                return radialref_reader.radial_ref
        else:
            return None

    def set_pitch(self):
        layout_tags = self.core.findall('layout')
        for layout_tag in layout_tags:
            if layout_tag.get('type') == 'fuel':
                location_tag = layout_tag.find('location')
                self.pitch = round(float(location_tag.get('pitch')),
                        const.precision)
                return
        else:
            raise InputFileError('Can\'t get pitch of the core.')

    def set_clusters(self):
        control_rod_tag = self.operation.find('control_rod')
        cluster_tags = control_rod_tag.findall('cluster')
        self.clusters = {}
        # A dict mapping cluster id in input file of this program to cluster id
        # in input file of Bamboo-Core.
        self.cluster_map = {}
        old_cluster_id = 1
        for cluster_tag in cluster_tags:
            asm_names = row_text(cluster_tag.text)
            self.clusters.setdefault(cluster_tag.get('id'), []).extend(
                    asm_names)
            self.cluster_map[cluster_tag.get('id')] = old_cluster_id
            old_cluster_id += 1

    def find_cluster_id(self, cr_name):
        for cluster_id, asm_names in self.clusters.items():
            if cr_name in asm_names:
                return cluster_id
        # return None

    def set_layouts(self):
        """
        Attribute `layout` is a 3D list. The outmost dimension indicates the
        type of layout, which can be indexed with `const.**`. Every 2D
        list in it specifies a radial layout.
        """
        self.layouts = [None]*5
        layout_tags = self.core.findall('layout')
        for layout_tag in layout_tags:
            local_type = layout_tag.get('type')
            if local_type == 'fuel':
                self.layouts[const.FU] = self.get_layout(layout_tag)
            elif local_type == 'fixed_absorber':
                self.layouts[const.AB] = \
                    self.get_layout(layout_tag)
            elif local_type == 'control_rod':
                self.layouts[const.CR] = \
                    self.get_cr_layout(layout_tag)
            elif local_type == 'detector':
                self.layouts[const.DE] = \
                    self.get_layout(layout_tag)
            elif local_type == 'plug':
                self.layouts[const.PG] = \
                    self.get_layout(layout_tag)
            else:
                raise InputFileError('Unrecognizable layout type: {}'.format(
                    local_type))
        if not self.layouts[const.FU]:
            raise InputFileError('Fuel layout must be specified')

    def get_layout(self, layout_tag):
        location_tag = layout_tag.find('location')
        rotation_tag = layout_tag.find('rotation')
        typename = layout_tag.get('type')
        location = matrix_text(location_tag.text)
        asm_location = []
        # If rotation tag is specified, use angles in this tag. Or use the
        # default angle in `ElementEntity` if the assembly is newly added in
        # this cycle. Use the angle in the latest cycle containing this
        # assembly if the assembly is not newly added in this cycle.
        if rotation_tag is not None:
            rotation = matrix_text(rotation_tag.text)
            for location_list, rotation_list in zip(location, rotation):
                tmp_list = []
                for asm_name, angle in zip(location_list, rotation_list):
                    if const.placeholder.match(asm_name):
                        tmp_list.append(None)
                    else:
                        asm = self.find_assembly(asm_name, typename)
                        if int(angle) % 360 not in \
                                const.allowed_rotation_angles:
                            raise InputFileError('Rotation angle must be '
                            'equal to one of {}'.format(
                                const.allowed_rotation_angles))
                        asm.rotation = int(angle) % 360
                        tmp_list.append(asm)
                asm_location.append(tmp_list)
            return asm_location
        else:
            for location_list in location:
                tmp_list = []
                for asm_name in location_list:
                    if const.placeholder.match(asm_name):
                        tmp_list.append(None)
                    else:
                        asm = self.find_assembly(asm_name, typename)
                        tmp_list.append(asm)
                asm_location.append(tmp_list)
            return asm_location

    def get_cr_layout(self, layout_tag):
        """
        Control rod layout has location, rotation, base, step, offset tags.
        Among them, location, base, step, offset tags are necessary. That means
        whether the control rod assembly is newly added or not, the attributes
        base, step and offset are always the value specified in this input
        file. Rotation tag is optional. If specified, use the value in this
        input file. If not specified, use the default angle value in
        `ElementEntity` when the assembly is newly added in this cycle, or use
        the angle in the latest cycle containing this assembly when the
        assembly is not newly added in this cycle.
        """
        location_tag = layout_tag.find('location')
        rotation_tag = layout_tag.find('rotation')
        base_tag = layout_tag.find('base')
        step_tag = layout_tag.find('step')
        offset_tag = layout_tag.find('offset')
        typename = layout_tag.get('type')
        location = matrix_text(location_tag.text)
        base = matrix_text(base_tag.text)
        step = matrix_text(step_tag.text)
        offset = matrix_text(offset_tag.text)
        asm_location = []
        if rotation_tag is None:
            for location_list, base_list, step_list, offset_list in \
                    zip(location, base, step, offset):
                tmp_list = []
                for asm_name, base_value, step_value, offset_value in \
                        zip(location_list, base_list, step_list, offset_list):
                    if const.placeholder.match(asm_name):
                        tmp_list.append(None)
                    else:
                        asm = self.find_assembly(asm_name, typename)
                        asm.base = round(float(base_value), const.precision)
                        asm.step = round(float(step_value), const.precision)
                        asm.offset = round(float(offset_value),
                                const.precision)
                        asm.cluster_id = self.find_cluster_id(asm_name)
                        tmp_list.append(asm)
                asm_location.append(tmp_list)
            return asm_location
        else:
            rotation = matrix_text(rotation_tag.text)
            for location_list, base_list, step_list, offset_list, \
                    rotation_list in zip(location, base, step,
                            offset, rotation):
                tmp_list = []
                for asm_name, base_value, step_value, offset_value, angle in \
                        zip(location_list, base_list, step_list,
                            offset_list, rotation_list):
                    if const.placeholder.match(asm_name):
                        tmp_list.append(None)
                    else:
                        asm = self.find_assembly(asm_name, typename)
                        asm.base = round(float(base_value), const.precision)
                        asm.step = round(float(step_value), const.precision)
                        asm.offset = int(offset_value)
                        asm.cluster_id = self.find_cluster_id(asm_name)
                        if int(angle) % 360 not in \
                                const.allowed_rotation_angles:
                            raise InputFileError('Rotation angle must be '
                            'equal to one of {}'.format(
                                const.allowed_rotation_angles))
                        asm.rotation = int(angle) % 360
                        tmp_list.append(asm)
                asm_location.append(tmp_list)
            return asm_location

    def get_burn_step(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        burn_step_tag = depletion_tag.find('burn_step')
        return burn_step_tag

    def get_depletion_power(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        power_tag = depletion_tag.find('power')
        return power_tag

    def get_cb_init(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        cb_init_tag = depletion_tag.find('cb_init')
        return cb_init_tag.text

    def get_calc_worth_order(self):
        operation_tag = self.operation
        controlrod_tag = operation_tag.find('control_rod')
        calc_worth_tag = controlrod_tag.find('calc_worth')
        return calc_worth_tag.get('order').split()

    def get_calc_worth(self):
        operation_tag = self.operation
        controlrod_tag = operation_tag.find('control_rod')
        calc_worth_tag = controlrod_tag.find('calc_worth')
        return matrix_text(calc_worth_tag.text)

    def get_control(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        control_tag = depletion_tag.find('control')
        return matrix_text(control_tag.text)

    def get_kinetic(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        kinetic_tag = depletion_tag.find('kinetic')
        if kinetic_tag is None:
            return [], []
        calc_point = row_text(kinetic_tag.find('calc_point').text)
        relative_power = row_text(kinetic_tag.find('relative_power').text)
        return calc_point, relative_power

    def get_crworth(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        crworth_tag = depletion_tag.find('crworth')
        if crworth_tag is None:
            return [], []
        calc_point = row_text(crworth_tag.find('calc_point').text)
        relative_power = row_text(crworth_tag.find('relative_power').text)
        return calc_point, relative_power

    def get_alpha(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        alpha_tag = depletion_tag.find('alpha')
        if alpha_tag is None:
            return [], [], [], [], []
        calc_point = row_text(alpha_tag.find('calc_point').text)
        relative_power = row_text(alpha_tag.find('relative_power').text)
        offset_tu = row_text(alpha_tag.find('offset_tu').text)
        offset_tm = row_text(alpha_tag.find('offset_tm').text)
        offset_cb = row_text(alpha_tag.find('offset_cb').text)
        return calc_point, relative_power, offset_tu, offset_tm, offset_cb

    def get_tempin(self):
        operation_tag = self.operation
        depletion_tag = operation_tag.find('depletion')
        tempin_tag = depletion_tag.find('tempin')
        return tempin_tag.text


class SettingsReader:

    def __init__(self, text):
        self.root = ET.fromstring(text)
        self.global_options = self.root.find('global')
        self.fuel_options = self.root.find('fuel')
        self.ref_options = self.root.find('ref')

    @classmethod
    def fromfile(cls, filepath):
        with open(filepath) as f:
            text = f.read()
        return cls(text)

    def get_min_mesh_num(self):
        mesh_num_tags = self.global_options.findall('NumLines1st')
        for tag in mesh_num_tags:
            if tag.get('type') is None:
                return int(tag.text)

    def get_max_mesh_num(self):
        mesh_num_tags = self.global_options.findall('NumLines1st')
        for tag in mesh_num_tags:
            if tag.get('type') == 'CRBA':
                return int(tag.text)

    def get_ring1st(self):
        ring1st_tags = self.global_options.findall('Ring1st')
        for tag in ring1st_tags:
            if tag.get('type') is None:
                return int(tag.text)

    def get_crba_ring1st(self):
        ring1st_tags = self.global_options.findall('Ring1st')
        for tag in ring1st_tags:
            if tag.get('type') == 'CRBA':
                return int(tag.text)

    def get_db_path(self):
        db_path_tag = self.global_options.find('database_path')
        for path_tag in db_path_tag:
            path_tag.text = os.path.abspath(path_tag.text)
        return db_path_tag

    def get_lattice_settings(self):
        global_tag = self.global_options
        trans_correc = global_tag.find('transport_correction')
        nxs_correc = global_tag.find('nxs_correction')
        tr_cor_mode = global_tag.find('tr_cor_mode')
        sxr_fac = global_tag.find('SXRFactor')
        fismatrix = global_tag.find('fismatrix')
        energy_sph = global_tag.find('energy_sph')
        res_option = global_tag.find('res_option')
        xen = global_tag.find('XEN')
        diff_coe = global_tag.find('diff_coe')
        macro_calc = global_tag.find('macro_calc')
        lattice_settings = [trans_correc, nxs_correc, tr_cor_mode, sxr_fac,
                fismatrix, energy_sph, res_option, xen, diff_coe, macro_calc]
        return lattice_settings

    def get_fuel_statepoints(self):
        if hasattr(self, 'fuel_statepoints'):
            return self.fuel_statepoints
        fuel_tag = self.fuel_options
        statepoints_tag = fuel_tag.find('statepoints')
        self.fuel_cb = float(statepoints_tag.get('typical_CB'))
        self.fuel_tf = float(statepoints_tag.get('typical_TF'))
        self.fuel_tm = float(statepoints_tag.get('typical_TM'))
        statepoints = []
        for collector_tag in statepoints_tag.findall('collector'):
            tfs = list(map(float, row_text(collector_tag.find('TF').text)))
            tms = list(map(float, row_text(collector_tag.find('TM').text)))
            cbs = list(map(float, row_text(collector_tag.find('CB').text)))
            bus = list(map(float, row_text(collector_tag.find('BU').text)))
            for tf in tfs:
                for tm in tms:
                    for cb in cbs:
                        for bu in bus:
                            statepoints.append((tf, tm, cb, bu))
        self.fuel_statepoints = statepoints
        return statepoints

    def get_ref_statepoints(self):
        if hasattr(self, 'ref_statepoints'):
            return self.ref_statepoints
        ref_tag = self.ref_options
        statepoints_tag = ref_tag.find('statepoints')
        statepoints = []
        for collector_tag in statepoints_tag.findall('collector'):
            tfs = list(map(float, row_text(collector_tag.find('TF').text)))
            tms = list(map(float, row_text(collector_tag.find('TM').text)))
            cbs = list(map(float, row_text(collector_tag.find('CB').text)))
            bus = list(map(float, row_text(collector_tag.find('BU').text)))
            for tf in tfs:
                for tm in tms:
                    for cb in cbs:
                        for bu in bus:
                            statepoints.append((tf, tm, cb, bu))
        self.ref_statepoints = statepoints
        return statepoints

    def get_fuel_cr_common(self):
        fuel_tag = self.fuel_options
        cr_tags = fuel_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'COMMON':
                cr_common_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="COMMON"` not found in fuel settings.')
        cr_common_str = cr_common_tag.text
        cr_common_str = cr_common_str.strip()
        cr_common_str_list = cr_common_str.splitlines()
        cr_common_str_list = [string.strip() for string in cr_common_str_list]
        cr_common_str = '\n'.join(cr_common_str_list)
        return cr_common_str

    def get_fuel_cr_xs(self):
        fuel_tag = self.fuel_options
        cr_tags = fuel_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'XS':
                cr_xs_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="XS"` not found in fuel settings.')
        cr_xs_str = cr_xs_tag.text
        cr_xs_str = cr_xs_str.strip()
        cr_xs_str_list = cr_xs_str.splitlines()
        cr_xs_str_list = [string.strip() for string in cr_xs_str_list]
        cr_xs_str = '\n'.join(cr_xs_str_list)
        return cr_xs_str

    def get_fuel_cr_kin(self):
        fuel_tag = self.fuel_options
        cr_tags = fuel_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'KIN':
                cr_kin_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="KIN"` not found in fuel settings.')
        cr_kin_str = cr_kin_tag.text
        cr_kin_str = cr_kin_str.strip()
        cr_kin_str_list = cr_kin_str.splitlines()
        cr_kin_str_list = [string.strip() for string in cr_kin_str_list]
        cr_kin_str = '\n'.join(cr_kin_str_list)
        return cr_kin_str

    def get_fuel_cr_form(self):
        fuel_tag = self.fuel_options
        cr_tags = fuel_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'FORM':
                cr_form_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="FORM"` not found in fuel settings.')
        cr_form_str = cr_form_tag.text
        cr_form_str = cr_form_str.strip()
        cr_form_str_list = cr_form_str.splitlines()
        cr_form_str_list = [string.strip() for string in cr_form_str_list]
        cr_form_str = '\n'.join(cr_form_str_list)
        return cr_form_str

    def get_ref_cr_common(self):
        ref_tag = self.ref_options
        cr_tags = ref_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'COMMON':
                cr_common_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="COMMON"` not found in reflector settings.')
        cr_common_str = cr_common_tag.text
        cr_common_str = cr_common_str.strip()
        cr_common_str_list = cr_common_str.splitlines()
        cr_common_str_list = [string.strip() for string in cr_common_str_list]
        cr_common_str = '\n'.join(cr_common_str_list)
        return cr_common_str

    def get_ref_cr_xs(self):
        ref_tag = self.ref_options
        cr_tags = ref_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'XS':
                cr_xs_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="XS"` not found in reflector settings.')
        cr_xs_str = cr_xs_tag.text
        cr_xs_str = cr_xs_str.strip()
        cr_xs_str_list = cr_xs_str.splitlines()
        cr_xs_str_list = [string.strip() for string in cr_xs_str_list]
        cr_xs_str = '\n'.join(cr_xs_str_list)
        return cr_xs_str

    def get_ref_cr_kin(self):
        ref_tag = self.ref_options
        cr_tags = ref_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'KIN':
                cr_kin_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="KIN"` not found in reflector settings.')
        cr_kin_str = cr_kin_tag.text
        cr_kin_str = cr_kin_str.strip()
        cr_kin_str_list = cr_kin_str.splitlines()
        cr_kin_str_list = [string.strip() for string in cr_kin_str_list]
        cr_kin_str = '\n'.join(cr_kin_str_list)
        return cr_kin_str

    def get_ref_cr_form(self):
        ref_tag = self.ref_options
        cr_tags = ref_tag.findall('CR')
        for tag in cr_tags:
            if tag.get('type') == 'FORM':
                cr_form_tag = tag
                break
        else:
            raise SettingsError('CR tag with attribute '
                '`type="FORM"` not found in reflector settings.')
        cr_form_str = cr_form_tag.text
        cr_form_str = cr_form_str.strip()
        cr_form_str_list = cr_form_str.splitlines()
        cr_form_str_list = [string.strip() for string in cr_form_str_list]
        cr_form_str = '\n'.join(cr_form_str_list)
        return cr_form_str

    def get_fuel_homo(self):
        fuel_tag = self.fuel_options
        return fuel_tag.find('homo')

    def get_ref_homo(self):
        ref_tag = self.ref_options
        return ref_tag.find('homo')

    def get_detector_numreg(self):
        global_tag = self.global_options
        detector_tag = global_tag.find('detector')
        return detector_tag.get('NumReg')

    def get_fuel_leakage(self):
        fuel_tag = self.fuel_options
        return fuel_tag.find('leakage')

    def get_ref_leakage(self):
        ref_tag = self.ref_options
        return ref_tag.find('leakage')

    def get_fuel_criterion(self):
        fuel_tag = self.fuel_options
        return fuel_tag.find('criterion')

    def get_ref_criterion(self):
        ref_tag = self.ref_options
        return ref_tag.find('criterion')

    def get_lattice_print(self):
        global_tag = self.global_options
        lattice_print = global_tag.find('lattice_print')
        return lattice_print

    def get_core_print(self):
        global_tag = self.global_options
        core_print = global_tag.find('core_print')
        return core_print

    def get_condense(self):
        global_tag = self.global_options
        return global_tag.find('condense')

    def get_ifba_condition(self):
        fuel_tag = self.fuel_options
        conditions = fuel_tag.findall('condition')
        for tag in conditions:
            if tag.get('type') == 'IFBA':
                return tag

    def get_fuel_condition(self):
        fuel_tag = self.fuel_options
        conditions = fuel_tag.findall('condition')
        for tag in conditions:
            if tag.get('type') is None:
                return tag

    def get_ref_condition(self):
        ref_tag = self.ref_options
        return ref_tag.find('condition')

    def get_lilac_path(self):
        global_tag = self.global_options
        return global_tag.find('lilac_path').text

    def get_geodef(self):
        global_tag = self.global_options
        return global_tag.find('GeoDef')

    def get_rec(self):
        global_tag = self.global_options
        return global_tag.find('REC')

    def get_burnup(self):
        global_tag = self.global_options
        return global_tag.find('BURNUP')

    def get_controlrod(self):
        global_tag = self.global_options
        return global_tag.find('CONTROLROD')

    def get_otset(self):
        global_tag = self.global_options
        return global_tag.find('OTset')

    def get_thermal(self):
        global_tag = self.global_options
        return global_tag.find('THERMAL')

    def get_thermalpass(self):
        global_tag = self.global_options
        return global_tag.find('ThermalPass')
