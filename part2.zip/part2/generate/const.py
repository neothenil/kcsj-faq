import re
import os

FU, AB, PG, DE, CR = range(5)
IN, BL, LL, UL, RL, RB, LB, LU, RU = range(9)
TF, TM, CB, BU = range(4)
H1, H4, H5 = range(3)

ModeratorID = 255
box_mesh_num = 5
axial_base_mesh_length = 20.0
ABML = axial_base_mesh_length  # Abbreviation for `axial_base_mesh_length`
stpnum = 200

precision = 10

NA = 0.602214129

placeholder = re.compile('-+')
uranium = re.compile(r'[uU](\d{3})')
empty_text = re.compile(r'\s+')
allowed_rotation_angles = [0, 90, 180, 270]

lattice_dir = 'inputs/lattice'
readb_dir = 'inputs/readb'
core_dir = 'inputs/core'
mass_data_file = os.path.join(os.path.dirname(__file__), 'mass_data')
archive_file = 'archive'
settings_file = os.path.join(os.path.dirname(__file__), 'settings.xml')

# `update_lilac` should be `true` or `false`;
# `lattice` should be an empty string or an string starting with `--lattice `
# followed with lattice codes;
# `cycle` should be a cycle number or a sequence of cycle numbers.
sh_template = '''#!/bin/sh

pyexe=python
if which python3 >/dev/null 2>&1; then
    pyexe=python3
fi

update_lilac={update_lilac}
if [ -n "$1" ]; then
    if $update_lilac; then
        $pyexe bamboo lattice {lattice} -j $1 && \\
        $pyexe bamboo readb && \\
        $pyexe bamboo core {cycle} --update
    else
        $pyexe bamboo core {cycle}
    fi
else
    if $update_lilac; then
        $pyexe bamboo lattice {lattice} && \\
        $pyexe bamboo readb && \\
        $pyexe bamboo core {cycle} --update
    else
        $pyexe bamboo core {cycle}
    fi
fi
'''
bat_template = '''@echo off
set update_lilac={update_lilac}
if "%1"=="" (
    if %update_lilac%==true (
        python bamboo lattice {lattice} && ^
python bamboo readb && ^
python bamboo core {cycle} --update
    ) else (
        python bamboo core {cycle}
    )
) else (
    if %update_lilac%==true (
        python bamboo lattice {lattice} -j %1 && ^
python bamboo readb && ^
python bamboo core {cycle} --update
    ) else (
        python bamboo core {cycle}
    )
)
'''
