class InputFileError(Exception):
    pass


class ModFileError(Exception):
    pass


class SettingsError(Exception):
    pass
