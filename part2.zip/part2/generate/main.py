import argparse

from .control import Controller


def main(args):
    parser = argparse.ArgumentParser(prog='bamboo generate',
            description='Generate input files.')
    parser.add_argument('file', metavar='<file>',
            help='specify the input file for generating input files')
    args = parser.parse_args(args)
    try:
        c = Controller(args.file)
        c.init()
        c.generate()
        c.save_archive()
    except Exception as e:
        raise e


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
