import pickle

from . import const
from .component import Core
from .component import compare
from .reader import SettingsReader, InputReader


class Controller:
    """
    `Controller` is a class above the `Core` level. It is used to control the
    relationship of different cycles. And it is a top interface communicating
    with command line arguments.
    """
    def __init__(self, filename):
        settings = SettingsReader.fromfile(const.settings_file)
        inp = InputReader.fromfile(filename)
        if inp.cycle == 1:
            self.archive = {}
        else:
            self.archive = self.load_archive()
        inp.set_attr(self.archive)
        self.core = Core(inp, settings)

    def init(self):
        """
        Initialize data in a core. If this is the first cycle, just call
        `combine_asm_types` directly. If not, find unique assembly types in
        this cycle and remove others first, then call `combine_asm_types` and
        update some attributes in the `Core` instance.
        """
        if self.core.cycle == 1:
            self.core.combine_asm_types()
        else:
            new_asm_types = []
            old_asm_types = []
            replace_dict = {}
            for asm_type in self.core.asm_types:
                for old_asm_type in self.archive['assembly_types']:
                    if asm_type == old_asm_type:
                        old_asm_types.append(old_asm_type)
                        replace_dict[asm_type.id] = old_asm_type
                        break
                else:
                    new_asm_types.append(asm_type)
            self.core.asm_types = new_asm_types
            self.core.old_asm_types = old_asm_types
            self.core.combine_asm_types()
            self.update_asm_type_layout(replace_dict)
            duplicated = compare.compare2(self.archive['lattices'],
                    self.core.new_lattices)
            self.update_new_lattices(duplicated)
            self.update_asm_types(duplicated)
        self.core.update_ref_matlibid()
        old_cr_mats = self.archive.get('cr_mats', [])
        self.core.set_cr_mats(old_cr_mats)

    def update_asm_type_layout(self, replace_dict):
        if not replace_dict:
            # If `replace_dict` is empty, then `old_asm_types` should also be
            # empty.
            return
        # clear `positions` attribute in `old_asm_types`
        for asm_type in self.core.old_asm_types:
            asm_type.positions = []
        new_asm_type_layout = []
        for i, asm_type_line in enumerate(self.core.asm_type_layout):
            new_asm_type_line = []
            for j, asm_type in enumerate(asm_type_line):
                if asm_type is None:
                    new_asm_type_line.append(None)
                    continue
                if asm_type.id in replace_dict:
                    new_asm_type_line.append(replace_dict[asm_type.id])
                    # set new `positions` attribute
                    replace_dict[asm_type.id].positions.append((i, j))
                else:
                    new_asm_type_line.append(asm_type)
            new_asm_type_layout.append(new_asm_type_line)
        self.core.asm_type_layout = new_asm_type_layout

    def update_new_lattices(self, duplicated):
        new_lattices = [lattice for lattice in self.core.new_lattices
                if lattice not in duplicated]
        self.core.next_matlibid = self.core.init_matlibid
        for lattice in new_lattices:
            lattice.matlibid = self.core.next_matlibid
            lattice.set_id(None, None)
            self.core.next_matlibid += 1
        self.core.new_lattices = new_lattices

    def update_asm_types(self, duplicated):
        for asm_type in self.core.asm_types:
            new_lattices = []
            new_controlrod_lattices = []
            for lattice in asm_type.lattices:
                if lattice in duplicated:
                    new_lattices.append(duplicated[lattice])
                else:
                    new_lattices.append(lattice)
            for lattice in asm_type.controlrod_lattices:
                if lattice in duplicated:
                    new_controlrod_lattices.append(duplicated[lattice])
                else:
                    new_controlrod_lattices.append(lattice)
            asm_type.lattices = new_lattices
            asm_type.controlrod_lattices = new_controlrod_lattices
            for segment in asm_type.segments:
                if segment.lattice not in duplicated:
                    continue
                segment.lattice = duplicated[segment.lattice]

    def generate(self):
        self.core.generate_lattice_files()
        self.core.generate_reflector_files()
        self.core.generate_readb()
        self.core.generate_cr()
        self.core.generate_core()
        self.core.generate_script()

    def save_archive(self):
        """
        Update data in archive file and save it.
        """
        self.archive['next_matlibid'] = self.core.next_matlibid
        input_assemblies = self.archive.setdefault('input_assemblies', {})
        # Non reflector assembly
        for layout in self.core.inp.layouts:
            if layout is None:
                continue
            for row_index, assemblies in enumerate(layout):
                for col_index, assembly in enumerate(assemblies):
                    if assembly is None:
                        continue
                    name = assembly.name
                    assembly_info = input_assemblies.setdefault(name, {})
                    assembly_info['entity'] = assembly
                    assembly_history = assembly_info.setdefault('history', [])
                    cur_history_info = {'cycle': self.core.cycle,
                            'row_index': row_index,
                            'col_index': col_index}
                    assembly_history.append(cur_history_info)
        # Reflector assembly
        for assembly in self.core.inp.assemblies:
            if assembly.dirname.endswith('reflector'):
                name = assembly.name
                assembly_info = input_assemblies.setdefault(name, {})
                assembly_info['entity'] = assembly
                assembly_history = assembly_info.setdefault('history', [])
                cur_history_info = {'cycle': self.core.cycle}
                assembly_history.append(cur_history_info)
        # Assembly types information
        assembly_types = self.archive.setdefault('assembly_types', [])
        assembly_types.extend(self.core.asm_types)
        # Lattices information
        lattices = self.archive.setdefault('lattices', [])
        lattices.extend(self.core.new_lattices)
        # cr_mats
        self.archive['cr_mats'] = self.core.cr_mats
        with open(const.archive_file, 'wb') as f:
            pickle.dump(self.archive, f)

    def load_archive(self):
        with open(const.archive_file, 'rb') as f:
            return pickle.load(f)
