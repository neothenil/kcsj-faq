import os

from .. import const

from . import element_to_node, dom, Box


class AxialRef:

    def __init__(self, heights, mats, typename):
        """
        `typename` should be chosen from "top" and "bottom".
        """
        self.heights = heights
        self.mats = mats
        self.typename = typename
        self.set_all_mats()
        self.matlibid = 0

    def set_all_mats(self):
        all_mats = []
        for mat in self.mats:
            if mat not in all_mats and mat is not None:
                all_mats.append(mat)
        self.all_mats = all_mats

    def set_id(self):
        if self.typename == 'top':
            str_id = 'reftop_{}'.format(self.matlibid)
        else:
            str_id = 'refbot_{}'.format(self.matlibid)
        self.id = str_id

    def info_between(self, start_point, end_point):
        """
        Key method in this class which can give the information in a range.
        Trust me, it could work.
        """
        if start_point < 0.0 or end_point > self.heights[-1]:
            raise AttributeError
        for index, value in enumerate(self.heights):
            if value > start_point:
                start_index = index
                break
        for index, value in enumerate(self.heights):
            if value >= end_point:
                end_index = index
                break
        mats_in_range = self.mats[start_index:end_index+1]
        heights_in_range = self.heights[start_index:end_index]
        relative_heights = [round(height - start_point, const.precision)
            for height in heights_in_range]
        relative_heights.append(round(end_point - start_point,
            const.precision))
        return relative_heights, mats_in_range

    def set_axial_box_layout(self, shape, size):
        """
        Set `all_boxes` and `box_layout` attributes.
        """
        if isinstance(shape, tuple):
            shape = shape[0]
        heights = self.heights
        mats = self.mats
        max_height = round(shape * size, const.precision)
        if heights[-1] < max_height:
            heights.append(max_height)
            mats.append(None)
        box_layout = []
        all_boxes = []
        for i in range(shape):
            start_point = round(i * size, const.precision)
            end_point = round(start_point + size, const.precision)
            new_box = Box(*self.info_between(start_point, end_point))
            for old_box in all_boxes:
                if new_box == old_box:
                    new_box = old_box
                    break
            else:
                all_boxes.append(new_box)
            box_layout.append(new_box)
        self.all_boxes = all_boxes
        self.box_layout = box_layout

    def set_matid_map(self, start_id):
        """
        Set `matid_map` attribute.
        """
        matid_map = {}
        for mat in self.all_mats:
            matid_map[mat.id] = start_id
            start_id += 1
        self.matid_map = matid_map

    def set_boxid(self, start_id):
        for box in self.all_boxes:
            box.setid(start_id)
            start_id += 1

    def place_with(self, fuel_lattice, settings):
        """
        Give information necessary for generating axial reflector input files.
        Save these information as attributes.

        New attributes: main_tm, main_tf, main_cb, controlrod, power,
        moderator_tag, modgeo_tag, coregeo_tag, base_doc.
        """
        self.set_axial_box_layout(fuel_lattice.shape, fuel_lattice.pin_size)
        fuel_gene_dir = os.path.join(const.lattice_dir, fuel_lattice.id)
        fuel_main_filename = fuel_lattice.id + '-main.xml'
        fuel_main_doc = dom.parse(os.path.join(fuel_gene_dir,
            fuel_main_filename))

        # Elements need to be modified in settings tag.
        settings_tag = fuel_main_doc.getElementsByTagName('settings')[0]
        detector_tag_list = settings_tag.getElementsByTagName('detector')
        if detector_tag_list:
            for detector_tag in detector_tag_list:
                settings_tag.removeChild(detector_tag)
        homo_tag = settings_tag.getElementsByTagName('homo')[0]
        new_homo_tag = element_to_node(settings.get_ref_homo(), fuel_main_doc)
        settings_tag.replaceChild(new_homo_tag, homo_tag)
        nxs_tag = settings_tag.getElementsByTagName('nxs_correction')[0]
        new_nxs_tag = fuel_main_doc.createElement('nxs_correction')
        new_nxs_tag.appendChild(fuel_main_doc.createTextNode('yes'))
        settings_tag.replaceChild(new_nxs_tag, nxs_tag)
        sxr_tag = settings_tag.getElementsByTagName('SXRFactor')[0]
        new_sxr_tag = fuel_main_doc.createElement('SXRFactor')
        new_sxr_tag.appendChild(fuel_main_doc.createTextNode('0.4'))
        settings_tag.replaceChild(new_sxr_tag, sxr_tag)
        linkpara_tag = settings_tag.getElementsByTagName('LinkPara')[0]
        self.main_tm = linkpara_tag.getAttribute('TMO')
        self.main_tf = linkpara_tag.getAttribute('TFU')
        self.main_cb = linkpara_tag.getAttribute('BOR')
        self.controlrod = linkpara_tag.getAttribute('ControlRod')

        # material information
        material_tags = fuel_main_doc.getElementsByTagName('material')
        self.moderator_tag = material_tags[-1]
        max_matid = 0
        for material_tag in material_tags[:-1]:
            int_id = int(material_tag.getAttribute('ID'))
            if int_id > max_matid:
                max_matid = int_id
        start_matid = max_matid + 1
        self.set_matid_map(start_matid)

        # SubGeo information
        subgeo_tags = fuel_main_doc.getElementsByTagName('SubGeo')
        max_subid = 0
        for subgeo_tag in subgeo_tags:
            subid = int(subgeo_tag.getAttribute('ID')) % 10000
            if subid > max_subid:
                max_subid = subid
        start_boxid = max_subid + 1
        self.set_boxid(start_boxid)
        self.modgeo_tag = fuel_main_doc.getElementsByTagName('ModGeo')[0]

        # Set new coregeo and coremat.
        coregeo = fuel_main_doc.createElement('CoreGeo')
        coregeo.setAttrs({'NumModXs': '2', 'NumModYs': '1'})
        l = fuel_main_doc.createElement('L')
        l.appendChild(fuel_main_doc.createTextNode('1 2'))
        coregeo.appendChild(l)
        coremat = fuel_main_doc.createElement('CoreMat')
        coremat.setAttrs({'NumModXs': '2', 'NumModYs': '1'})
        l = fuel_main_doc.createElement('L')
        l.appendChild(fuel_main_doc.createTextNode('1 2'))
        coremat.appendChild(l)
        old_coregeo = fuel_main_doc.getElementsByTagName('CoreGeo')[0]
        old_coremat = fuel_main_doc.getElementsByTagName('CoreMat')[0]
        input_tag = fuel_main_doc.documentElement
        input_tag.replaceChild(coregeo, old_coregeo)
        input_tag.replaceChild(coremat, old_coremat)
        self.coregeo_tag = coregeo

        # Set new leakage tag.
        leakage = element_to_node(settings.get_ref_leakage(), fuel_main_doc)
        old_leakage = fuel_main_doc.getElementsByTagName('leakage')[0]
        input_tag.replaceChild(leakage, old_leakage)

        # Depletion information
        depletion_tag = fuel_main_doc.getElementsByTagName('depletion')[0]
        self.power = depletion_tag.getAttribute('power')
        burnstep_tag = depletion_tag.getElementsByTagName('BurnStep')[0]
        new_burnstep_tag = fuel_main_doc.createElement('BurnStep')
        depletion_tag.replaceChild(new_burnstep_tag, burnstep_tag)

        # Set new condition and criterion tag.
        condition = fuel_main_doc.getElementsByTagName('condition')[0]
        new_condition = element_to_node(settings.get_ref_condition(),
                fuel_main_doc)
        input_tag.replaceChild(new_condition, condition)
        criterion = fuel_main_doc.getElementsByTagName('criterion')[0]
        new_criterion = element_to_node(settings.get_ref_criterion(),
                fuel_main_doc)
        input_tag.replaceChild(new_criterion, criterion)

        self.base_doc = fuel_main_doc

    def to_xml(self, settings):
        input_tag = self.base_doc.documentElement
        for mat in self.all_mats:
            material = self.base_doc.createElement('material')
            material.setAttrs({'ID': str(self.matid_map[mat.id]),
                'temperature': self.main_tm})
            for alias, density in mat.nu_density.items():
                nuclide = self.base_doc.createElement('nuclide')
                nuclide.setAttrs({'alias': alias, 'density': str(density)})
                material.appendChild(nuclide)
            input_tag.insertBefore(material, self.moderator_tag)

        for box in self.all_boxes:
            subgeo, submat = box.to_sub(self.matid_map, self.base_doc)
            input_tag.insertBefore(subgeo, self.modgeo_tag)
            input_tag.insertBefore(submat, self.modgeo_tag)

        modgeo = self.base_doc.createElement('ModGeo')
        modgeo.setAttrs({'ID': '2', 'ModType': '1',
            'NumSubXs': str(len(self.box_layout)),
            'NumSubYs': str(len(self.box_layout))})
        layout_str = ''
        for box in self.box_layout:
            layout_str += str(box.id) + ' '
        layout_str_list = [layout_str] * len(self.box_layout)
        layout_str = '\n' + '\n'.join(layout_str_list) + '\n'
        l = self.base_doc.createElement('L')
        l.appendChild(self.base_doc.createTextNode(layout_str))
        modgeo.appendChild(l)
        modmat = self.base_doc.createElement('ModMat')
        modmat.setAttrs({'ID': '2', 'ModID': '2',
            'NumSubXs': str(len(self.box_layout)),
            'NumSubYs': str(len(self.box_layout))})
        l = self.base_doc.createElement('L')
        l.appendChild(self.base_doc.createTextNode(layout_str))
        modmat.appendChild(l)
        input_tag.insertBefore(modgeo, self.coregeo_tag)
        input_tag.insertBefore(modmat, self.coregeo_tag)

        if self.typename == 'top':
            basename = 'reftop_{}'.format(self.matlibid)
            gene_dir = os.path.join(const.lattice_dir, basename)
            ref_main_filename = basename + '-main.xml'
        else:
            basename = 'refbot_{}'.format(self.matlibid)
            gene_dir = os.path.join(const.lattice_dir, basename)
            ref_main_filename = basename + '-main.xml'
        os.makedirs(gene_dir, exist_ok=True)
        ref_main_file_str = self.base_doc.toprettyxml(indent='', newl='\n')
        ref_main_file_str_list = ref_main_file_str.splitlines(keepends=True)
        ref_main_file_str_list = [i
                for i in ref_main_file_str_list if i != '\n']
        ref_main_file_str = ''.join(ref_main_file_str_list)
        print('generate {}'.format(ref_main_filename))
        with open(os.path.join(gene_dir, ref_main_filename), 'w') as f:
            f.write(ref_main_file_str)

        statepoints = settings.get_ref_statepoints()
        branch_statepoints = []
        main_cb, main_tf, main_tm = (float(self.main_cb),
                float(self.main_tf), float(self.main_tm))
        for statepoint in statepoints:
            if statepoint[const.CB] == main_cb and \
                    statepoint[const.TF] == main_tf and \
                    statepoint[const.TM] == main_tm:
                continue
            branch_statepoints.append(statepoint)

        if len(branch_statepoints) == 0:
            return

        for branch_num in range(1,
                len(branch_statepoints)//const.stpnum + 2):
            stps = branch_statepoints[(branch_num-1)*const.stpnum:
                    branch_num*const.stpnum]
            main_doc = dom.parse(os.path.join(gene_dir, ref_main_filename))
            input_tag = main_doc.documentElement
            restart_node = main_doc.getElementsByTagName('restart')[0]
            input_node = main_doc.getElementsByTagName('input')[0]
            input_node.removeChild(restart_node)
            for stp in stps:
                new_restart = main_doc.createElement('restart')
                new_restart.setAttribute('begin', 'yes')
                leakage = element_to_node(settings.get_ref_leakage(),
                        main_doc)
                depletion = main_doc.createElement('depletion')
                depletion.setAttribute('power', str(self.power))
                burnstep = main_doc.createElement('BurnStep')
                burnstep.appendChild(main_doc.createTextNode(
                    str(stp[const.BU])))
                depletion.appendChild(burnstep)
                linkpara = main_doc.createElement('LinkPara')
                linkpara.setAttrs({'ControlRod': self.controlrod,
                    'TFU': str(stp[const.TF]),
                    'TMO': str(stp[const.TM]),
                    'BOR': str(stp[const.CB])})
                if stp[const.CB] != self.main_cb or \
                        stp[const.TM] != self.main_tm:
                    mod_material = main_doc.createElement('material')
                    mod_material.setAttrs({'ID': str(const.ModeratorID),
                        'temperature': str(stp[const.TM]),
                        'BOR': str(stp[const.CB]),
                        'pressure': str(self.moderator_tag.getAttribute(
                            'pressure')),
                        'ResetAll': 'yes'})
                    new_restart.appendChild(mod_material)
                new_restart.appendChildren([leakage, depletion, linkpara])
                input_node.appendChild(new_restart)

            branch_file_str = main_doc.toprettyxml(indent='', newl='\n')
            branch_file_str_list = branch_file_str.splitlines(keepends=True)
            branch_file_str_list = [i
                    for i in branch_file_str_list if i != '\n']
            branch_file_str = ''.join(branch_file_str_list)
            filename = basename + '-branch{}.xml'.format(branch_num)
            print('generate {}'.format(filename))
            with open(os.path.join(gene_dir, filename), 'w') as f:
                f.write(branch_file_str)

    def __repr__(self):
        return 'AxialRef({!r})'.format(self.id)


class RadialRef(AxialRef):

    def __init__(self, heights, mats):
        self.heights = heights
        self.mats = mats
        self.set_all_mats()
        self.matlibid = 0

    def set_id(self):
        self.id = 'radialref_{}'.format(min(self.matlibid))

    def set_radial_box_layout(self, shape, size, gap_width):
        """
        Set `all_boxes` and `box_layout` attributes.
        """
        if isinstance(shape, tuple):
            shape = shape[0]
        heights = self.heights
        mats = self.mats
        max_height = round(shape * size + 2 * gap_width, const.precision)
        if heights[-1] < max_height:
            heights.append(max_height)
            mats.append(None)
        top_box_layout = []
        inner_box_layout = []
        all_boxes = []
        # left-most box in top_box_layout
        start_point = size + gap_width
        new_box = Box(*self.info_between(0.0, start_point), width=start_point)
        top_box_layout.append(new_box)
        all_boxes.append(new_box)
        # inner boxes in top_box_layout
        for i in range(shape-2):
            start = round(start_point + i * size, const.precision)
            end = round(start_point + (i + 1) * size, const.precision)
            new_box = Box(*self.info_between(start, end), width=start_point)
            for old_box in all_boxes:
                if new_box == old_box:
                    new_box = old_box
                    break
            else:
                all_boxes.append(new_box)
            top_box_layout.append(new_box)
        # right-most box in top_box_layout
        new_box = Box(*self.info_between(end, heights[-1]), width=start_point)
        for old_box in all_boxes:
            if new_box == old_box:
                new_box = old_box
                break
        else:
            all_boxes.append(new_box)
        top_box_layout.append(new_box)
        # left-most box in inner_box_layout
        new_box = Box(*self.info_between(0.0, start_point), width=size)
        inner_box_layout.append(new_box)
        all_boxes.append(new_box)
        # inner boxes in inner_box_layout
        for i in range(shape-2):
            start = round(start_point + i * size, const.precision)
            end = round(start_point + (i + 1) * size, const.precision)
            new_box = Box(*self.info_between(start, end), width=size)
            for old_box in all_boxes:
                if new_box == old_box:
                    new_box = old_box
                    break
            else:
                all_boxes.append(new_box)
            inner_box_layout.append(new_box)
        # right-most box in inner_box_layout
        new_box = Box(*self.info_between(end, heights[-1]), width=size)
        for old_box in all_boxes:
            if new_box == old_box:
                new_box = old_box
                break
        else:
            all_boxes.append(new_box)
        inner_box_layout.append(new_box)
        self.all_boxes = all_boxes
        self.box_layout = [top_box_layout, inner_box_layout]

    def place_with(self, fuel_lattice, settings, gap_width):
        """
        Give information necessary for generating radial reflector input files.
        Save these information as attributes.

        New attributes: main_tm, main_tf, main_cb, controlrod, power,
        moderator_tag, modgeo_tag, coregeo_tag, base_doc.
        """
        if gap_width == 0.0:
            self.set_axial_box_layout(fuel_lattice.shape,
                    fuel_lattice.pin_size)
        else:
            self.set_radial_box_layout(fuel_lattice.shape,
                    fuel_lattice.pin_size, gap_width)
        fuel_gene_dir = os.path.join(const.lattice_dir, fuel_lattice.id)
        fuel_main_filename = fuel_lattice.id + '-main.xml'
        fuel_main_doc = dom.parse(os.path.join(fuel_gene_dir,
            fuel_main_filename))

        # Elements need to be modified in settings tag.
        settings_tag = fuel_main_doc.getElementsByTagName('settings')[0]
        detector_tag_list = settings_tag.getElementsByTagName('detector')
        if detector_tag_list:
            for detector_tag in detector_tag_list:
                settings_tag.removeChild(detector_tag)
        homo_tag = settings_tag.getElementsByTagName('homo')[0]
        new_homo_tag = element_to_node(settings.get_ref_homo(),
                fuel_main_doc)
        settings_tag.replaceChild(new_homo_tag, homo_tag)
        nxs_tag = settings_tag.getElementsByTagName('nxs_correction')[0]
        new_nxs_tag = fuel_main_doc.createElement('nxs_correction')
        new_nxs_tag.appendChild(fuel_main_doc.createTextNode('yes'))
        settings_tag.replaceChild(new_nxs_tag, nxs_tag)
        sxr_tag = settings_tag.getElementsByTagName('SXRFactor')[0]
        new_sxr_tag = fuel_main_doc.createElement('SXRFactor')
        new_sxr_tag.appendChild(fuel_main_doc.createTextNode('0.4'))
        settings_tag.replaceChild(new_sxr_tag, sxr_tag)
        linkpara_tag = settings_tag.getElementsByTagName('LinkPara')[0]
        self.main_tm = linkpara_tag.getAttribute('TMO')
        self.main_tf = linkpara_tag.getAttribute('TFU')
        self.main_cb = linkpara_tag.getAttribute('BOR')
        self.controlrod = linkpara_tag.getAttribute('ControlRod')

        # material information
        material_tags = fuel_main_doc.getElementsByTagName('material')
        self.moderator_tag = material_tags[-1]
        max_matid = 0
        for material_tag in material_tags[:-1]:
            int_id = int(material_tag.getAttribute('ID'))
            if int_id > max_matid:
                max_matid = int_id
        start_matid = max_matid + 1
        self.set_matid_map(start_matid)

        # SubGeo information
        subgeo_tags = fuel_main_doc.getElementsByTagName('SubGeo')
        max_subid = 0
        for subgeo_tag in subgeo_tags:
            subid = int(subgeo_tag.getAttribute('ID')) % 10000
            if subid > max_subid:
                max_subid = subid
        start_boxid = max_subid + 1
        self.set_boxid(start_boxid)
        self.modgeo_tag = fuel_main_doc.getElementsByTagName('ModGeo')[0]

        # Set new coregeo and coremat.
        coregeo = fuel_main_doc.createElement('CoreGeo')
        coregeo.setAttrs({'NumModXs': '2', 'NumModYs': '1'})
        l = fuel_main_doc.createElement('L')
        l.appendChild(fuel_main_doc.createTextNode('1 2'))
        coregeo.appendChild(l)
        coremat = fuel_main_doc.createElement('CoreMat')
        coremat.setAttrs({'NumModXs': '2', 'NumModYs': '1'})
        l = fuel_main_doc.createElement('L')
        l.appendChild(fuel_main_doc.createTextNode('1 2'))
        coremat.appendChild(l)
        old_coregeo = fuel_main_doc.getElementsByTagName('CoreGeo')[0]
        old_coremat = fuel_main_doc.getElementsByTagName('CoreMat')[0]
        input_tag = fuel_main_doc.documentElement
        input_tag.replaceChild(coregeo, old_coregeo)
        input_tag.replaceChild(coremat, old_coremat)
        self.coregeo_tag = coregeo

        # Set new leakage tag.
        leakage = element_to_node(settings.get_ref_leakage(),
                fuel_main_doc)
        old_leakage = fuel_main_doc.getElementsByTagName('leakage')[0]
        input_tag.replaceChild(leakage, old_leakage)

        # Depletion information
        depletion_tag = fuel_main_doc.getElementsByTagName('depletion')[0]
        self.power = depletion_tag.getAttribute('power')
        burnstep_tag = depletion_tag.getElementsByTagName('BurnStep')[0]
        new_burnstep_tag = fuel_main_doc.createElement('BurnStep')
        depletion_tag.replaceChild(new_burnstep_tag, burnstep_tag)

        # Set new condition and criterion tag.
        condition = fuel_main_doc.getElementsByTagName('condition')[0]
        new_condition = element_to_node(settings.get_ref_condition(),
                fuel_main_doc)
        input_tag.replaceChild(new_condition, condition)
        criterion = fuel_main_doc.getElementsByTagName('criterion')[0]
        new_criterion = element_to_node(settings.get_ref_criterion(),
                fuel_main_doc)
        input_tag.replaceChild(new_criterion, criterion)

        self.base_doc = fuel_main_doc

    def to_xml(self, settings, gap_width):
        input_tag = self.base_doc.documentElement
        for mat in self.all_mats:
            material = self.base_doc.createElement('material')
            material.setAttrs({'ID': str(self.matid_map[mat.id]),
                'temperature': self.main_tm})
            for alias, density in mat.nu_density.items():
                nuclide = self.base_doc.createElement('nuclide')
                nuclide.setAttrs({'alias': alias, 'density': str(density)})
                material.appendChild(nuclide)
            input_tag.insertBefore(material, self.moderator_tag)

        for box in self.all_boxes:
            subgeo, submat = box.to_sub(self.matid_map, self.base_doc)
            input_tag.insertBefore(subgeo, self.modgeo_tag)
            input_tag.insertBefore(submat, self.modgeo_tag)

        if gap_width == 0.0:
            numxs = len(self.box_layout)
        else:
            numxs = len(self.box_layout[0])
        numys = numxs
        modgeo = self.base_doc.createElement('ModGeo')
        modgeo.setAttrs({'ID': '2', 'ModType': '1',
            'NumSubXs': str(numxs),
            'NumSubYs': str(numys)})
        if gap_width == 0.0:
            layout_str = ''
            for box in self.box_layout:
                # layout_str += str(box.id) + ' '
                layout_str += '{:5} '.format(box.id)
            layout_str_list = [layout_str] * len(self.box_layout)
            layout_str = '\n' + '\n'.join(layout_str_list) + '\n'
        else:
            # Top and bottom boxes
            top_layout_str = ''
            for box in self.box_layout[0]:
                # top_layout_str += str(box.id) + ' '
                top_layout_str += '{:5} '.format(box.id)
            top_layout_str = '\n' + top_layout_str + '\n'
            # Inner boxes
            inner_layout_str = ''
            for box in self.box_layout[1]:
                # inner_layout_str += str(box.id) + ' '
                inner_layout_str += '{:5} '.format(box.id)
            inner_layout_str_list = [inner_layout_str] * \
                (len(self.box_layout[1]) - 2)
            layout_str = top_layout_str + '\n'.join(inner_layout_str_list) + \
                top_layout_str
        l = self.base_doc.createElement('L')
        l.appendChild(self.base_doc.createTextNode(layout_str))
        modgeo.appendChild(l)
        modmat = self.base_doc.createElement('ModMat')
        modmat.setAttrs({'ID': '2', 'ModID': '2',
            'NumSubXs': str(numxs),
            'NumSubYs': str(numys)})
        l = self.base_doc.createElement('L')
        l.appendChild(self.base_doc.createTextNode(layout_str))
        modmat.appendChild(l)
        input_tag.insertBefore(modgeo, self.coregeo_tag)
        input_tag.insertBefore(modmat, self.coregeo_tag)

        basename = 'radialref_{}'.format(min(self.matlibid))
        gene_dir = os.path.join(const.lattice_dir, basename)
        ref_main_filename = basename + '-main.xml'
        os.makedirs(gene_dir, exist_ok=True)
        ref_main_file_str = self.base_doc.toprettyxml(indent='', newl='\n')
        ref_main_file_str_list = ref_main_file_str.splitlines(keepends=True)
        ref_main_file_str_list = [i
                for i in ref_main_file_str_list if i != '\n']
        ref_main_file_str = ''.join(ref_main_file_str_list)
        print('generate {}'.format(ref_main_filename))
        with open(os.path.join(gene_dir, ref_main_filename), 'w') as f:
            f.write(ref_main_file_str)

        statepoints = settings.get_ref_statepoints()
        branch_statepoints = []
        main_cb, main_tf, main_tm = (float(self.main_cb),
                float(self.main_tf), float(self.main_tm))
        for statepoint in statepoints:
            if statepoint[const.CB] == main_cb and \
                    statepoint[const.TF] == main_tf and \
                    statepoint[const.TM] == main_tm:
                continue
            branch_statepoints.append(statepoint)

        if len(branch_statepoints) == 0:
            return

        for branch_num in range(1,
                len(branch_statepoints)//const.stpnum + 2):
            stps = branch_statepoints[(branch_num-1)*const.stpnum:
                    branch_num*const.stpnum]
            main_doc = dom.parse(os.path.join(gene_dir, ref_main_filename))
            input_tag = main_doc.documentElement
            restart_node = main_doc.getElementsByTagName('restart')[0]
            input_node = main_doc.getElementsByTagName('input')[0]
            input_node.removeChild(restart_node)
            for stp in stps:
                new_restart = main_doc.createElement('restart')
                new_restart.setAttribute('begin', 'yes')
                leakage = element_to_node(settings.get_ref_leakage(),
                        main_doc)
                depletion = main_doc.createElement('depletion')
                depletion.setAttribute('power', str(self.power))
                burnstep = main_doc.createElement('BurnStep')
                burnstep.appendChild(main_doc.createTextNode(
                    str(stp[const.BU])))
                depletion.appendChild(burnstep)
                linkpara = main_doc.createElement('LinkPara')
                linkpara.setAttrs({'ControlRod': self.controlrod,
                    'TFU': str(stp[const.TF]),
                    'TMO': str(stp[const.TM]),
                    'BOR': str(stp[const.CB])})
                if stp[const.CB] != self.main_cb or \
                        stp[const.TM] != self.main_tm:
                    mod_material = main_doc.createElement('material')
                    mod_material.setAttrs({'ID': str(const.ModeratorID),
                        'temperature': str(stp[const.TM]),
                        'BOR': str(stp[const.CB]),
                        'pressure': str(self.moderator_tag.getAttribute(
                            'pressure')),
                        'ResetAll': 'yes'})
                    new_restart.appendChild(mod_material)
                new_restart.appendChildren([leakage, depletion, linkpara])
                input_node.appendChild(new_restart)

            branch_file_str = main_doc.toprettyxml(indent='', newl='\n')
            branch_file_str_list = branch_file_str.splitlines(keepends=True)
            branch_file_str_list = [i
                    for i in branch_file_str_list if i != '\n']
            branch_file_str = ''.join(branch_file_str_list)
            filename = basename + '-branch{}.xml'.format(branch_num)
            print('generate {}'.format(filename))
            with open(os.path.join(gene_dir, filename), 'w') as f:
                f.write(branch_file_str)

    def __repr__(self):
        return 'RadialRef({!r})'.format(self.id)
