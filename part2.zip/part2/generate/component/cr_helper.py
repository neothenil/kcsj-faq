from .. import const


messy_data = None


def get_messy_data(config, statepoints):
    global messy_data
    if messy_data is None:
        messy_data = _get_messy_data(config, statepoints)
    return messy_data


def _get_messy_data(config, statepoints):
    bctt = bu_cb_tf_tm(statepoints)
    segments = read_config(config)
    len_string_list = []
    pair_string_list = []
    for seg in segments:
        seg.attach(*bctt)
        term1, term2, term3 = seg.gen_terms(statepoints)
        term1_pairs = get_data_pairs(term1)
        term2_pairs = get_data_pairs(term2)
        term3_pairs = get_data_pairs(term3)
        len_string = '{} {} {}'.format(len(term1_pairs),
                len(term2_pairs), len(term3_pairs))
        len_string_list.append(len_string)
        pair_string = ""
        for pair in term1_pairs:
            pair_string += '{} {}  '.format(pair[0], pair[1])
        pair_string_list.append(pair_string)
        pair_string = ""
        for pair in term2_pairs:
            pair_string += '{} {}  '.format(pair[0], pair[1])
        pair_string_list.append(pair_string)
        pair_string = ""
        for pair in term3_pairs:
            pair_string += '{} {}  '.format(pair[0], pair[1])
        pair_string_list.append(pair_string)
    return len_string_list + pair_string_list


class Segment:
    def __init__(self, bu_pair, cb_pair, tf_pair, tm_pair,
                 typical_bu, typical_cb, typical_tf, typical_tm):
        assert bu_pair[0] <= typical_bu <= bu_pair[1]
        assert cb_pair[0] <= typical_cb <= cb_pair[1]
        assert tf_pair[0] <= typical_tf <= tf_pair[1]
        assert tm_pair[0] <= typical_tm <= tm_pair[1]
        self.bu_slice = slice(bu_pair[0]-1, bu_pair[1])
        self.cb_slice = slice(cb_pair[0]-1, cb_pair[1])
        self.tf_slice = slice(tf_pair[0]-1, tf_pair[1])
        self.tm_slice = slice(tm_pair[0]-1, tm_pair[1])
        self.typical_bu = typical_bu
        self.typical_cb = typical_cb
        self.typical_tf = typical_tf
        self.typical_tm = typical_tm

    def attach(self, bu, cb, tf, tm):
        self.max_bu = max(bu[self.bu_slice])
        self.min_bu = min(bu[self.bu_slice])
        self.max_cb = max(cb[self.cb_slice])
        self.min_cb = min(cb[self.cb_slice])
        self.max_tf = max(tf[self.tf_slice])
        self.min_tf = min(tf[self.tf_slice])
        self.max_tm = max(tm[self.tm_slice])
        self.min_tm = min(tm[self.tm_slice])
        self.typical_bu = bu[self.typical_bu-1]
        self.typical_cb = cb[self.typical_cb-1]
        self.typical_tf = tf[self.typical_tf-1]
        self.typical_tm = tm[self.typical_tm-1]

    def gen_terms(self, statepoints):
        term1_strings = []
        term2_strings = []
        term3_strings = []
        for nr, stp in enumerate(statepoints, 1):
            data = list(stp)
            bu = data[const.BU]
            cb = data[const.CB]
            tf = data[const.TF]
            tm = data[const.TM]
            if self.min_bu <= bu <= self.max_bu and \
               self.min_cb <= cb <= self.max_cb and \
               tf == self.typical_tf and \
               tm == self.typical_tm:
                string = "{} {}".format(nr, stp)
                term1_strings.append(string)
            if self.min_tf <= tf <= self.max_tf and \
               bu == self.typical_bu and \
               cb == self.typical_cb and \
               tm == self.typical_tm:
                string = "{} {}".format(nr, stp)
                term2_strings.append(string)
            if self.min_cb <= cb <= self.max_cb and \
               self.min_tm <= tm <= self.max_tm and \
               bu == self.typical_bu and \
               tf == self.typical_tf:
                string = "{} {}".format(nr, stp)
                term3_strings.append(string)
        return term1_strings, term2_strings, term3_strings


def read_config(config):
    num_segment = int(config[0].split()[0])
    segment_list = []
    for i in range(1, num_segment+1):
        segment_config1 = list(map(int, config[i].split()))
        segment_config2 = list(map(int, config[i+num_segment].split()))
        bu_pair = (segment_config1[0], segment_config1[1])
        cb_pair = (segment_config1[2], segment_config1[3])
        tf_pair = (segment_config1[4], segment_config1[5])
        tm_pair = (segment_config1[6], segment_config1[7])
        typical_bu = segment_config2[0]
        typical_cb = segment_config2[1]
        typical_tf = segment_config2[2]
        typical_tm = segment_config2[3]
        seg = Segment(bu_pair, cb_pair, tf_pair, tm_pair,
                      typical_bu, typical_cb, typical_tf, typical_tm)
        segment_list.append(seg)
    return segment_list


def bu_cb_tf_tm(statepoints):
    bu = []
    cb = []
    tf = []
    tm = []
    for stp in statepoints:
        if stp[const.BU] not in bu:
            bu.append(stp[const.BU])
        if stp[const.CB] not in cb:
            cb.append(stp[const.CB])
        if stp[const.TF] not in tf:
            tf.append(stp[const.TF])
        if stp[const.TM] not in tm:
            tm.append(stp[const.TM])
    bu.sort()
    cb.sort()
    tf.sort()
    tm.sort()
    return bu, cb, tf, tm


def get_data_pairs(term_string_list):
    old_num_state_point = -1
    num_min = num_max = 0
    data_pairs = []
    for data_point in term_string_list:
        li_data = data_point.split()
        num_state_point = int(li_data[0])
        if num_state_point > old_num_state_point + 1:
            if num_min > 0 and num_max > 0:
                data_pairs.append((num_min, num_max))
            num_min = num_max = num_state_point
        elif num_state_point == old_num_state_point + 1:
            num_max += 1
        old_num_state_point = num_state_point
    else:
        if len(term_string_list) > 0:
            data_pairs.append((num_min, num_max))
    return data_pairs
