from .. import const
from ..errors import InputFileError

from . import Segment


class AssemblyEntity:
    """
    `AssemblyEntity` is composed of element entities. Attribute `entities`
    contains instances of `ElementEntity`, with each type in a fixed position.
    Attribute `model` is set later when all types in a core are already known.
    """

    def __init__(self, element_entities):
        self.entities = list(element_entities)
        self.model = None

    def __repr__(self):
        return 'AsEn'


class AssemblyType:

    def __init__(self, members, rotations):
        self.members = members     # A list of `ElementType` instance
        self.check_members()
        self.rotations = rotations
        # self.crinfo = crinfo
        # Set after invoking `rotate` method.
        self.rotated_segment_groups = []
        # Set by the core.
        self.positions = []
        # Set after combination.
        self.segments = []
        self.lattices = []
        # Set for control rod lattice.
        self.controlrod_lattices = []
        # Just for pretty display.
        self.id = None

    def set_cycle(self, cycle):
        self.cycle = cycle

    def check_members(self):
        fuel_height = self.members[const.FU].total_height
        # Suppose `const.FU` == 0 and `const.CR` == 4.
        for reader in self.members[1:4]:
            if reader is None:
                continue
            if reader.total_height != fuel_height:
                raise InputFileError('The total height of {!r} does'
                        'not match with {!r}'.format(reader.name,
                            self.members[const.FU].name))

    def rotate(self):
        """
        Set `rotated_segment_groups` and reverse the segments.
        """
        for reader, angle in zip(self.members, self.rotations):
            if reader is None:
                self.rotated_segment_groups.append(None)
                continue
            old_segments = reader.segments
            new_segments = []
            rotated_lattices = []
            for segment in reversed(old_segments):
                for lattice in rotated_lattices:
                    # If a same lattice has been rotated, use it directly.
                    if lattice.id == segment.lattice.id:
                        rotated_lattice = lattice
                        break
                else:
                    rotated_lattice = segment.lattice.rotate(angle)
                    rotated_lattices.append(rotated_lattice)
                new_segments.append(Segment(segment.height, rotated_lattice))
            new_segments = tuple(new_segments)
            self.rotated_segment_groups.append(new_segments)

    def combine(self, start_matlibid):
        """
        Combine lattices without control rod. First, rotate. Then, combine.
        """
        # Pre-processing
        abs_heights = set()
        segment_groups_without_cr = self.rotated_segment_groups[:4]
        for segment_group in segment_groups_without_cr:
            if segment_group is None:
                continue
            abs_height = 0.0
            for segment in segment_group:
                abs_height += segment.height
                abs_heights.add(abs_height)
                segment.abs_height = abs_height
        abs_heights = sorted(abs_heights)

        # Main logic
        lattice_groups_to_new_lattice = {}
        for i in range(len(abs_heights)):
            lattices_to_combine = []
            for segment in segment_groups_without_cr[const.FU]:
                if segment.abs_height >= abs_heights[i]:
                    lattices_to_combine.append(segment.lattice)
                    break
            for segment_group in segment_groups_without_cr[1:]:
                if segment_group is None:
                    lattices_to_combine.append(None)
                    continue
                for segment in segment_group:
                    if segment.abs_height >= abs_heights[i]:
                        lattices_to_combine.append(segment.lattice)
                        break
            assert len(lattices_to_combine) == 4
            lattices_to_combine = tuple(lattices_to_combine)
            if lattices_to_combine in lattice_groups_to_new_lattice:
                new_lattice = lattice_groups_to_new_lattice[
                        lattices_to_combine]
            else:
                new_lattice = lattices_to_combine[const.FU] + \
                    lattices_to_combine[const.AB] + \
                    lattices_to_combine[const.PG] + \
                    lattices_to_combine[const.DE]
                lattice_groups_to_new_lattice[lattices_to_combine] = \
                    new_lattice
            if i == 0:
                height = abs_heights[0]
            else:
                height = abs_heights[i] - abs_heights[i-1]
            self.segments.append(Segment(height, new_lattice, abs_heights[i]))

        # Post-processing
        if self.rotated_segment_groups[const.CR] is not None:
            matlibid_interval = len(self.rotated_segment_groups[const.CR]) + 1
        else:
            matlibid_interval = 1
        for segment in self.segments:
            if segment.lattice not in self.lattices:
                segment.lattice.matlibid = start_matlibid
                start_matlibid += matlibid_interval
                segment.lattice.set_id(self.members[:4], self.rotations[:4])
                segment.lattice.set_all_mats()
                segment.lattice.set_fuel_mats()
                segment.lattice.set_matid_map()
                segment.lattice.set_pins_location()
                self.lattices.append(segment.lattice)
        return start_matlibid

    def combine_controlrod(self):
        """
        Combine control rod after all the other lattices have been combined.
        """
        if self.members[const.CR] is None:
            return
        for lattice in self.lattices:
            matlibid = lattice.matlibid + 1
            for segment in self.rotated_segment_groups[const.CR]:
                cr_lattice = lattice + segment.lattice
                cr_lattice.matlibid = matlibid
                matlibid += 1
                cr_lattice.set_control_rod_id(self.members, self.rotations)
                cr_lattice.set_all_mats()
                cr_lattice.set_fuel_mats()
                cr_lattice.set_matid_map()
                cr_lattice.set_pins_location()
                self.controlrod_lattices.append(cr_lattice)

    def longest_lattice(self):
        longest_segment = max(self.segments, key=lambda x: x.height)
        return longest_segment.lattice

    def matlibid_at_height(self, height):
        if height > self.segments[-1].abs_height:
            raise InputFileError
        for segment in self.segments:
            if segment.abs_height >= height:
                return segment.lattice.matlibid

    def top_lattice(self):
        if not self.segments:
            raise AttributeError("`segments` attribute not set yet")
        return self.segments[-1].lattice

    def bottom_lattice(self):
        if not self.segments:
            raise AttributeError("`segments` attribute not set yet")
        return self.segments[0].lattice

    def calc_mass(self):
        """
        Calculate uranium mass in this asm_type. Unit: kg.
        """
        if hasattr(self, 'mass'):
            return self.mass
        mass = 0.0
        fuel_segments = self.members[const.FU].segments
        for segment in fuel_segments:
            height = segment.height
            mass_in_lattice = segment.lattice.calc_mass()
            mass += height * mass_in_lattice
        mass = mass/1000.
        self.mass = mass
        return mass

    def view_members(self):
        """Just for debug."""
        members = []
        for ele_type in self.members:
            if ele_type is None:
                members.append(None)
            else:
                members.append(ele_type.name)
        return members

    def __eq__(self, other):
        if not isinstance(other, AssemblyType):
            return False
        return self.members == other.members \
            and self.rotations == other.rotations

    def __repr__(self):
        return 'AsmType({}:{})'.format(self.cycle, self.id)
