from .. import const


def compare(all_lattices):
    """Given a list of `Lattice` instance, check the duplicated lattices,
    return a dictionary with the duplicated lattices as keys, the one
    should replace it as values.
    """
    duplicated = [False] * len(all_lattices)
    duplicated_dict = {}
    for i, lattice in enumerate(all_lattices):
        if duplicated[i] is False:
            duplicated_dict[lattice] = []
            for j in range(i, len(all_lattices)):
                if lattice == all_lattices[j]:
                    duplicated_dict[lattice].append(all_lattices[j])
                    if i != j:
                        duplicated[j] = True

    dup2one = {}
    for key, value in duplicated_dict.items():
        if len(value) == 1:
            continue
        for dup_lattice in value[1:]:
            dup2one[dup_lattice] = key
    return dup2one


def compare2(fixed_lattices, checked_lattices):
    """Given a fixed list of `Lattice` instance, check the duplicated lattices
    in `checked_lattices`, return a dictionary with the duplicated lattices as
    keys, the one should replace it as values.
    """
    duplicated_dict = {}
    for checked_lattice in checked_lattices:
        for old_lattice in fixed_lattices:
            if checked_lattice == old_lattice:
                duplicated_dict[checked_lattice] = old_lattice
                break
    return duplicated_dict


def update_asm_types(asm_types, dup2one):
    for asm_type in asm_types:
        new_lattices = []
        for lattice in asm_type.lattices:
            if lattice not in dup2one:
                new_lattices.append(lattice)
                continue
            target_lattice = dup2one[lattice]
            new_lattices.append(target_lattice)
        asm_type.lattices = new_lattices
        for segment in asm_type.segments:
            if segment.lattice not in dup2one:
                continue
            target_lattice = dup2one[segment.lattice]
            segment.lattice = target_lattice


def find_casual_continued(asm_types):
    """Find casual lattices and continued lattices. Returned casual lattices
    could have duplicated lattices because `extend` method of list is used to
    get the casual lattices.
    """
    casual_lattices = []
    continued_lattices = []
    for asm_type in asm_types:
        if asm_type.members[const.CR] is None:
            casual_lattices.extend(asm_type.lattices)
        else:
            cr_seg_num = len(asm_type.members[const.CR].segments)
            for i, lattice in enumerate(asm_type.lattices):
                continued_lattices.append(lattice)
                continued_lattices.extend(asm_type.controlrod_lattices[
                    i*cr_seg_num:(i+1)*cr_seg_num])
    return casual_lattices, continued_lattices


def casual_continued_ranges(asm_types):
    casual_lattices = []
    continued_lattices = []
    ranges = {}
    start = end = 0
    for asm_type in asm_types:
        if asm_type.members[const.CR] is None:
            casual_lattices.extend(asm_type.lattices)
        else:
            end = start + len(asm_type.lattices+asm_type.controlrod_lattices)
            ranges[(asm_type.cycle, asm_type.id)] = (start, end)
            cr_seg_num = len(asm_type.members[const.CR].segments)
            for i, lattice in enumerate(asm_type.lattices):
                continued_lattices.append(lattice)
                continued_lattices.extend(asm_type.controlrod_lattices[
                    i*cr_seg_num:(i+1)*cr_seg_num])
            start = end
    return casual_lattices, continued_lattices, ranges


def uniq_casual_lattices(casual_lattices, continued_lattices):
    # Remove duplicated casual_lattices
    # Remove casual lattice appeared in continued_lattices
    new_casual_lattices = []
    for lattice in casual_lattices:
        if lattice not in new_casual_lattices and \
                lattice not in continued_lattices:
            new_casual_lattices.append(lattice)
    return new_casual_lattices


def update_id(casual_lattices, continued_lattices, core):
    core.next_matlibid = core.init_matlibid
    new_casual_lattices = uniq_casual_lattices(
            casual_lattices, continued_lattices)
    # Set matlibid and id for casual_lattices
    for lattice in new_casual_lattices:
        lattice.matlibid = core.next_matlibid
        lattice.set_id(None, None)
        core.next_matlibid += 1
    # Set matlibid and id for continued_lattices
    for lattice in continued_lattices:
        lattice.matlibid = core.next_matlibid
        lattice.set_id(None, None)
        core.next_matlibid += 1
    return new_casual_lattices, continued_lattices
