import os
import math
from collections import Counter

from .. import const
from .. import mesh_method
from ..errors import InputFileError

from . import (
    dom,
    element_to_node,
    Cluster,
    Lattice,
    AxialRef,
    RadialRef,
    AssemblyEntity,
    AssemblyType,
    compare,
    cr_helper
)


class Core:

    def __init__(self, inp, settings):
        self.inp = inp
        self.cycle = inp.cycle
        self.ref_top, self.ref_bot = inp.find_axialrefs()
        self.radial_ref = inp.find_radialref()
        self.settings = settings
        if inp.cycle > 1:
            self.init_matlibid = self.inp.archive['next_matlibid']
        else:
            self.init_matlibid = 1
        self.next_matlibid = self.init_matlibid
        #
        self.asm_types = []
        self.old_asm_types = []
        self.asm_entity_layout, self.asm_type_layout = self.set_asm_layout()
        #
        self.clusters = self.set_clusters()
        # Initial uranium mass in this core. Calculated before finding
        # duplicated assembly type. The value will be equal to the value
        # calculated after finding duplicated assemly type.
        self.mass = self.calc_mass()
        self.gap_width = self.set_gap_width()
        self.volume = self.set_volume()
        self.power = self.inp.power
        self.pressure = self.inp.pressure
        self.flow = self.inp.flow

    def set_asm_layout(self):
        """
        Set `asm_types` attribute.
        Return `asm_entity_layout` and `asm_type_layout`.
        """
        fuel_layout = self.inp.layouts[const.FU]
        absorber_layout = self.inp.layouts[const.AB]
        plug_layout = self.inp.layouts[const.PG]
        detector_layout = self.inp.layouts[const.DE]
        controlrod_layout = self.inp.layouts[const.CR]

        asm_entity_layout = []
        asm_type_layout = []
        asm_type_id = 1
        for i in range(len(fuel_layout)):
            asm_type_in_line = []
            asm_entity_in_line = []
            for j in range(len(fuel_layout[0])):
                if fuel_layout[i][j] is None:
                    asm_type_in_line.append(None)
                    asm_entity_in_line.append(None)
                    continue
                asm_members = [None]*5
                rotations = [0]*5
                asm_members[const.FU] = fuel_layout[i][j]
                asm_members[const.AB] = absorber_layout[i][j] \
                    if absorber_layout else None
                asm_members[const.PG] = plug_layout[i][j] \
                    if plug_layout else None
                asm_members[const.DE] = detector_layout[i][j] \
                    if detector_layout else None
                asm_members[const.CR] = controlrod_layout[i][j] \
                    if controlrod_layout else None
                members = []
                for asm in asm_members:
                    if asm is None:
                        members.append(None)
                        continue
                    members.append(asm.load())

                rotations[const.FU] = fuel_layout[i][j].rotation
                rotations[const.AB] = absorber_layout[i][j].rotation \
                    if absorber_layout and absorber_layout[i][j] else None
                rotations[const.PG] = plug_layout[i][j].rotation \
                    if plug_layout and plug_layout[i][j] else None
                rotations[const.DE] = detector_layout[i][j].rotation \
                    if detector_layout and detector_layout[i][j] else None
                rotations[const.CR] = controlrod_layout[i][j].rotation \
                    if controlrod_layout and controlrod_layout[i][j] else None

                # [2018-12-11] This block should be changed in future.
                for asm_type in self.asm_types:
                    if asm_type.members == members and \
                            asm_type.rotations == rotations:
                        new_asm_type = asm_type
                        break
                else:
                    new_asm_type = AssemblyType(members, rotations)
                    new_asm_type.id = asm_type_id
                    new_asm_type.set_cycle(self.cycle)
                    asm_type_id += 1
                    self.asm_types.append(new_asm_type)
                new_asm_type.positions.append((i, j))
                asm_type_in_line.append(new_asm_type)
                new_asm_entity = AssemblyEntity(asm_members)
                new_asm_entity.model = new_asm_type
                asm_entity_in_line.append(new_asm_entity)
            asm_type_layout.append(asm_type_in_line)
            asm_entity_layout.append(asm_entity_in_line)
        return asm_entity_layout, asm_type_layout

    def set_clusters(self):
        if self.inp.layouts[const.CR] is None:
            return
        clusters = []
        for i in range(len(self.inp.layouts[const.CR])):
            for j in range(len(self.inp.layouts[const.CR][0])):
                asm = self.inp.layouts[const.CR][i][j]
                if asm is None:
                    continue
                for cluster in clusters:
                    if asm.cluster_id == cluster.id:
                        new_cluster = cluster
                        break
                else:
                    new_cluster = Cluster(asm.cluster_id, [],
                            asm.base, asm.step, asm.offset)
                    clusters.append(new_cluster)
                new_cluster.positions.append((i, j))
        return clusters

    def pretty_print(self):
        for asm_type_list in self.asm_type_layout:
            for asm_type in asm_type_list:
                if asm_type is None:
                    print('0', end='\t')
                else:
                    print('{}:{}'.format(asm_type.cycle, asm_type.id),
                          end='\t')
            print()

    def combine_asm_types(self):
        """
        Invoke `rotate` method in asm_type, then invoke `combine` method.  If
        there is control rod in this asm_type, then invoke `combine_controlrod`
        as well. After combining asm_types, check duplicated lattices in
        asm_types.
        """
        for asm_type in self.asm_types:
            asm_type.rotate()
            self.next_matlibid = asm_type.combine(self.next_matlibid)
            if asm_type.members[const.CR] is not None:
                asm_type.combine_controlrod()
        # Check duplicated lattice files here
        new_lattices = []
        for asm_type in self.asm_types:
            for lattice in asm_type.lattices:
                new_lattices.append(lattice)
            for cr_lattice in asm_type.controlrod_lattices:
                new_lattices.append(cr_lattice)
        dup2one = compare.compare(new_lattices)
        compare.update_asm_types(self.asm_types, dup2one)
        casual_lattices, continued_lattices = compare.find_casual_continued(
                self.asm_types)
        casual_lattices, continued_lattices = compare.update_id(
                casual_lattices, continued_lattices, self)
        self.new_lattices = casual_lattices + continued_lattices
        # End check

    def update_ref_matlibid(self):
        """Update `matlibid` attribute of reflectors."""
        # Do not change matlibid if the reflector is not new. A new reflector
        # can be identified by testing if the matlibid attribute equal to 0.
        if self.ref_top is not None and self.ref_top.matlibid == 0:
            self.ref_top.matlibid = self.next_matlibid
            self.ref_top.set_id()
            self.next_matlibid += 1
        if self.ref_bot is not None and self.ref_bot.matlibid == 0:
            self.ref_bot.matlibid = self.next_matlibid
            self.ref_bot.set_id()
            self.next_matlibid += 1
        if self.radial_ref is not None and self.radial_ref.matlibid == 0:
            # Index 0: radialrefH1
            # Index 1: radialrefH4
            # Index 2: radialrefH5
            self.radial_ref.matlibid = (self.next_matlibid,
                    self.next_matlibid+1, self.next_matlibid+2)
            self.radial_ref.set_id()
            self.next_matlibid += 3

    def calc_mass(self):
        """
        Calculate uranium mass in this core. Unit: kg.
        """
        mass = 0.0
        for asm_type in self.asm_types + self.old_asm_types:
            mass += asm_type.calc_mass() * len(asm_type.positions)
        self.mass = mass
        return mass

    def set_gap_width(self):
        pitch = self.inp.pitch
        asm_type = self.asm_types[0]
        lattice = asm_type.members[const.FU].lattices[0]
        lattice_size = lattice.pin_size * lattice.shape[0]
        gap_width = round((pitch - lattice_size) / 2.0, const.precision)
        if gap_width < 0.0:
            raise InputFileError('The core pitch is smaller than lattice size')
        return round(gap_width, const.precision)

    def set_volume(self):
        """
        Calculate total volume of fuel assembly in this core. Unit: m^3.
        """
        pitch = self.inp.pitch
        asm_type = self.asm_types[0]
        total_height = asm_type.members[const.FU].total_height
        one_volume = pitch**2*total_height
        asm_type_num = 0
        for asm_type in self.asm_types:
            asm_type_num += len(asm_type.positions)
        volume = asm_type_num * one_volume / 1e6
        return volume

    def generate_lattice_files(self):
        power = round(self.power/self.mass*1000.0, const.precision)
        for lattice in self.new_lattices:
            lattice.to_xml(self.settings, self.gap_width,
                    power, self.pressure)

    def most_asm_type(self):
        """
        Used in the process generating axial reflector files.
        """
        most_asm_type = max(self.asm_types+self.old_asm_types,
                key=lambda x: len(x.positions))
        return most_asm_type

    def edge_positions(self):
        results = []
        shape = (len(self.asm_type_layout), len(self.asm_type_layout[0]))
        if shape[0] <= 2 or shape[1] <= 2:
            for i in range(shape[0]):
                for j in range(shape[1]):
                    results.append((i, j))
            return results
        for index, asm in enumerate(self.asm_type_layout[0]):
            if asm is not None:
                results.append((0, index))
        for index, asm in enumerate(self.asm_type_layout[-1]):
            if asm is not None:
                results.append((shape[0] - 1, index))
        for index, asm_list in enumerate(self.asm_type_layout):
            if asm_list[0] is not None:
                results.append((index, 0))
            if asm_list[-1] is not None:
                results.append((index, shape[1] - 1))
        for line_num, asm_list in enumerate(self.asm_type_layout[1:-1], 1):
            for column_num, asm in enumerate(asm_list[1:-1], 1):
                if asm is not None and \
                        self.has_none_neighbor((line_num, column_num)):
                    results.append((line_num, column_num))
        return results

    def has_none_neighbor(self, position):
        detect_positions = [
                (position[0] - 1, position[1] - 1),
                (position[0] - 1, position[1]),
                (position[0] - 1, position[1] + 1),
                (position[0], position[1] - 1),
                (position[0], position[1] + 1),
                (position[0] + 1, position[1] - 1),
                (position[0] + 1, position[1]),
                (position[0] + 1, position[1] + 1)]
        for detect_position in detect_positions:
            if self.asm_type_layout[detect_position[0]][detect_position[1]] \
                    is None:
                return True
        return False

    def most_asm_type_at_edge(self):
        """
        Used in the process generating radial reflector files.
        """
        edge_positions = self.edge_positions()
        edge_asm_types = [self.asm_type_layout[position[0]][position[1]].id
                for position in edge_positions]
        edge_asm_type_counter = Counter(edge_asm_types)
        most_asm_type_id = edge_asm_type_counter.most_common(1)[0][0]
        for asm_type in self.asm_types + self.old_asm_types:
            if asm_type.id == most_asm_type_id:
                return asm_type

    def generate_reflector_files(self):
        most_asm_type = self.most_asm_type()
        # ref_top
        if self.ref_top is not None and \
                self.ref_top.matlibid > self.init_matlibid:
            most_lattice_at_top = most_asm_type.top_lattice()
            self.ref_top.place_with(most_lattice_at_top, self.settings)
            self.ref_top.to_xml(self.settings)
        # ref_bot
        if self.ref_bot is not None and \
                self.ref_bot.matlibid > self.init_matlibid:
            most_lattice_at_bottom = most_asm_type.bottom_lattice()
            self.ref_bot.place_with(most_lattice_at_bottom, self.settings)
            self.ref_bot.to_xml(self.settings)
        # radial_ref
        if self.radial_ref is not None and \
                max(self.radial_ref.matlibid) > self.init_matlibid:
            most_asm_type_at_edge = self.most_asm_type_at_edge()
            longest_lattice = most_asm_type_at_edge.longest_lattice()
            self.radial_ref.place_with(longest_lattice, self.settings,
                    self.gap_width)
            self.radial_ref.to_xml(self.settings, self.gap_width)

    def set_cr_mats(self, old_cr_mats):
        cr_mats = old_cr_mats.copy()
        new_mats = self.get_new_mats()
        cr_mats.extend(new_mats)
        self.cr_mats = cr_mats

    def get_new_mats(self):
        new_mats = self.new_lattices + self.get_new_ref()
        return new_mats

    def get_new_ref(self):
        new_ref = []
        if self.ref_top and \
                self.ref_top.matlibid > self.init_matlibid:
            new_ref.append(self.ref_top)
        if self.ref_bot and \
                self.ref_bot.matlibid > self.init_matlibid:
            new_ref.append(self.ref_bot)
        if self.radial_ref and \
                max(self.radial_ref.matlibid) > self.init_matlibid:
            new_ref.append(self.radial_ref)
        return new_ref

    def generate_readb(self):
        line_list = []
        fuel_statepoint_num = len(self.settings.get_fuel_statepoints())
        fuel_form = '{} {} 0'
        ref_statepoint_num = len(self.settings.get_ref_statepoints())
        for mat in self.cr_mats:
            if isinstance(mat, Lattice):
                line = fuel_form.format(mat.id, fuel_statepoint_num)
                line_list.append(line)
            elif isinstance(mat, RadialRef):
                for i in [1, 4, 5]:
                    line_list.append('{} {} {}'.format(
                        mat.id, ref_statepoint_num, i
                    ))
            elif isinstance(mat, AxialRef):
                if mat.typename == 'top':
                    line_list.append('{} {} 2'.format(mat.id,
                                     ref_statepoint_num))
                else:
                    line_list.append('{} {} 3'.format(mat.id,
                                     ref_statepoint_num))
            else:
                raise TypeError('unrecognizable type in `cr_mats`')
        most_asm_type = self.most_asm_type()
        lattice = most_asm_type.top_lattice()
        pinnum = lattice.shape[0]
        first_line = '{} {}'.format(len(line_list), pinnum)
        line_list.insert(0, first_line)
        str_lines = '\n'.join(line_list)
        os.makedirs(const.readb_dir, exist_ok=True)
        print('generate inp.dat for ReadBLattice')
        with open(os.path.join(const.readb_dir, 'inp.dat'), 'w') as f:
            f.write(str_lines)

    def generate_CR_XS(self, all_mats, is_fuel, statepoints):
        """Return a string containing text in CR_XS file."""
        line_list = []
        line_list.append(str(len(all_mats)))
        line_list.append(str(len(all_mats)) + '*UO2')
        line_list.append(str(len(all_mats)) + '*1')
        files_str = ''
        for file_name in all_mats:
            files_str += 'CX{} '.format(file_name)
        line_list.append(files_str)
        fuel_statepoint_num = len(self.settings.get_fuel_statepoints())
        ref_statepoint_num = len(self.settings.get_ref_statepoints())
        fuel_statepoint_str = str(fuel_statepoint_num) + ' '
        ref_statepoint_str = str(ref_statepoint_num) + ' '
        statepoint_str = ''
        for i in is_fuel:
            if i:
                statepoint_str += fuel_statepoint_str
            else:
                statepoint_str += ref_statepoint_str
        line_list.append(statepoint_str)
        line_list.append('--------------------------------------')
        # fuel repeat unit
        fuel_repeat_unit = []
        cr_common = self.settings.get_fuel_cr_common()
        cr_common_list = cr_common.splitlines()
        fuel_repeat_unit.extend(cr_common_list)
        messy_data = cr_helper.get_messy_data(cr_common_list[2:], statepoints)
        fuel_repeat_unit.extend(messy_data)
        fuel_repeat_unit.append('--------------------------------------')
        fuel_repeat_unit.append('{} 0'.format(len(statepoints)))
        fuel_repeat_unit.append('--------------------------------------')
        cr_xs = self.settings.get_fuel_cr_xs()
        fuel_repeat_unit.extend(cr_xs.splitlines())
        # ref repeat unit
        ref_repeat_unit = []
        cr_common = self.settings.get_ref_cr_common()
        ref_repeat_unit.extend(cr_common.splitlines())
        cr_xs = self.settings.get_ref_cr_xs()
        ref_repeat_unit.extend(cr_xs.splitlines())
        # append to `line_list`
        for i in is_fuel:
            if i:
                line_list.extend(fuel_repeat_unit)
            else:
                line_list.extend(ref_repeat_unit)
        # the last line
        line_list.append('0 1')
        return '\n'.join(line_list)

    def generate_CR_KIN(self, all_mats, is_fuel, statepoints):
        """Return a string containing text in CR_KIN file."""
        line_list = []
        line_list.append(str(len(all_mats)))
        line_list.append(str(len(all_mats)) + '*UO2')
        line_list.append(str(len(all_mats)) + '*1')
        files_str = ''
        for file_name in all_mats:
            files_str += 'CK{} '.format(file_name)
        line_list.append(files_str)
        fuel_statepoint_num = len(self.settings.get_fuel_statepoints())
        ref_statepoint_num = len(self.settings.get_ref_statepoints())
        fuel_statepoint_str = str(fuel_statepoint_num) + ' '
        ref_statepoint_str = str(ref_statepoint_num) + ' '
        statepoint_str = ''
        for i in is_fuel:
            if i:
                statepoint_str += fuel_statepoint_str
            else:
                statepoint_str += ref_statepoint_str
        line_list.append(statepoint_str)
        line_list.append('--------------------------------------')
        # fuel repeat unit
        fuel_repeat_unit = []
        cr_common = self.settings.get_fuel_cr_common()
        cr_common_list = cr_common.splitlines()
        fuel_repeat_unit.extend(cr_common_list)
        messy_data = cr_helper.get_messy_data(cr_common_list[2:], statepoints)
        fuel_repeat_unit.extend(messy_data)
        fuel_repeat_unit.append('--------------------------------------')
        fuel_repeat_unit.append('{} 0'.format(len(statepoints)))
        fuel_repeat_unit.append('--------------------------------------')
        cr_kin = self.settings.get_fuel_cr_kin()
        fuel_repeat_unit.extend(cr_kin.splitlines())
        # ref repeat unit
        ref_repeat_unit = []
        cr_common = self.settings.get_ref_cr_common()
        ref_repeat_unit.extend(cr_common.splitlines())
        cr_kin = self.settings.get_ref_cr_kin()
        ref_repeat_unit.extend(cr_kin.splitlines())
        # append to `line_list`
        for i in is_fuel:
            if i:
                line_list.extend(fuel_repeat_unit)
            else:
                line_list.extend(ref_repeat_unit)
        # the last line
        line_list.append('0 1')
        return '\n'.join(line_list)

    def generate_CR_FORM(self, all_mats, is_fuel, statepoints):
        """Return a string containing text in CR_FORM file."""
        line_list = []
        line_list.append(str(len(all_mats)))
        line_list.append(str(len(all_mats)) + '*UO2')
        line_list.append(str(len(all_mats)) + '*1')
        files_str = ''
        for file_name in all_mats:
            files_str += 'CF{} '.format(file_name)
        line_list.append(files_str)
        fuel_statepoint_num = len(self.settings.get_fuel_statepoints())
        ref_statepoint_num = len(self.settings.get_ref_statepoints())
        fuel_statepoint_str = str(fuel_statepoint_num) + ' '
        ref_statepoint_str = str(ref_statepoint_num) + ' '
        statepoint_str = ''
        for i in is_fuel:
            if i:
                statepoint_str += fuel_statepoint_str
            else:
                statepoint_str += ref_statepoint_str
        line_list.append(statepoint_str)
        line_list.append('--------------------------------------')
        # fuel repeat unit
        fuel_repeat_unit = []
        cr_common = self.settings.get_fuel_cr_common()
        cr_common_list = cr_common.splitlines()
        fuel_repeat_unit.extend(cr_common_list)
        messy_data = cr_helper.get_messy_data(cr_common_list[2:], statepoints)
        fuel_repeat_unit.extend(messy_data)
        fuel_repeat_unit.append('--------------------------------------')
        fuel_repeat_unit.append('{} 0'.format(len(statepoints)))
        fuel_repeat_unit.append('--------------------------------------')
        cr_form = self.settings.get_fuel_cr_form()
        most_asm_type = self.most_asm_type()
        lattice = most_asm_type.top_lattice()
        pinnum = math.ceil(lattice.shape[0])
        cr_form = cr_form.format(pinnum**2, 2*pinnum**2)
        fuel_repeat_unit.extend(cr_form.splitlines())
        # ref repeat unit
        ref_repeat_unit = []
        cr_common = self.settings.get_ref_cr_common()
        ref_repeat_unit.extend(cr_common.splitlines())
        cr_form = self.settings.get_ref_cr_form()
        ref_repeat_unit.extend(cr_form.splitlines())
        # append to `line_list`
        for i in is_fuel:
            if i:
                line_list.extend(fuel_repeat_unit)
            else:
                line_list.extend(ref_repeat_unit)
        # the last line
        line_list.append('0 1')
        return '\n'.join(line_list)

    def get_mats_str(self):
        all_mats = []
        is_fuel = []
        for mat in self.cr_mats:
            if isinstance(mat, Lattice):
                all_mats.append(mat.id)
                is_fuel.append(True)
            elif isinstance(mat, RadialRef):
                for i in [1, 4, 5]:
                    all_mats.append(mat.id + 'H{}'.format(i))
                    is_fuel.append(False)
            elif isinstance(mat, AxialRef):
                if mat.typename == 'top':
                    all_mats.append(mat.id + 'H2')
                    is_fuel.append(False)
                else:
                    all_mats.append(mat.id + 'H3')
                    is_fuel.append(False)
            else:
                raise TypeError('unrecognizable type in `cr_mats`')
        return all_mats, is_fuel

    def generate_cr(self):
        # preprocess
        all_mats, is_fuel = self.get_mats_str()
        statepoints = self.settings.get_fuel_statepoints()
        main_statepoints = []
        branch_statepoints = []
        for statepoint in statepoints:
            if statepoint[const.CB] == self.settings.fuel_cb and \
                    statepoint[const.TF] == self.settings.fuel_tf and \
                    statepoint[const.TM] == self.settings.fuel_tm:
                main_statepoints.append(statepoint)
            else:
                branch_statepoints.append(statepoint)
        main_statepoints.sort(key=lambda x: x[const.BU])
        statepoints = main_statepoints + branch_statepoints
        # write to files
        os.makedirs(const.core_dir, exist_ok=True)
        print('generate CR files')
        with open(os.path.join(const.core_dir, 'CR_XS'), 'w') as f:
            f.write(self.generate_CR_XS(all_mats, is_fuel, statepoints))
        with open(os.path.join(const.core_dir, 'CR_KIN'), 'w') as f:
            f.write(self.generate_CR_KIN(all_mats, is_fuel, statepoints))
        with open(os.path.join(const.core_dir, 'CR_FORM'), 'w') as f:
            f.write(self.generate_CR_FORM(all_mats, is_fuel, statepoints))

    def a_lattice(self):
        asm_type = (self.asm_types + self.old_asm_types)[0]
        lattice = asm_type.top_lattice()
        return lattice

    def get_flabels(self, fuel_layout, clen):
        format_str = '{:>%d}' % clen
        place_holder = '0'*clen
        result = []
        for line in fuel_layout:
            tmp = []
            for asm in line:
                if asm is None:
                    tmp.append(place_holder)
                    continue
                tmp.append(format_str.format(asm.name))
            result.append(tmp)
        return result

    def mesh_in_axial(self):
        fixed_points = []
        for asm_type in self.asm_types + self.old_asm_types:
            fixed_points.extend([seg.abs_height for seg in asm_type.segments])
        fixed_points = sorted(set(fixed_points))
        return mesh_method.mesh_from_list(fixed_points, const.ABML)

    def get_detcon(self):
        detcon_list = []
        for asm_type_line in self.asm_type_layout:
            tmp_list = []
            for asm_type in asm_type_line:
                if asm_type is None:
                    tmp_list.append('0')
                    continue
                if asm_type.members[const.DE] is not None:
                    tmp_list.append('1')
                else:
                    tmp_list.append('0')
            detcon_list.append(tmp_list)
        if not self.radial_ref:
            return detcon_list
        modified_detcon_list = []
        length = len(self.asm_type_layout[0]) + 2
        modified_detcon_list.append(['0'] * length)
        for detcon_line in detcon_list:
            modified_detcon_list.append(['0'] + detcon_line + ['0'])
        modified_detcon_list.append(['0'] * length)
        return modified_detcon_list

    def get_cr_layout(self):
        cr_layout = [[0]*len(self.asm_type_layout[0]) for i in range(
            len(self.asm_type_layout))]
        for cluster in self.clusters:
            old_id = self.inp.cluster_map[cluster.id]
            for position in cluster.positions:
                cr_layout[position[0]][position[1]] = old_id
        if not self.radial_ref:
            return cr_layout
        modified_cr_layout = []
        length = len(self.asm_type_layout[0]) + 2
        modified_cr_layout.append([0] * length)
        for detcon_line in cr_layout:
            modified_cr_layout.append([0] + detcon_line + [0])
        modified_cr_layout.append([0] * length)
        return modified_cr_layout

    def cr_max_step(self, calc_worth_matrix):
        max_step = 0
        for line in calc_worth_matrix:
            max_step_str = max(line, key=int)
            if max_step < int(max_step_str):
                max_step = int(max_step_str)
        return max_step

    def get_pcr_info(self, sorted_clusters, max_step, ref_height):
        pcr_info = []
        for cluster in sorted_clusters:
            min_height = round(ref_height + cluster.base, const.precision)
            cluster.abs_base = min_height
            max_height = round(min_height + max_step * cluster.step,
                    const.precision)
            pcr_info.append([min_height, max_height])
        return pcr_info

    def get_pcro_info(self, sorted_clusters):
        pcro_info = []
        control_matrix = self.inp.get_control()
        for i in range(1, len(control_matrix)+1):
            line = [i]
            for j in range(len(control_matrix[i-1])):
                abs_base = sorted_clusters[j].abs_base
                step = sorted_clusters[j].step
                line.append(round(float(control_matrix[i-1][j])*step+abs_base,
                    const.precision))
            pcro_info.append(line)
        return pcro_info

    def fuel_neighbors(self, position, layout):
        detect_positions = [
                (position[0] - 1, position[1] - 1),
                (position[0] - 1, position[1]),        # index 1
                (position[0] - 1, position[1] + 1),
                (position[0], position[1] - 1),        # index 3
                (position[0], position[1] + 1),        # index 4
                (position[0] + 1, position[1] - 1),
                (position[0] + 1, position[1]),        # index 6
                (position[0] + 1, position[1] + 1)]
        result = [False] * len(detect_positions)
        for index, detect_position in enumerate(detect_positions):
            try:
                asm_type = layout[detect_position[0]][detect_position[1]]
            except IndexError:
                pass
            else:
                result[index] = bool(asm_type)
        return result

    def mat_rot(self, fuel_neighbors):
        # up, down, left, right
        udlr = [fuel_neighbors[1], fuel_neighbors[6], fuel_neighbors[3],
                fuel_neighbors[4]]
        count = udlr.count(True)
        if count == 0:
            # The rotation is arbitrary
            return self.radial_ref.matlibid[const.H1], 1
        if count == 1:
            matlibid = self.radial_ref.matlibid[const.H4]
            if udlr[0]:
                rotation = 4
            elif udlr[1]:
                rotation = 2
            elif udlr[2]:
                rotation = 1
            elif udlr[3]:
                rotation = 3
            return matlibid, rotation
        if count == 2:
            matlibid = self. radial_ref.matlibid[const.H5]
            if udlr[1] and udlr[2]:
                rotation = 1
            elif udlr[1] and udlr[3]:
                rotation = 2
            elif udlr[0] and udlr[3]:
                rotation = 3
            elif udlr[0] and udlr[2]:
                rotation = 4
            else:
                raise InputFileError('error layout for radial reflector')
            return matlibid, rotation
        raise InputFileError('error layout for radial reflector')

    def ref_layout(self):
        asm_type_layout_with_ref = []
        asm_type_layout_with_ref.append(
                [None]*(len(self.asm_type_layout[0])+2))
        for line in self.asm_type_layout:
            asm_type_layout_with_ref.append([None]+line+[None])
        asm_type_layout_with_ref.append(
                [None]*(len(self.asm_type_layout[0])+2))
        ref_layout_info = {}
        for i in range(len(asm_type_layout_with_ref)):
            for j in range(len(asm_type_layout_with_ref[0])):
                position = (i, j)
                if asm_type_layout_with_ref[i][j] is None:
                    fuel_neighbors = self.fuel_neighbors(position,
                            asm_type_layout_with_ref)
                    if not any(fuel_neighbors):
                        continue
                    # position -> (matlibid, rotation)
                    # Note this position bases on `asm_type_layout_with_ref`.
                    # While `positions` attribute in `AssemblyType` bases on
                    # `asm_type_layout`.
                    ref_layout_info[(i, j)] = self.mat_rot(fuel_neighbors)
        return ref_layout_info

    def mat_layout_at_height(self, height):
        mat_layout = []
        for line in self.asm_type_layout:
            tmp = []
            for asm_type in line:
                if asm_type is None:
                    tmp.append(0)
                else:
                    tmp.append(
                        self.matlibid_to_coreid(
                            asm_type.matlibid_at_height(height),
                            asm_type))
            mat_layout.append(tmp)
        return mat_layout

    def matref_layout(self, mat_layout, ref_layout_info):
        if not self.radial_ref:
            return mat_layout
        matref_layout = []
        matref_layout.append([0]*(len(self.asm_type_layout[0])+2))
        for line in mat_layout:
            matref_layout.append([0] + line + [0])
        matref_layout.append([0]*(len(self.asm_type_layout[0])+2))
        for position, matrot in ref_layout_info.items():
            matref_layout[position[0]][position[1]] = self.matlibid_to_coreid(
                matrot[0], None)
        return matref_layout

    def ref_top_layout(self):
        if not self.ref_top:
            return [[]]
        matlibid = self.ref_top.matlibid
        coreid = self.matlibid_to_coreid(matlibid, None)
        one_line = [coreid] * (len(self.asm_type_layout[0])
                + (self.radial_ref and 2 or 0))
        layout = [one_line] * (len(self.asm_type_layout)
                + (self.radial_ref and 2 or 0))
        return layout

    def ref_bottom_layout(self):
        if not self.ref_bot:
            return [[]]
        matlibid = self.ref_bot.matlibid
        coreid = self.matlibid_to_coreid(matlibid, None)
        one_line = [coreid] * (len(self.asm_type_layout[0]) + 2)
        layout = [one_line] * (len(self.asm_type_layout) + 2)
        return layout

    def rotation_layout(self, ref_layout_info):
        rot_layout = []
        for line in self.asm_type_layout:
            tmp = []
            for asm_type in line:
                if asm_type is None:
                    tmp.append(0)
                else:
                    tmp.append(1)
            rot_layout.append(tmp)
        rotref_layout = []
        rotref_layout.append([0]*(len(self.asm_type_layout[0])+2))
        for line in rot_layout:
            rotref_layout.append([0] + line + [0])
        rotref_layout.append([0]*(len(self.asm_type_layout[0])+2))
        for position, matrot in ref_layout_info.items():
            rotref_layout[position[0]][position[1]] = matrot[1]
        return rotref_layout

    def layout2str(self, layout, form='{:3} '):
        result = ''
        format_str = form * len(layout[0]) + '\n'
        for line in layout:
            result += format_str.format(*line)
        return result

    def get_flow_layout(self, fuel_node_num):
        rated_flow = self.inp.flow
        flow_in_a_node = round(rated_flow/3.6/fuel_node_num, const.precision)
        flow_layout = []
        for line in self.asm_type_layout:
            tmp = []
            for asm_type in line:
                if asm_type is None:
                    tmp.append(0.0)
                else:
                    tmp.append(flow_in_a_node)
            flow_layout.append(tmp)
        flow_layout_with_ref = []
        flow_layout_with_ref.append([0.0] * (len(self.asm_type_layout[0])+2))
        for line in flow_layout:
            flow_layout_with_ref.append([0.0] + line + [0.0])
        flow_layout_with_ref.append([0.0] * (len(self.asm_type_layout[0])+2))
        return flow_layout_with_ref

    def get_nfpin_rod_gap_clad(self, lattice):
        all_pins = lattice.all_pins
        fuel_pins = []
        for pin in all_pins:
            nuclides_in_pin = []
            for mat in pin.mats:
                if mat is None:
                    continue
                nuclides_in_pin.extend(list(mat.nu_density))
            for nuclide in nuclides_in_pin:
                match_obj = const.uranium.match(nuclide)
                if match_obj is not None:
                    fuel_pins.append(pin)
                    break
        nfpin = 0
        for pin_line in lattice.layout:
            for pin in pin_line:
                if pin in fuel_pins:
                    nfpin += 1
        fuel_pin = fuel_pins[0]
        rod = fuel_pin.radii[0]
        gap = round(fuel_pin.radii[1] - fuel_pin.radii[0], const.precision)
        clad = round(fuel_pin.radii[2] - fuel_pin.radii[1], const.precision)
        return nfpin, rod, gap, clad

    def set_special_normal_dict(self):
        casual, continued, ranges = compare.casual_continued_ranges(
            self.asm_types + self.old_asm_types
        )
        casual = compare.uniq_casual_lattices(casual, continued)
        all_mats = casual + continued
        if self.ref_top:
            all_mats.append(self.ref_top)
        if self.ref_bot:
            all_mats.append(self.ref_bot)
        if self.radial_ref:
            all_mats.append(self.radial_ref)
        matid_list = []
        for mat in all_mats:
            if isinstance(mat, Lattice):
                matid_list.append(mat.matlibid)
            elif isinstance(mat, RadialRef):
                matid_list.extend(mat.matlibid)
            elif isinstance(mat, AxialRef):
                matid_list.append(mat.matlibid)
        # set `normal_dict`
        normal_dict = {matid: i+1 for i, matid in enumerate(matid_list)}
        self.normal_dict = normal_dict
        # update `ranges`
        for key in ranges:
            old_range = ranges[key]
            new_range = (old_range[0] + len(casual),
                         old_range[1] + len(casual))
            ranges[key] = new_range
        # set `special_dict`
        special_dict = {}
        for key in ranges:
            range = ranges[key]
            mats = matid_list[range[0]:range[1]]
            the_dict = {}
            start = range[0] + 1
            for mat in mats:
                the_dict[mat] = start
                start += 1
            special_dict[key] = the_dict
        self.special_dict = special_dict
        return matid_list

    def matlibid_to_coreid(self, matlibid, asm_type):
        if asm_type is None:
            return self.normal_dict[matlibid]
        key = (asm_type.cycle, asm_type.id)
        if key in self.special_dict:
            special_dict = self.special_dict[key]
            return special_dict[matlibid]
        return self.normal_dict[matlibid]

    #  TODO
    def convert_unit(self, _from, to, data):
        if _from in ['DB', 'DD']:
            return data
        raise NotImplementedError

    def to_xml(self):
        doc = dom.Document()
        inp = doc.createElement('input')
        # path
        path_tag = doc.createElement('path')
        lilac_tag = doc.createElement('LILAC')
        lilac_tag.appendChild(doc.createTextNode(
            self.settings.get_lilac_path()))
        path_tag.appendChild(lilac_tag)
        inp.appendChild(path_tag)
        # MatDef
        matdef_tag = doc.createElement('MatDef')
        matid_list = self.set_special_normal_dict()
        ref_num = 0
        if self.ref_top:
            ref_num += 1
        if self.ref_bot:
            ref_num += 1
        if self.radial_ref:
            ref_num += 3
        fuel_num = len(matid_list) - ref_num
        nm_tag = doc.createElement('NM')
        nm_tag.appendChild(doc.createTextNode(str(len(matid_list))))
        mtab_tag = doc.createElement('MTAB')
        mtab_str = '{}*1'.format(fuel_num)
        if ref_num > 0:
            mtab_str += ' {}*-1'.format(ref_num)
        mtab_tag.appendChild(doc.createTextNode(mtab_str))
        islink_tag = doc.createElement('IsLink')
        islink_tag.appendChild(doc.createTextNode(
                self.new_lattices and '1' or '0'))  # short-circuit evaluation
        matdef_tag.appendChildren([nm_tag, mtab_tag, islink_tag])
        inp.appendChild(matdef_tag)
        # GeoDef
        geodef_tag = element_to_node(self.settings.get_geodef(), doc)
        a_lattice = self.a_lattice()
        npst_str = str(a_lattice.shape[0])
        dxa_str = str(self.inp.pitch)
        most_asm_type = self.most_asm_type()
        hcore_str = str(most_asm_type.members[const.FU].total_height)
        npst_tag = doc.createElement('NPST')
        npst_tag.appendChild(doc.createTextNode(npst_str))
        dxa_tag = doc.createElement('DXA')
        dxa_tag.appendChild(doc.createTextNode(dxa_str))
        hcore_tag = doc.createElement('HCORE')
        hcore_tag.appendChild(doc.createTextNode(hcore_str))
        geodef_tag.appendChildren([npst_tag, dxa_tag, hcore_tag])
        inp.appendChild(geodef_tag)
        # NumAssembly
        fuel_layout = self.inp.layouts[const.FU]
        naxl_str = str(len(fuel_layout[0])+(self.radial_ref and 2 or 0))
        nayl_str = str(len(fuel_layout)+(self.radial_ref and 2 or 0))
        numassembly_tag = doc.createElement('NumAssembly')
        naxl_tag = doc.createElement('NAXL')
        naxl_tag.appendChild(doc.createTextNode(naxl_str))
        nayl_tag = doc.createElement('NAYL')
        nayl_tag.appendChild(doc.createTextNode(nayl_str))
        nax_tag = doc.createElement('NAX')
        nax_tag.appendChild(doc.createTextNode(naxl_str))
        nay_tag = doc.createElement('NAY')
        nay_tag.appendChild(doc.createTextNode(nayl_str))
        nmx_tag = doc.createElement('NMX')
        nmx_tag.appendChild(doc.createTextNode(naxl_str))
        nmy_tag = doc.createElement('NMY')
        nmy_tag.appendChild(doc.createTextNode(nayl_str))
        axial_mesh = self.mesh_in_axial()
        nmz_tag = doc.createElement('NMZ')
        if self.ref_top and self.ref_bot:
            nmz = len(axial_mesh) + 2
        elif self.ref_top or self.ref_bot:
            nmz = len(axial_mesh) + 1
        else:
            nmz = len(axial_mesh)
        nmz_tag.appendChild(doc.createTextNode(str(nmz)))
        asm_with_longest_name = max(self.inp.assemblies,
                key=lambda x: len(x.name))
        clen = len(asm_with_longest_name.name)
        clen_tag = doc.createElement('CLEN')
        clen_tag.appendChild(doc.createTextNode(str(clen)))
        numassembly_tag.appendChildren([naxl_tag, nayl_tag, nax_tag, nay_tag,
            nmx_tag, nmy_tag, nmz_tag, clen_tag])
        flabels = self.get_flabels(fuel_layout, clen)
        for flabel in flabels:
            flabel_tag = doc.createElement('FLABEL')
            name_str = ' '.join(flabel)
            flabel_tag.setAttribute('NAME', name_str)
            numassembly_tag.appendChild(flabel_tag)
        inp.appendChild(numassembly_tag)
        # Ref
        ref_tag = doc.createElement('Ref')
        numref_tag = doc.createElement('NumRef')
        numref_str = ''
        numref_str += (self.radial_ref and '1 ' or '0 ')
        numref_str += (self.ref_top and '1 ' or '0 ')
        numref_str += (self.ref_bot and '1' or '0')
        numref_tag.appendChild(doc.createTextNode(numref_str))
        bc_tag = doc.createElement('BC')
        bc_tag.appendChild(doc.createTextNode('-3 '*6))  # maybe wrong
        ref_tag.appendChildren([numref_tag, bc_tag])
        inp.appendChild(ref_tag)
        # NODELENGTH
        nodelength_tag = doc.createElement('NODELENGTH')
        hx_tag = doc.createElement('HX')
        hx_str = '{}*{}'.format(naxl_str, dxa_str)
        hx_tag.appendChild(doc.createTextNode(hx_str))
        hy_tag = doc.createElement('HY')
        hy_str = '{}*{}'.format(nayl_str, dxa_str)
        hy_tag.appendChild(doc.createTextNode(hy_str))
        modified_axial_mesh = [0.0] + axial_mesh
        mesh_length_list = [round(
            modified_axial_mesh[i]-modified_axial_mesh[i-1], const.precision)
            for i in range(1, len(axial_mesh)+1)]
        if self.ref_bot:
            mesh_length_list = [self.inp.pitch] + mesh_length_list
        if self.ref_top:
            mesh_length_list = mesh_length_list + [self.inp.pitch]
        hz_tag = doc.createElement('HZ')
        hz_str = ','.join(map(str, mesh_length_list))
        hz_tag.appendChild(doc.createTextNode(hz_str))
        lax_tag = doc.createElement('LAX')
        lax_str = '{}*1'.format(naxl_str)
        lax_tag.appendChild(doc.createTextNode(lax_str))
        lay_tag = doc.createElement('LAY')
        lay_str = '{}*1'.format(nayl_str)
        lay_tag.appendChild(doc.createTextNode(lay_str))
        lrx_tag = doc.createElement('LRX')
        lrx_tag.appendChild(doc.createTextNode(lax_str))
        lry_tag = doc.createElement('LRY')
        lry_tag.appendChild(doc.createTextNode(lay_str))
        lrz_tag = doc.createElement('LRZ')
        lrz_str = '{}*1'.format(len(mesh_length_list))
        lrz_tag.appendChild(doc.createTextNode(lrz_str))
        nodelength_tag.appendChildren([hx_tag, hy_tag, hz_tag, lax_tag,
            lay_tag, lrx_tag, lry_tag, lrz_tag])
        inp.appendChild(nodelength_tag)
        # REC
        rec_tag = element_to_node(self.settings.get_rec(), doc)
        npfx_tag = doc.createElement('NPFX')
        npfx_str = str(int(naxl_str)*a_lattice.shape[1])
        npfx_tag.appendChild(doc.createTextNode(npfx_str))
        npfy_tag = doc.createElement('NPFY')
        npfy_str = str(int(nayl_str)*a_lattice.shape[0])
        npfy_tag.appendChild(doc.createTextNode(npfy_str))
        npfz_tag = doc.createElement('NPFZ')
        npfz_str = str(len(mesh_length_list))
        npfz_tag.appendChild(doc.createTextNode(npfz_str))
        one_element_in_hpx = round(self.inp.pitch/a_lattice.shape[1],
                const.precision)
        hpx_tag = doc.createElement('HPX')
        hpx_str = '{}*{}'.format(npfx_str, one_element_in_hpx)
        hpx_tag.appendChild(doc.createTextNode(hpx_str))
        one_element_in_hpy = round(self.inp.pitch/a_lattice.shape[0],
                const.precision)
        hpy_tag = doc.createElement('HPY')
        hpy_str = '{}*{}'.format(npfy_str, one_element_in_hpy)
        hpy_tag.appendChild(doc.createTextNode(hpy_str))
        hpz_tag = doc.createElement('HPZ')
        hpz_tag.appendChild(doc.createTextNode(hz_str))
        npmx_tag = doc.createElement('NPMX')
        npmx_tag.appendChild(doc.createTextNode(npfx_str))
        npmy_tag = doc.createElement('NPMY')
        npmy_tag.appendChild(doc.createTextNode(npfy_str))
        npmz_tag = doc.createElement('NPMZ')
        npmz_tag.appendChild(doc.createTextNode(npfz_str))
        lpmx_tag = doc.createElement('LPMX')
        lpmx_tag.appendChild(doc.createTextNode('{}*1'.format(npfx_str)))
        lpmy_tag = doc.createElement('LPMY')
        lpmy_tag.appendChild(doc.createTextNode('{}*1'.format(npfy_str)))
        lpmz_tag = doc.createElement('LPMZ')
        lpmz_tag.appendChild(doc.createTextNode('{}*1'.format(npfz_str)))
        detcon = self.get_detcon()
        detcon_str = '\n'
        for detcon_line in detcon:
            detcon_str += ' '.join(detcon_line) + '\n'
        detcon_tag = doc.createElement('DETCON')
        detcon_tag.appendChild(doc.createTextNode(detcon_str))
        rec_tag.appendChildren([npfx_tag, npfy_tag, npfz_tag,
            hpx_tag, hpy_tag, hpz_tag, npmx_tag, npmy_tag, npmz_tag,
            lpmx_tag, lpmy_tag, lpmz_tag, detcon_tag])
        inp.appendChild(rec_tag)
        # BURNUP
        burnup_tag = element_to_node(self.settings.get_burnup(), doc)
        burn_step = self.inp.get_burn_step()
        xxpo_str = burn_step.text
        xxpo_list = xxpo_str.split()
        nxp_tag = doc.createElement('NXP')
        nxp_tag.appendChild(doc.createTextNode(str(len(xxpo_list))))
        xpo_tag = doc.createElement('XPO')
        xpo_tag.appendChild(doc.createTextNode('0'))
        fpth_tag = doc.createElement('FPTH')
        fpth_tag.appendChild(doc.createTextNode(str(self.power)))
        burn_tag = doc.createElement('BURN')
        xedays_tag = doc.createElement('XEDAYS')
        if burn_step.get('unit') in ['E', 'DE', 'B', 'DB']:
            xedays_tag.appendChild(doc.createTextNode('0'))
            converted_xxpo_list = self.convert_unit(burn_step.get('unit'),
                    'DB', [float(data) for data in xxpo_list])
        elif burn_step.get('unit') in ['H', 'DH', 'D', 'DD', 'Y', 'DY']:
            xedays_tag.appendChild(doc.createTextNode('1'))
            converted_xxpo_list = self.convert_unit(burn_step.get('unit'),
                    'DD', [float(data) for data in xxpo_list])
        xxpo_list = [str(data) for data in converted_xxpo_list]
        xxpo_tag = doc.createElement('XXPO')
        xxpo_tag.appendChild(doc.createTextNode(
            '\n'+'\n'.join(xxpo_list)+'\n'))
        fpdd_tag = doc.createElement('FPDD')
        fpdd_str = '{0}*3\n{0}*3'.format(len(xxpo_list))
        fpdd_tag.appendChild(doc.createTextNode(fpdd_str))
        depletion_power = self.inp.get_depletion_power()
        if depletion_power.get('unit') == 'MW':
            depletion_list = depletion_power.text.split()
            depletion_list = [round(float(power)/self.power, const.precision)
                    for power in depletion_list]
            pxpo_str = '\n'.join(map(str, depletion_list))
        else:
            pxpo_str = '\n'.join(depletion_power.text.split())
        pxpo_tag = doc.createElement('PXPO')
        pxpo_tag.appendChild(doc.createTextNode('\n'+pxpo_str+'\n'))
        cboro_tag = doc.createElement('CBORO')
        cboro_str = '{}*{}'.format(len(xxpo_list), self.inp.get_cb_init())
        cboro_tag.appendChild(doc.createTextNode(cboro_str))
        burnup_tag.appendChildren([nxp_tag, xpo_tag, fpth_tag, burn_tag,
            xedays_tag, xxpo_tag, fpdd_tag, pxpo_tag, cboro_tag])
        inp.appendChild(burnup_tag)
        # CONTROLROD
        controlrod_tag = element_to_node(self.settings.get_controlrod(), doc)
        ncr_tag = doc.createElement('NCR')
        ncr_tag.appendChild(doc.createTextNode(str(len(self.clusters))))
        cr_layout = self.get_cr_layout()
        kcr_str = '\n'
        for num_list in cr_layout:
            kcr_str += ' '.join(map(str, num_list)) + '\n'
        kcr_tag = doc.createElement('KCR')
        kcr_tag.appendChild(doc.createTextNode(kcr_str))
        nsch_tag = doc.createElement('NSCH')
        nsch_tag.appendChild(doc.createTextNode('2'))
        sorted_clusters = sorted(self.clusters,
                key=lambda x: self.inp.cluster_map[x.id])
        calc_worth = self.inp.get_calc_worth()
        max_step = self.cr_max_step(calc_worth)
        pcr_info = self.get_pcr_info(sorted_clusters, max_step, self.inp.pitch)
        pcr_str = '\n'
        for line in pcr_info:
            pcr_str += '{}, {}\n'.format(line[0], line[1])
        pcr_tag = doc.createElement('PCR')
        pcr_tag.appendChild(doc.createTextNode(pcr_str))
        pcro_info = self.get_pcro_info(sorted_clusters)
        pcro_str = '\n'
        for line in pcro_info:
            pcro_str += ', '.join(map(str, line)) + '\n'
        pcro_tag = doc.createElement('PCRO')
        pcro_tag.appendChild(doc.createTextNode(pcro_str))
        nstep_tag = doc.createElement('NSTEP')
        nstep_tag.appendChild(doc.createTextNode(str(max_step)))
        npass_tag = doc.createElement('NPASS')
        npass_tag.appendChild(doc.createTextNode(str(len(calc_worth))))
        secr_list = [str(self.inp.cluster_map[i])
                for i in self.inp.get_calc_worth_order()]
        secr_str = ' '.join(secr_list)
        secr_tag = doc.createElement('SECR')
        secr_tag.appendChild(doc.createTextNode(secr_str))
        notch_str = '\n'
        for nr, line in enumerate(calc_worth, 1):
            notch_str += str(nr) + ' ' + ' '.join(line) + '\n'
        notch_tag = doc.createElement('NOTCH')
        notch_tag.appendChild(doc.createTextNode(notch_str))
        npass2_tag = doc.createElement('NPASS2')
        npass2_tag.appendChild(doc.createTextNode(str(len(calc_worth))))
        secr2_tag = doc.createElement('SECR2')
        secr2_tag.appendChild(doc.createTextNode(secr_str))
        notch2_tag = doc.createElement('NOTCH2')
        notch2_tag.appendChild(doc.createTextNode(notch_str))
        controlrod_tag.appendChildren([ncr_tag, kcr_tag, nsch_tag, pcr_tag,
            pcro_tag, nstep_tag, npass_tag, secr_tag, notch_tag, npass2_tag,
            secr2_tag, notch2_tag])
        inp.appendChild(controlrod_tag)
        # MatArrange
        if self.radial_ref:
            ref_layout_info = self.ref_layout()
        else:
            ref_layout_info = {}
        mater_str = '\n'
        mater_str += self.layout2str(self.ref_top_layout())
        for height in axial_mesh[::-1]:
            mat_layout = self.mat_layout_at_height(height)
            mater_str += self.layout2str(self.matref_layout(mat_layout,
                ref_layout_info))
        mater_str += self.layout2str(self.ref_bottom_layout())
        mater_tag = doc.createElement('MATER')
        mater_tag.appendChild(doc.createTextNode(mater_str))
        mator_str = '\n'
        one_mator = self.layout2str(self.rotation_layout(ref_layout_info))
        if self.ref_top and self.ref_bot:
            repeat = len(axial_mesh) + 2
        elif self.ref_top or self.ref_bot:
            repeat = len(axial_mesh) + 1
        else:
            repeat = len(axial_mesh)
        mator_str += one_mator * repeat
        mator_tag = doc.createElement('MATOR')
        mator_tag.appendChild(doc.createTextNode(mator_str))
        matarrange_tag = doc.createElement('MatArrange')
        matarrange_tag.appendChildren([mater_tag, mator_tag])
        inp.appendChild(matarrange_tag)
        # MatToLib
        mattolib_tag = doc.createElement('MatToLib')
        nlib_tag = doc.createElement('NLIB')
        nlib_str = '\n'
        for coreid, matid in enumerate(matid_list, 1):
            nlib_str += '{} {}\n'.format(coreid, matid)
        nlib_tag.appendChild(doc.createTextNode(nlib_str))
        nminput_tag = doc.createElement('NMINPUT')
        mattolib_tag.appendChildren([nlib_tag, nminput_tag])
        inp.appendChild(mattolib_tag)
        # OTset
        otset_tag = element_to_node(self.settings.get_otset(), doc)
        asm_num = 0
        for asm_type in self.asm_types + self.old_asm_types:
            asm_num += len(asm_type.positions)
        height = (self.asm_types+self.old_asm_types)[0].members[const.FU].total_height
        density_u = round(self.mass/(asm_num*self.inp.pitch**2*height*1e-3),
                const.precision)
        tum_str = '{}*{} {}*0.0'.format(fuel_num, density_u, ref_num)
        tum_tag = doc.createElement('TUM')
        tum_tag.appendChild(doc.createTextNode(tum_str))
        kinetic_calc_point = self.inp.get_kinetic()[0]
        alpha_calc_point = self.inp.get_alpha()[0]
        crworth_calc_point = self.inp.get_crworth()[0]
        if self.cycle == 1:
            restart_type = 0
        else:
            restart_type = 2
        tcal_str = '{} {} {} {} 0 0'.format(
                len(kinetic_calc_point), len(alpha_calc_point),
                len(crworth_calc_point), restart_type)
        tcal_tag = doc.createElement('TCal')
        tcal_tag.appendChild(doc.createTextNode(tcal_str))
        otset_tag.appendChildren([tum_tag, tcal_tag])
        inp.appendChild(otset_tag)
        # Print
        print_tag = doc.createElement('Print')
        print_option = element_to_node(self.settings.get_core_print(), doc)
        print_option.tagName = 'PRINT'
        print_tag.appendChild(print_option)
        inp.appendChild(print_tag)
        # THERMAL
        thermal_tag = element_to_node(self.settings.get_thermal(), doc)
        nchtype_tag = doc.createElement('NCHTYPE')
        nchtype_tag.appendChild(doc.createTextNode('1'))
        tcoolin_str = self.inp.get_tempin()
        tcoolin_tag = doc.createElement('TCOOLIN')
        tcoolin_tag.appendChild(doc.createTextNode(tcoolin_str))
        flow_layout = self.get_flow_layout(asm_num)
        flow_str = '\n'
        flow_str += self.layout2str(flow_layout, '{:6.2f} ')
        flow_tag = doc.createElement('FLOW')
        flow_tag.appendChild(doc.createTextNode(flow_str))
        thermal_tag.appendChildren([nchtype_tag, tcoolin_tag, flow_tag])
        inp.appendChild(thermal_tag)
        # ThermalPass
        thermalpass_tag = element_to_node(self.settings.get_thermalpass(), doc)
        npin_str = str(a_lattice.shape[0]*a_lattice.shape[1])
        npin_tag = doc.createElement('NPIN')
        npin_tag.appendChild(doc.createTextNode(npin_str))
        nfpin, rod, gap, clad = self.get_nfpin_rod_gap_clad(a_lattice)
        pin_pitch = a_lattice.pin_size
        nfpin_tag = doc.createElement('NFPIN')
        nfpin_tag.appendChild(doc.createTextNode(str(nfpin)))
        pitch_tag = doc.createElement('PITCH')
        pitch_tag.appendChild(doc.createTextNode(str(pin_pitch)))
        rod_tag = doc.createElement('ROD')
        rod_tag.appendChild(doc.createTextNode(str(rod)))
        gap_tag = doc.createElement('GAP')
        gap_tag.appendChild(doc.createTextNode(str(gap)))
        clad_tag = doc.createElement('CLAD')
        clad_tag.appendChild(doc.createTextNode(str(clad)))
        channel_layout = []
        for line in flow_layout:
            tmp = []
            for value in line:
                if value == 0.0:
                    tmp.append(0)
                else:
                    tmp.append(1)
            channel_layout.append(tmp)
        channel_str = '\n'
        channel_str += self.layout2str(channel_layout)
        channel_tag = doc.createElement('CHANNEL')
        channel_tag.appendChild(doc.createTextNode(channel_str))
        thermalpass_tag.appendChildren([npin_tag, nfpin_tag, pitch_tag,
            rod_tag, gap_tag, clad_tag, channel_tag])
        inp.appendChild(thermalpass_tag)
        # KINETIC
        kinetic_tag = doc.createElement('KINETIC')
        calc_point, relative_power = self.inp.get_kinetic()
        ntxp_str = ' '.join(calc_point)
        ntxp_tag = doc.createElement('NTXP')
        ntxp_tag.appendChild(doc.createTextNode(ntxp_str))
        fv_tag = doc.createElement('FV')
        fv_tag.appendChild(doc.createTextNode('1'))
        nkp_tag = doc.createElement('NKP')
        nkp_tag.appendChild(doc.createTextNode(str(len(relative_power))))
        pkp_tag = doc.createElement('PKP')
        pkp_tag.appendChild(doc.createTextNode(' '.join(relative_power)))
        kinetic_tag.appendChildren([ntxp_tag, fv_tag, nkp_tag, pkp_tag])
        inp.appendChild(kinetic_tag)
        # REACTIVITY
        reactivity_tag = doc.createElement('REACTIVITY')
        calc_point, relative_power, offset_tu, offset_tm, offset_cb = \
            self.inp.get_alpha()
        nrep_tag = doc.createElement('NREP')
        nrep_tag.appendChild(doc.createTextNode(' '.join(calc_point)))
        nrp_tag = doc.createElement('NRP')
        nrp_tag.appendChild(doc.createTextNode(str(len(relative_power))))
        prp_tag = doc.createElement('PRP')
        prp_tag.appendChild(doc.createTextNode(' '.join(relative_power)))
        cdt_tag = doc.createElement('CDT')
        cdt_tag.appendChild(doc.createTextNode(' '.join(offset_tu)))
        cmt_tag = doc.createElement('CMT')
        cmt_tag.appendChild(doc.createTextNode(' '.join(offset_tm)))
        cbc_tag = doc.createElement('CBC')
        cbc_tag.appendChild(doc.createTextNode(' '.join(offset_cb)))
        reactivity_tag.appendChildren([nrep_tag, nrp_tag, prp_tag, cdt_tag,
            cmt_tag, cbc_tag])
        inp.appendChild(reactivity_tag)
        # CRODWORTH
        crodworth_tag = doc.createElement('CRODWORTH')
        calc_point, relative_power = self.inp.get_crworth()
        ncrp_tag = doc.createElement('NCRP')
        ncrp_tag.appendChild(doc.createTextNode(' '.join(calc_point)))
        ncp_tag = doc.createElement('NCP')
        ncp_tag.appendChild(doc.createTextNode(str(len(relative_power))))
        pcp_tag = doc.createElement('PCP')
        pcp_tag.appendChild(doc.createTextNode(' '.join(relative_power)))
        crodworth_tag.appendChildren([ncrp_tag, ncp_tag, pcp_tag])
        inp.appendChild(crodworth_tag)
        # write to file
        doc.appendChild(inp)
        os.makedirs(const.core_dir, exist_ok=True)
        filename = 'CORE-CYCLE{}.XML'.format(self.cycle)
        print('generate ' + filename)
        with open(os.path.join(const.core_dir, filename), 'w') as f:
            doc.writexml(f, newl='\n')

    def generate_core(self):
        self.to_xml()

    def generate_script(self):
        if self.cycle == 1:
            update_lilac = 'true'
            lattice = ''
        else:
            new_mats = self.get_new_mats()
            if new_mats:
                update_lilac = 'true'
                lattice = '-l ' + ' '.join([mat.id for mat in new_mats])
            else:
                update_lilac = 'false'
                lattice = ''
        cycle = str(self.cycle)

        sh_script_name = 'run.sh'
        sh_script = const.sh_template.format(update_lilac=update_lilac,
                lattice=lattice, cycle=cycle)
        print('generate run.sh')
        with open(sh_script_name, 'w') as f:
            f.write(sh_script)
        os.chmod(sh_script_name, 0o775)

        bat_script_name = 'run.bat'
        bat_script = const.bat_template.format(update_lilac=update_lilac,
                lattice=lattice, cycle=cycle)
        print('generate run.bat')
        with open(bat_script_name, 'w') as f:
            f.write(bat_script)
