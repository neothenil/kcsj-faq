import os

from .. import const
from ..errors import InputFileError

from . import element_to_node, dom


class Lattice:

    def __init__(self, id, pin_size, layout):
        self.id = str(id)
        self.pin_size = float(pin_size)
        self.layout = layout     # layout of pins
        self.shape = (len(self.layout), len(self.layout[0]))
        # Set after rotating and every combination step.
        self.members = [None]*5
        self.all_pins = self.find_all_pins()
        self.next_pinid = self.max_pinid() + 1
        # Set after all lattices have been combined.
        self.all_mats = []
        self.fuel_mats = []
        self.matid_map = {}
        self.matlibid = 0
        # Set after this lattice has been rotated.
        # Positions in this attribute is compatible with Bamboo-Lattice input
        # files, not just the indice in `layout`.
        self.detector_positions = []

    def __eq__(self, other):
        if not isinstance(other, Lattice):
            return False
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if self.layout[i][j] != other.layout[i][j]:
                    return False
        return True

    def __hash__(self):
        """Error-prone hash method."""
        return hash(id(self))

    def find_all_pins(self):
        pins = []
        for pin_list in self.layout:
            for pin in pin_list:
                if pin not in pins and pin is not None:
                    pin.pin_size = self.pin_size
                    pins.append(pin)
        return pins

    def max_pinid(self):
        if self.all_pins:
            pin_with_maxid = max(self.all_pins, key=lambda x: x.id)
            if pin_with_maxid.id >= 10000:
                raise InputFileError('pin id exceeds 10000')
            return pin_with_maxid.id
        else:
            return 0

    def rotate_90(self, layout):
        """
        Return the layout after rotating 90 degree.
        """
        new_layout = [[None]*len(layout) for i in range(len(layout[0]))]
        for i in range(len(layout[0])):
            for j in range(len(layout)):
                new_layout[i][j] = layout[len(layout)-j-1][i]
        return new_layout

    def rotate(self, angle):
        """
        Return a new `Lattice` instance after rotating `angle` degree.
        """
        if angle == 0:
            new_layout = [i.copy() for i in self.layout]
            new_lattice = Lattice(self.id, self.pin_size, new_layout)
        else:
            new_layout = [i.copy() for i in self.layout]
            for i in range(angle//90):
                new_layout = self.rotate_90(new_layout)
            new_lattice = Lattice(self.id, self.pin_size, new_layout)
        new_lattice.members = self.members.copy()
        if new_lattice.members[const.DE] is not None:
            for i in range(new_lattice.shape[0]):
                for j in range(new_lattice.shape[1]):
                    if new_lattice.layout[i][j] is not None:
                        new_lattice.detector_positions.append(
                                (new_lattice.shape[0]-i, j+1))
        return new_lattice

    def set_all_mats(self):
        for pin in self.all_pins:
            for mat in pin.mats:
                if mat not in self.all_mats and mat is not None:
                    self.all_mats.append(mat)

    def set_fuel_mats(self):
        for mat in self.all_mats:
            for alias, density in mat.nu_density.items():
                if const.uranium.match(alias):
                    self.fuel_mats.append(mat)
                    break

    def set_matid_map(self):
        intid = 1
        for mat in self.all_mats:
            self.matid_map[mat.id] = intid
            intid += 1

    def set_id(self, asm_type_members, rotations):
        """
        Invoking this method requires the `matlibid` attribute was set
        correctly.
        """
        self.id = 'fuel_' + str(self.matlibid)
        # new_id = '[{}]'.format(self.matlibid)
        # for lattice_id, asm_type, angle in zip(self.members,
        #         asm_type_members, rotations):
        #     if asm_type is None:
        #         new_id += '+'
        #     else:
        #         new_id += '{}#{}({})+'.format(
        #                   lattice_id, asm_type.name, angle)
        # self.id = new_id

    def set_control_rod_id(self, asm_type_members, rotations):
        self.id = 'fuel_' + str(self.matlibid)
        # new_id = '[{}]'.format(self.matlibid)
        # for lattice_id, asm_type, angle in zip(self.members,
        #         asm_type_members[:4], rotations):
        #     if asm_type is None:
        #         new_id += '+'
        #     else:
        #         new_id += '{}#{}({})+'.format(
        #                   lattice_id, asm_type.name, angle)
        # appended_id = '{}#{}({})'.format(self.members[const.CR],
        #         asm_type_members[const.CR].name, rotations[const.CR])
        # new_id += appended_id
        # self.id = new_id

    # May cause unexpected result because some pins are shared among different
    # lattices.
    def set_pins_location(self):
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if i == 0 and j == 0:
                    self.layout[i][j].location[const.LU] = True
                elif i == 0 and j == self.shape[1] - 1:
                    self.layout[i][j].location[const.RU] = True
                elif i == self.shape[0] - 1 and j == 0:
                    self.layout[i][j].location[const.LB] = True
                elif i == self.shape[0] - 1 and j == self.shape[1] - 1:
                    self.layout[i][j].location[const.RB] = True
                elif i == 0:
                    self.layout[i][j].location[const.UL] = True
                elif j == 0:
                    self.layout[i][j].location[const.LL] = True
                elif i == self.shape[0] - 1:
                    self.layout[i][j].location[const.BL] = True
                elif j == self.shape[1] - 1:
                    self.layout[i][j].location[const.RL] = True
                else:
                    self.layout[i][j].location[const.IN] = True

    def has_ifba(self):
        for pin in self.all_pins:
            if pin.pin_type == 'IFBA':
                return True
        return False

    def combine(self, other_lattice):
        """
        Return a combined new lattice.
        """
        if other_lattice is None:
            return self
        if self.pin_size != other_lattice.pin_size or \
                self.shape != other_lattice.shape:
            raise InputFileError('{} does not match with {}'.format(
                self, other_lattice))
        pin_pairs_to_combine = {}
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if other_lattice.layout[i][j] is not None:
                    pin_pairs_to_combine.setdefault(
                            (self.layout[i][j], other_lattice.layout[i][j]),
                            []).append((i, j))
        next_pinid = self.next_pinid
        new_layout = [i.copy() for i in self.layout]
        for pin_pairs, positions in pin_pairs_to_combine.items():
            new_pin = pin_pairs[0].combine(pin_pairs[1], next_pinid)
            next_pinid += 1
            for position in positions:
                new_layout[position[0]][position[1]] = new_pin
        new_lattice = Lattice(None, self.pin_size, new_layout)
        members = self.members.copy()
        for i in range(5):
            if other_lattice.members[i] is not None:
                members[i] = other_lattice.members[i]
        new_lattice.members = members
        if self.detector_positions:
            new_lattice.detector_positions = self.detector_positions
        if other_lattice.detector_positions:
            new_lattice.detector_positions = other_lattice.detector_positions
        return new_lattice

    def calc_mass(self):
        """
        Calculate uranium mass in unit axial length. Unit: g/cm.
        """
        if hasattr(self, 'mass'):
            return self.mass
        mass = 0.0
        for pin_list in self.layout:
            for pin in pin_list:
                if pin is None:
                    continue
                mass += pin.calc_mass()
        self.mass = mass
        return mass

    def sub_layout(self, gap_width):
        if gap_width == 0.0:
            layout = '\n'
            for pin_list in self.layout:
                for pin in pin_list:
                    layout += '{:5} '.format(pin.id)
                layout += '\n'
            return layout
        else:
            sub_layout = [[None]*self.shape[1] for i in range(self.shape[0])]
            for i, pin_list in enumerate(self.layout[1:-1], 1):
                for j, pin in enumerate(pin_list[1:-1], 1):
                    sub_layout[i][j] = '{:5}'.format(pin.id)
            for i, pin in enumerate(self.layout[-1][1:-1], 1):
                sub_layout[-1][i] = '{:5}'.format(pin.id+10000*const.BL)
            for i, pin_list in enumerate(self.layout[1:-1], 1):
                sub_layout[i][0] = '{:5}'.format(
                        pin_list[0].id+10000*const.LL)
                sub_layout[i][-1] = '{:5}'.format(
                        pin_list[-1].id+10000*const.RL)
            for i, pin in enumerate(self.layout[0][1:-1], 1):
                sub_layout[0][i] = '{:5}'.format(pin.id+10000*const.UL)
            sub_layout[0][0] = \
                '{:5}'.format(self.layout[0][0].id+10000*const.LU)
            sub_layout[0][-1] = \
                '{:5}'.format(self.layout[0][-1].id+10000*const.RU)
            sub_layout[-1][0] = \
                '{:5}'.format(self.layout[-1][0].id+10000*const.LB)
            sub_layout[-1][-1] = \
                '{:5}'.format(self.layout[-1][-1].id+10000*const.RB)
            sub_layout = [' '.join(i) for i in sub_layout]
            sub_layout = '\n' + '\n'.join(sub_layout) + '\n'
            return sub_layout

    def main_to_xml(self, settings, gap_width, power, pressure, test=False):
        """
        Generate Bamboo-Lattice main input files.
        """
        statepoints = settings.get_fuel_statepoints()
        main_burnup = []
        branch_statepoints = []
        for statepoint in statepoints:
            if statepoint[const.CB] == settings.fuel_cb and \
                    statepoint[const.TF] == settings.fuel_tf and \
                    statepoint[const.TM] == settings.fuel_tm:
                main_burnup.append(statepoint[const.BU])
            else:
                branch_statepoints.append(statepoint)
        if 0.0 in main_burnup:
            main_burnup.remove(0.0)
        main_burnup.sort()
        if not test:
            gene_dir = os.path.join(const.lattice_dir, self.id)
            # Info needed for generating branch input files.
            self.branch_statepoints = branch_statepoints
            self.gene_dir = gene_dir
        else:
            gene_dir = os.path.join(const.lattice_dir, 'test_'+self.id)

        doc = dom.Document()
        inp = doc.createElement('input')

        path = doc.createElement('path')
        for element in settings.get_db_path():
            node = element_to_node(element, doc)
            path.appendChild(node)
        inp.appendChild(path)

        settings_node = doc.createElement('settings')
        for element in settings.get_lattice_settings():
            node = element_to_node(element, doc)
            settings_node.appendChild(node)
        homo = settings.get_fuel_homo()
        settings_node.appendChild(element_to_node(homo, doc))
        if self.members[const.DE] is not None:
            for de_position in self.detector_positions:
                detector = doc.createElement('detector')
                row = str(de_position[0])
                col = str(de_position[1])
                numreg = settings.get_detector_numreg()
                detector.setAttrs({'row': row, 'col': col, 'NumReg': numreg})
                settings_node.appendChild(detector)
        linkpara = doc.createElement('LinkPara')
        if self.members[const.CR] is not None:
            controlrod = 'yes'
        else:
            controlrod = 'no'
        linkpara.setAttrs({'ControlRod': controlrod,
            'TFU': str(settings.fuel_tf),
            'TMO': str(settings.fuel_tm),
            'BOR': str(settings.fuel_cb)})
        settings_node.appendChild(linkpara)
        inp.appendChild(settings_node)

        for mat in self.all_mats:
            material = doc.createElement('material')
            if mat in self.fuel_mats:
                temperature = str(settings.fuel_tf)
            else:
                temperature = str(settings.fuel_tm)
            material.setAttrs({'ID': str(self.matid_map[mat.id]),
                'temperature': temperature})
            for alias, density in mat.nu_density.items():
                nuclide = doc.createElement('nuclide')
                nuclide.setAttrs({'alias': alias, 'density': str(density)})
                material.appendChild(nuclide)
            inp.appendChild(material)
        moderator_material = doc.createElement('material')
        moderator_material.setAttrs({'ID': str(const.ModeratorID),
            'temperature': str(settings.fuel_tm),
            'pressure': str(pressure),
            'BOR': str(settings.fuel_cb)})
        h2o = doc.createElement('nuclide')
        h2o.setAttrs({'alias': 'HinH2O', 'density': ''})
        o16 = doc.createElement('nuclide')
        o16.setAttrs({'alias': 'O16', 'density': ''})
        b10s = doc.createElement('nuclide')
        b10s.setAttrs({'alias': 'B10s', 'density': ''})
        b11s = doc.createElement('nuclide')
        b11s.setAttrs({'alias': 'B11s', 'density': ''})
        moderator_material.appendChildren([h2o, o16, b10s, b11s])
        inp.appendChild(moderator_material)

        for pin in self.all_pins:
            mesh_num_max = settings.get_max_mesh_num()
            mesh_num_min = settings.get_min_mesh_num()
            subgeos, submats = pin.to_subs(settings, gap_width,
                    self.matid_map, mesh_num_max, mesh_num_min, doc)
            for subgeo, submat in zip(subgeos, submats):
                inp.appendChildren([subgeo, submat])

        modgeo = doc.createElement('ModGeo')
        modgeo.setAttrs({'ID': '1', 'ModType': '1',
            'NumSubXs': str(self.shape[0]),
            'NumSubYs': str(self.shape[1])})
        l = doc.createElement('L')
        l.appendChild(doc.createTextNode(self.sub_layout(gap_width)))
        modgeo.appendChild(l)
        modmat = doc.createElement('ModMat')
        modmat.setAttrs({'ID': '1', 'ModID': '1',
            'NumSubXs': str(self.shape[0]),
            'NumSubYs': str(self.shape[1])})
        l = doc.createElement('L')
        l.appendChild(doc.createTextNode(self.sub_layout(gap_width)))
        modmat.appendChild(l)
        coregeo = doc.createElement('CoreGeo')
        coregeo.setAttrs({'NumModXs': '1', 'NumModYs': '1'})
        coremat = doc.createElement('CoreMat')
        coremat.setAttrs({'NumModXs': '1', 'NumModYs': '1'})
        l = doc.createElement('L')
        l.appendChild(doc.createTextNode('1'))
        coregeo.appendChild(l)
        l = doc.createElement('L')
        l.appendChild(doc.createTextNode('1'))
        coremat.appendChild(l)
        inp.appendChildren([modgeo, modmat, coregeo, coremat])

        if self.has_ifba():
            condition = element_to_node(settings.get_ifba_condition(), doc)
        else:
            condition = element_to_node(settings.get_fuel_condition(), doc)
        inp.appendChild(condition)

        depletion = doc.createElement('depletion')
        depletion.setAttribute('power', str(power))
        burnstep = doc.createElement('BurnStep')
        str_burnstep = '\n' + '\n'.join(map(str, main_burnup)) + '\n'
        burnstep.appendChild(doc.createTextNode(str_burnstep))
        depletion.appendChild(burnstep)
        inp.appendChild(depletion)

        restart = doc.createElement('restart')
        restart.setAttribute('begin', 'no')
        inp.appendChild(restart)

        leakage = element_to_node(settings.get_fuel_leakage(), doc)
        inp.appendChild(leakage)

        criterion = element_to_node(settings.get_fuel_criterion(), doc)
        inp.appendChild(criterion)

        condense = element_to_node(settings.get_condense(), doc)
        inp.appendChild(condense)

        print_option = element_to_node(settings.get_lattice_print(), doc)
        print_option.tagName = 'option'
        print_node = doc.createElement('print')
        print_node.appendChild(print_option)
        inp.appendChild(print_node)

        doc.appendChild(inp)

        os.makedirs(gene_dir, exist_ok=True)
        if not test:
            main_filename = self.id + '-main.xml'
            print('generate {}'.format(main_filename))
        else:
            main_filename = 'test_' + self.id + '-main.xml'
        with open(os.path.join(gene_dir, main_filename), 'w') as f:
            doc.writexml(f, newl='\n')

    def branch_to_xml(self, settings, gap_width, power, pressure):
        """
        Generate Bamboo-Lattice branch input files.
        """
        branch_statepoints = self.branch_statepoints
        gene_dir = self.gene_dir
        main_filename = self.id + '-main.xml'
        if len(branch_statepoints) == 0:
            return

        for branch_num in range(1,
                len(branch_statepoints)//const.stpnum + 2):
            stps = branch_statepoints[(branch_num-1)*const.stpnum:
                    branch_num*const.stpnum]
            main_doc = dom.parse(os.path.join(gene_dir, main_filename))
            restart_node = main_doc.getElementsByTagName('restart')[0]
            input_node = main_doc.getElementsByTagName('input')[0]
            input_node.removeChild(restart_node)
            for stp in stps:
                new_restart = main_doc.createElement('restart')
                new_restart.setAttribute('begin', 'yes')
                leakage = element_to_node(settings.get_fuel_leakage(),
                        main_doc)
                depletion = main_doc.createElement('depletion')
                depletion.setAttribute('power', str(power))
                burnstep = main_doc.createElement('BurnStep')
                burnstep.appendChild(main_doc.createTextNode(
                    str(stp[const.BU])))
                depletion.appendChild(burnstep)
                linkpara = main_doc.createElement('LinkPara')
                if self.members[const.CR] is not None:
                    controlrod = 'yes'
                else:
                    controlrod = 'no'
                linkpara.setAttrs({'ControlRod': controlrod,
                    'TFU': str(stp[const.TF]),
                    'TMO': str(stp[const.TM]),
                    'BOR': str(stp[const.CB])})
                if stp[const.CB] != settings.fuel_cb or \
                        stp[const.TM] != settings.fuel_tm:
                    mod_material = main_doc.createElement('material')
                    mod_material.setAttrs({'ID': str(const.ModeratorID),
                        'temperature': str(stp[const.TM]),
                        'BOR': str(stp[const.CB]),
                        'pressure': str(pressure),
                        'ResetAll': 'yes'})
                    new_restart.appendChild(mod_material)
                if stp[const.TF] != settings.fuel_tf:
                    for fuel in self.fuel_mats:
                        fuel_material = main_doc.createElement('material')
                        fuel_material.setAttrs({
                            'ID': str(self.matid_map[fuel.id]),
                            'temperature': str(stp[const.TF])})
                        new_restart.appendChild(fuel_material)
                new_restart.appendChildren([leakage, depletion, linkpara])
                input_node.appendChild(new_restart)

            branch_file_str = main_doc.toprettyxml(indent='', newl='\n')
            branch_file_str_list = branch_file_str.splitlines(keepends=True)
            branch_file_str_list = [i
                    for i in branch_file_str_list if i != '\n']
            branch_file_str = ''.join(branch_file_str_list)
            filename = self.id + '-branch{}.xml'.format(branch_num)
            print('generate {}'.format(filename))
            with open(os.path.join(gene_dir, filename), 'w') as f:
                f.write(branch_file_str)

    def to_xml(self, settings, gap_width, power, pressure):
        """
        Generate Bamboo-Lattice input files for both main and branch.
        """
        self.main_to_xml(settings, gap_width, power, pressure)
        self.branch_to_xml(settings, gap_width, power, pressure)

    def __add__(self, other):
        return self.combine(other)

    def __str__(self):
        layout = ''
        for pin_line in self.layout:
            line = ''
            for pin in pin_line:
                if pin is None:
                    line += '- '
                else:
                    line += str(pin.id) + ' '
            line += '\n'
            layout += line
        return layout

    def __repr__(self):
        return 'Lattice({!r})'.format(self.id)
