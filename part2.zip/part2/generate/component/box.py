from .. import const
from .. import mesh_method


class Box:
    """
    Data structure for a mesh in the reflector.
    """

    def __init__(self, dimensions, mats, width=None):
        assert len(dimensions) == len(mats)
        self.dimensions = dimensions
        self.mats = mats
        self.width = width

    def setid(self, int_id):
        if not isinstance(int_id, int):
            raise AttributeError
        self.id = int_id

    def is_square(self):
        return self.width is None or self.width == self.dimensions[-1]

    def to_sub(self, matid_map, doc):
        """
        Called after `id` has been set.
        """
        dims, mats = mesh_method.simple_mesh_box(self)
        if self.is_square():
            half_width = round(self.dimensions[-1]/2.0, const.precision)
            str_gaptype = '0'
            str_gapwidth = '0.0'
        else:
            half_width = min(round(self.dimensions[-1]/2.0, const.precision),
                    round(self.width/2.0, const.precision))
            if dims[-1] > self.width:
                str_gaptype = '4'
                str_gapwidth = str(round(dims[-1] - self.width,
                    const.precision))
            else:
                str_gaptype = '3'
                str_gapwidth = str(round(self.width - dims[-1],
                    const.precision))
        subgeo = doc.createElement('SubGeo')
        subgeo.setAttrs({'ID': str(self.id), 'SubType': '7',
            'HalfWidth': str(half_width),
            'NumLines1st': str(len(dims)),
            'NumLines2nd': str(len(dims))})
        angle = doc.createElement('Angle1st')
        angle.appendChild(doc.createTextNode('0'))
        ring = doc.createElement('Ring1st')
        ring.appendChild(doc.createTextNode('0'))
        gaptype = doc.createElement('GapType')
        gaptype.appendChild(doc.createTextNode(str_gaptype))
        gapwidth = doc.createElement('GapWidth')
        gapwidth.appendChild(doc.createTextNode(str_gapwidth))
        lines1st = doc.createElement('Lines1st')
        lines1st.appendChild(doc.createTextNode('\n' + '\n'
            .join(map(str, dims)) + '\n'))
        dims_y = [round(i/len(dims)*dims[-1], const.precision)
                for i in range(1, len(dims)+1)]
        if not self.is_square():
            dims_y[-1] = self.width
            assert dims_y[-1] > dims_y[-2]
        lines2nd = doc.createElement('Lines2nd')
        lines2nd.appendChild(doc.createTextNode('\n' + '\n'
            .join(map(str, dims_y)) + '\n'))
        subgeo.appendChildren([angle, ring, gaptype, gapwidth,
            lines1st, lines2nd])
        submat = doc.createElement('SubMat')
        submat.setAttrs({'ID': str(self.id), 'SubID': str(self.id)})
        matids = doc.createElement('MatIDs')
        str_matids = ''
        for mat in mats:
            if mat is None:
                str_matids += str(const.ModeratorID) + ' '
            else:
                str_matids += str(matid_map[mat.id]) + ' '
        matid_list = [str_matids] * len(dims_y)
        str_matids = '\n' + '\n'.join(matid_list) + '\n'
        matids.appendChild(doc.createTextNode(str_matids))
        submat.appendChild(matids)
        return subgeo, submat

    def __eq__(self, other):
        return self.dimensions == other.dimensions and \
                self.mats == other.mats and \
                self.width == other.width

    def __repr__(self):
        return "Box({!r}, {!r})".format(self.dimensions, self.mats) \
                if self.is_square() else \
                "Box({!r}, {!r}, {!r})".format(self.dimensions, self.mats,
                        self.width)
