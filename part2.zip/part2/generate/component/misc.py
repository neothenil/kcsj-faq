import xml.dom.minidom as dom
from collections import namedtuple

from .. import const


class Segment:

    def __init__(self, height, lattice, abs_height=0.0):
        self.height = height
        self.lattice = lattice
        self.abs_height = abs_height

    def __repr__(self):
        return 'Segment({!r}, {!r}, {!r})'.format(
                self.height, self.lattice, self.abs_height)


class Cluster:
    def __init__(self, id, positions, base, step, offset, abs_base=0.0):
        self.id = id
        self.positions = positions
        self.base = base
        self.step = step
        self.offset = offset
        self.abs_base = abs_base


# Monkey patch for minidom

def setAttrs(element, attr_dict):
    for name, value in attr_dict.items():
        element.setAttribute(name, value)


def appendChildren(element, child_list):
    for child in child_list:
        element.appendChild(child)


dom.Element.setAttrs = setAttrs
dom.Element.appendChildren = appendChildren


def element_to_node(element, doc):
    attrs = element.attrib
    text = element.text
    tag = element.tag
    node = doc.createElement(tag)
    if text and not const.empty_text.match(text):
        node.appendChild(doc.createTextNode(text))
    node.setAttrs(attrs)
    for subele in element:
        subnode = element_to_node(subele, doc)
        node.appendChild(subnode)
    return node


Material = namedtuple('Material', ['id', 'nu_density'])
Material.__repr__ = lambda x: 'Material({!r})'.format(x.id)
