import math

from .. import const
from .. import mesh_method
from ..errors import ModFileError


def new_mass_dict(file_location):
    with open(file_location) as f:
        data_lines = f.readlines()
    mass_dict = {}
    for line in data_lines:
        data_pairs = line.split()
        mass_dict[data_pairs[0]] = round(float(
            data_pairs[1]), const.precision)
    return mass_dict


mass_dict = new_mass_dict(const.mass_data_file)


class Pin:

    def __init__(self, id, radii, mats, pin_type):
        self.id = int(id)  # Raise error if `id` is not integer.
        self.radii = radii
        self.mats = mats
        self.pin_type = pin_type
        # Default attribute values.
        self.boundaries = []
        # Set after lattice has been combined.
        self.location = [False] * 9
        self.pin_size = 0.0

    def __repr__(self):
        return 'Pin({})'.format(repr(self.id))

    def __eq__(self, other):
        if not isinstance(other, Pin):
            return False
        return self.pin_type == other.pin_type and \
            self.radii == other.radii and \
            self.mats == other.mats

    def __hash__(self):
        """Error-prone hash method."""
        return hash(id(self))

    def copy(self):
        radii = [i for i in self.radii]
        mats = [i for i in self.mats]
        boundaries = [i for i in self.boundaries]
        location = [i for i in self.location]
        new_pin = Pin(self.id, radii, mats, self.pin_type)
        new_pin.boundaries = boundaries
        new_pin.location = location
        new_pin.pin_size = self.pin_size
        return new_pin

    def combine(self, other_pin, new_id):
        if other_pin is None:
            return self
        if self.mats[0] is not None:
            raise ModFileError('{} can\'t combine with other pin.'.format(
                self))
        if max(other_pin.radii) > self.radii[0]:
            raise ModFileError('{} is too large for {}'.format(
                other_pin, self))
        # Make sure other_pin not be changed.
        other_pin = other_pin.copy()
        if max(other_pin.radii) < self.radii[0]:
            other_pin.radii.append(self.radii[0])
            other_pin.mats.append(None)
        result_pin = self.copy()
        result_pin.id = int(new_id)
        boundary_radius = result_pin.radii.pop(0)
        result_pin.mats.pop(0)
        result_pin.radii = other_pin.radii + result_pin.radii
        result_pin.mats = other_pin.mats + result_pin.mats
        result_pin.boundaries.append(boundary_radius)
        return result_pin

    def to_subs(self, settings, gap_width, matid_map,
            mesh_num_max, mesh_num_min, doc):
        radii, mats = mesh_method.simple_mesh(self, mesh_num_max, mesh_num_min)
        if self.boundaries:
            ring1st = settings.get_crba_ring1st()
            if ring1st < 0:
                ring1st = len(radii) + ring1st + 1
        else:
            ring1st = settings.get_ring1st()
            if ring1st < 0:
                ring1st = len(radii) + ring1st + 1
        subgeos = []
        submats = []
        if self.location[const.IN]:
            subgeo = doc.createElement('SubGeo')
            subgeo.setAttrs({'ID': str(self.id), 'SubType': '1',
                'HalfWidth': str(self.pin_size / 2),
                'NumLines1st': str(len(radii)),
                'NumLines2nd': '8'})
            angle = doc.createElement('Angle1st')
            angle.appendChild(doc.createTextNode('0'))
            ring = doc.createElement('Ring1st')
            ring.appendChild(doc.createTextNode(str(ring1st)))
            gaptype = doc.createElement('GapType')
            gaptype.appendChild(doc.createTextNode('0'))
            gapwidth = doc.createElement('GapWidth')
            gapwidth.appendChild(doc.createTextNode(str('0.0')))
            lines1st = doc.createElement('Lines1st')
            lines1st.appendChild(doc.createTextNode('\n' + '\n'
                .join(map(str, radii)) + '\n'))
            lines2nd = doc.createElement('Lines2nd')
            subgeo.appendChildren([angle, ring, gaptype, gapwidth, lines1st,
                lines2nd])
            subgeos.append(subgeo)
            # submat
            submat = doc.createElement('SubMat')
            submat.setAttrs({'ID': str(self.id), 'SubID': str(self.id)})
            matids = doc.createElement('MatIDs')
            str_matids = '\n'
            for mat in mats:
                if mat is None:
                    str_matids += str(const.ModeratorID) + '\n'
                else:
                    str_matids += str(matid_map[mat.id]) + '\n'
            str_matids += str(const.ModeratorID) + '\n'
            matids.appendChild(doc.createTextNode(str_matids))
            submat.appendChild(matids)
            submats.append(submat)
        if gap_width > 0.0:
            if self.location[const.BL]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.BL),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('1'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.LL]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.LL),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('2'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.UL]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.UL),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('3'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.RL]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.RL),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('4'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.RB]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.RB),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('14'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.LB]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.LB),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('21'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.LU]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.LU),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('32'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
            if self.location[const.RU]:
                subgeo = doc.createElement('SubGeo')
                subgeo.setAttrs({'ID': str(self.id+10000*const.RU),
                    'SubType': '1',
                    'HalfWidth': str(self.pin_size / 2),
                    'NumLines1st': str(len(radii)),
                    'NumLines2nd': '8'})
                angle = doc.createElement('Angle1st')
                angle.appendChild(doc.createTextNode('0'))
                ring = doc.createElement('Ring1st')
                ring.appendChild(doc.createTextNode(str(ring1st)))
                gaptype = doc.createElement('GapType')
                gaptype.appendChild(doc.createTextNode('43'))
                gapwidth = doc.createElement('GapWidth')
                gapwidth.appendChild(doc.createTextNode(str(gap_width)))
                lines1st = doc.createElement('Lines1st')
                lines1st.appendChild(doc.createTextNode('\n' + '\n'
                    .join(map(str, radii)) + '\n'))
                lines2nd = doc.createElement('Lines2nd')
                subgeo.appendChildren([angle, ring, gaptype, gapwidth,
                    lines1st, lines2nd])
                subgeos.append(subgeo)
                # submat
                submat = doc.createElement('SubMat')
                submat.setAttrs({'ID': subgeo.getAttribute('ID'),
                    'SubID': subgeo.getAttribute('ID')})
                matids = doc.createElement('MatIDs')
                str_matids = '\n'
                for mat in mats:
                    if mat is None:
                        str_matids += str(const.ModeratorID) + '\n'
                    else:
                        str_matids += str(matid_map[mat.id]) + '\n'
                str_matids += '255\n'
                matids.appendChild(doc.createTextNode(str_matids))
                submat.appendChild(matids)
                submats.append(submat)
        assert len(subgeos) == len(submats)
        return subgeos, submats

    def calc_mass(self):
        """
        Calculate uranium mass in unit axial length. Unit: g/cm.
        """
        if hasattr(self, 'mass'):
            return self.mass
        mass = 0.0
        for radius, mat in zip(self.radii, self.mats):
            if mat is None:
                continue
            for alias, density in mat.nu_density.items():
                match_obj = const.uranium.match(alias)
                if match_obj is not None:
                    M = mass_dict[alias.upper()]
                    previous_radius_index = self.radii.index(radius) - 1
                    if previous_radius_index < 0:
                        previous_radius = 0.0
                    else:
                        previous_radius = self.radii[previous_radius_index]
                    area = math.pi*(radius**2-previous_radius**2)
                    mass += density*area*M/const.NA
        self.mass = mass
        return mass
