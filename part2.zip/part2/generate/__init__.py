from .main import main as handle_generate
