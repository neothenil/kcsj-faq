"""
File: __init__.py
Author: Neophyliam
Email: 727549953@qq.com
Github: https://github.com/Neophyliam
"""

import sys


def error(message):
    sys.exit("[Error] " + message)
