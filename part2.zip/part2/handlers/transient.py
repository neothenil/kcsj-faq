"""
File: transient.py
Author: Neophyliam
Email: 727549953@qq.com
Github: https://github.com/Neophyliam
"""

import re
import os
import shutil
import argparse
import subprocess

from config import (
        trans_cache_path,
        trans_inputs_path,
        trans_inputs,
        trans_executable,
        trans_path,
        trans_outputs_path,
        trans_outputs,
        core_outputs_path)
from handlers import error

cycle_num_pattern = re.compile(r"CYCLE(\d+)")


def copy_lilac():
    """Copy `LILAC' directory from `core_outputs_path' to `trans_cache_path'.

    Raise `FileNotFoundError' if the `LILAC' directory does not exist. If this
    directory is already in `trans_cache_path', remove it first.
    """
    lilac_target_path = os.path.join(trans_cache_path, "LILAC")
    if os.path.exists(lilac_target_path) and os.path.isdir(lilac_target_path):
        shutil.rmtree(lilac_target_path)
    lilac_src_path = os.path.join(core_outputs_path, "LILAC")
    shutil.copytree(lilac_src_path, lilac_target_path)


def copy_from_cycle(cycle_num):
    """Copy `KININFO' and `main.bt' from a cycle directory in
    `core_outputs_path'.

    Raise AssertionError if a cycle directory with `cycle_num' does not exist.

    Raise `FileNotFoundError' if "main.bt" file or "KININFO" directory does not
    exist in the cycle directory. If "KININFO" directory is already in
    `trans_cache_path', remove it first.

    Raise `FileNotFoundError' if `core_outputs_path' does not exist.
    """
    all_cycle_dirs = os.listdir(core_outputs_path)
    cycle_dir = None
    for cd in all_cycle_dirs:
        match = cycle_num_pattern.search(cd)
        if match:
            this_cycle_num = int(match.group(1))
            if this_cycle_num == cycle_num:
                cycle_dir = cd
                break
    assert cycle_dir is not None,\
        "'CYCLE{}' directory does not exist in '{}'.".format(cycle_num,
                core_outputs_path)
    cycle_dir = os.path.join(core_outputs_path, cycle_dir)
    shutil.copy(os.path.join(cycle_dir, "main.bt"), trans_cache_path)
    kin_target_path = os.path.join(trans_cache_path, "KININFO")
    if os.path.exists(kin_target_path) and os.path.isdir(kin_target_path):
        shutil.rmtree(kin_target_path)
    shutil.copytree(os.path.join(cycle_dir, "KININFO"), kin_target_path)


def copy_user_inputs():
    """Copy inputs supplied by user.
    """
    dir_inputs = trans_inputs.get("dirs")
    file_inputs = trans_inputs.get("files")
    if dir_inputs:
        for dir_name in dir_inputs:
            dir_src_path = os.path.join(trans_inputs_path, dir_name)
            dir_target_path = os.path.join(trans_cache_path, dir_name)
            if os.path.exists(dir_target_path) and \
               os.path.isdir(dir_target_path):
                shutil.rmtree(dir_target_path)
            if os.path.exists(dir_src_path) and \
                    not os.path.exists(trans_cache_path):
                os.makedirs(trans_cache_path, exist_ok=True)
            shutil.copytree(dir_src_path, dir_target_path)
    if file_inputs:
        for file_name in file_inputs:
            file_src_path = os.path.join(trans_inputs_path, file_name)
            if os.path.exists(file_src_path) and \
                    not os.path.exists(trans_cache_path):
                os.makedirs(trans_cache_path, exist_ok=True)
            shutil.copy(file_src_path, trans_cache_path)


def execute():
    """Execute Bamboo-Transient."""
    command = os.path.join(trans_path, trans_executable)
    command = os.path.abspath(command)
    subprocess.run([command], cwd=trans_cache_path, check=True)


def save_results():
    """Save results produced by Bamboo-Transient."""
    dir_outputs = trans_outputs.get("dirs")
    file_outputs = trans_outputs.get("files")
    os.makedirs(trans_outputs_path, exist_ok=True)
    # This `if' clause could be deleted. Leave it here just to make the future
    # easier if one day Bamboo-Transient produces one or more directories to be
    # saved.
    if dir_outputs:
        pass
    if file_outputs:
        for file_name in file_outputs:
            file_src_path = os.path.join(trans_cache_path, file_name)
            shutil.copy(file_src_path, trans_outputs_path)


def run(cycle_num):
    copy_user_inputs()
    copy_lilac()
    copy_from_cycle(cycle_num)
    execute()
    save_results()


def main(args):
    parser = argparse.ArgumentParser(prog="bamboo transient",
            description="Handle Bamboo-Transient.")
    parser.add_argument("cycle", type=int, default=1, nargs="?",
            help="Execute Bamboo-Transient from results of `cycle'"
            " (default=1)")
    args = parser.parse_args(args)
    try:
        run(args.cycle)
    except (AssertionError,
            FileNotFoundError,
            subprocess.CalledProcessError) as e:
        error(str(e))


handle_trans = main


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
