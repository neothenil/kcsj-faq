"""
File: core.py
Author: Neophyliam
Email: 727549953@qq.com
Github: https://github.com/Neophyliam
"""

import os
import re
import time
import shutil
import argparse
import warnings
import subprocess

from config import (
        core_cache_path,
        core_inputs_path,
        core_cr_inputs,
        core_optional_inputs,
        core_path,
        core_executable,
        core_outputs_path,
        core_outputs,
        core_optional_outputs,
        readb_outputs_path)
from handlers import error


class CoreHandlerError(Exception):
    pass


cycle_number_pattern = re.compile(r'CORE-CYCLE(\d+)\.XML')


def check_cycles(cycles):
    if not cycles:
        return
    minimal_cycle_number = cycles[0].number
    i = 0
    for cycle in cycles:
        if cycle.number != minimal_cycle_number + i:
            warnings.warn('Provided cycles not sequential')
            time.sleep(3)
            break
        i += 1


def copy_flab_if_necessary(cycles):
    if not cycles:
        return
    minimal_cycle_number = cycles[0].number
    if minimal_cycle_number == 1:
        return
    last_cycle_output_path = os.path.join(core_outputs_path,
            "CYCLE%d" % (minimal_cycle_number-1))
    if not os.path.exists(last_cycle_output_path):
        warnings.warn('Can not find FLAB.DAT of CYCLE%d. '
                      'Use FLAB.DAT in cache directly'
                      % (minimal_cycle_number-1))
        time.sleep(3)
        return
    dir_entries = os.scandir(last_cycle_output_path)
    for dir_entry in dir_entries:
        if dir_entry.name == 'FLAB.DAT':
            break
    else:
        warnings.warn('Can not find FLAB.DAT of CYCLE%d. '
                      'Use FLAB.DAT in cache directly'
                      % (minimal_cycle_number-1))
        time.sleep(3)
        return
    shutil.copy(dir_entry.path, core_cache_path)


def copy_opt_inputs():
    for file_name in os.listdir(core_inputs_path):
        if file_name in core_optional_inputs:
            file_path = os.path.join(core_inputs_path, file_name)
            shutil.copy(file_path, core_cache_path)


def copy_from_readb():
    """Copy results of ReadBLattice for the use of Core program.

    Executed only in the first cycle.
    """
    core_path_files = os.listdir(core_cache_path)
    lilac_path = os.path.join(core_cache_path, "LILAC")
    if "LILAC" not in core_path_files:
        shutil.copytree(readb_outputs_path, lilac_path)


def copy_cr_inputs():
    """Handle input files whose names start with "CR".

    Executed only in the first cycle.
    """
    cr_inputs = core_cr_inputs
    for cr in cr_inputs:
        cr_dir = cr.split('_')[1]
        dir_path = os.path.join(core_cache_path, "LILAC", cr_dir)
        os.makedirs(dir_path, exist_ok=True)
        cr_src = os.path.join(core_inputs_path, cr)
        cr_dst = os.path.join(dir_path, "CR")
        shutil.copy(cr_src, cr_dst)


def save_dat_outputs(path):
    dat_outputs = []
    for file_name in core_outputs:
        if file_name.endswith("DAT"):
            dat_outputs.append(file_name)
    for file_name in os.listdir(core_cache_path):
        if file_name in core_optional_outputs:
            dat_outputs.append(file_name)

    for output_file in dat_outputs:
        output_file_path = os.path.join(core_cache_path, output_file)
        if output_file in os.listdir(path):
            os.remove(os.path.join(path, output_file))
        shutil.copy(output_file_path, path)


def save_dir_outputs(path):
    files = os.scandir(core_cache_path)
    for file in files:
        if file.is_dir() and file.name in core_outputs:
            output_path = os.path.join(path, file.name)
            if file.name in os.listdir(path):
                shutil.rmtree(output_path)
            shutil.copytree(file.path, output_path)


def save_lilac():
    if "LILAC" in os.listdir(core_outputs_path):
        shutil.rmtree(os.path.join(core_outputs_path, "LILAC"))
    shutil.copytree(os.path.join(core_cache_path, "LILAC"),
                    os.path.join(core_outputs_path, "LILAC"))


class Cycle:
    def __init__(self, dir_entry, number):
        self.dir_entry = dir_entry
        self.number = number

    def prepare(self):
        copy_opt_inputs()
        copy_from_readb()
        copy_cr_inputs()
        shutil.copy(self.dir_entry.path,
                    os.path.join(core_cache_path, "CORE.XML"))

    def execute(self):
        command = os.path.join(core_path, core_executable)
        command = os.path.abspath(command)
        subprocess.run([command], cwd=core_cache_path, check=True)

    def save(self):
        path = os.path.join(core_outputs_path, "CYCLE%d" % self.number)
        os.makedirs(path, exist_ok=True)
        save_dat_outputs(path)
        save_dir_outputs(path)


def find_cycles():
    result = []
    inputs = os.scandir(core_inputs_path)
    for dir_entry in inputs:
        if dir_entry.name == "CORE.XML":
            result.append(Cycle(dir_entry, 1))
            assert len(result) == 1, "Naming conflict."
            return result
        match = cycle_number_pattern.search(dir_entry.name)
        if match:
            cycle_number = int(match.group(1))
            result.append(Cycle(dir_entry, cycle_number))
    return result


def sort_cycles(cycles):
    def sort_func(cycle):
        return cycle.number

    cycles.sort(key=sort_func)


def execute(cycles, clean=False, update=False):
    all_cycles = find_cycles()
    assert len(all_cycles) != 0,\
        "Input files not sufficient. Or the files are not named correctly."
    cycles_to_exe = []
    if cycles:
        for num in cycles:
            for cycle in all_cycles:
                if cycle.number == num:
                    cycles_to_exe.append(cycle)
                    break
            else:
                raise CoreHandlerError('can not find cycle with '
                        'number {}'.format(num))
    else:
        cycles_to_exe = all_cycles
    sort_cycles(cycles_to_exe)
    os.makedirs(core_cache_path, exist_ok=True)
    lilac_path = os.path.join(core_cache_path, "LILAC")
    if update and os.path.exists(lilac_path):
        shutil.rmtree(lilac_path)
    check_cycles(cycles_to_exe)
    copy_flab_if_necessary(cycles_to_exe)
    for cycle in cycles_to_exe:
        cycle.prepare()
        cycle.execute()
        cycle.save()
    save_lilac()

    if clean and os.path.exists(core_cache_path):
        shutil.rmtree(core_cache_path)


def main(args):
    parser = argparse.ArgumentParser(prog="bamboo core",
            description="Handle Bamboo-Core with "
            "one or more cycles.")
    parser.add_argument("-c", "--clean", action="store_true",
            help="clean cache directory after all execution")
    parser.add_argument("cycles", type=int, nargs="*", metavar='cycle',
            help="execute Bamboo-Core for particular cycles")
    parser.add_argument("-u", "--update", action="store_true",
            help="update library provided by Bamboo-Lattice and ReadBLattice")
    args = parser.parse_args(args)
    try:
        execute(cycles=args.cycles, clean=args.clean, update=args.update)
    except (AssertionError,
            FileNotFoundError,
            subprocess.CalledProcessError,
            CoreHandlerError) as e:
        error(str(e))


handle_core = main


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
