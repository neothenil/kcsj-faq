"""
File: readb.py
Author: Neophyliam
Email: 727549953@qq.com
Github: https://github.com/Neophyliam
"""

import os
import shutil
import argparse
import subprocess

from handlers import error
from handlers import lattice
from config import (
        files_to_cat,
        readb_path,
        readb_executable,
        readb_input,
        readb_cache_path,
        readb_outputs_path,
        lattice_outputs_path)


def cat(files, target):
    """Concatenate files to target."""

    with open(target, 'w') as f_target:
        for file in files:
            with open(file, 'r') as f:
                f_target.write(f.read())


def classify(target_dir):
    """Classify files in target_dir according to global variable files_to_cat.
    """

    def is_main(file):
        return file.name.split('.')[0].endswith("main")

    def get_number(file):
        match = lattice.branch_number_pattern.search(file.name)
        assert match, \
            "Can't find branch number in name of file {}".format(file.path)
        return int(match.group(1))

    def file_to_number(file):
        if is_main(file):
            return 0
        else:
            return get_number(file)

    def file_type(file):
        return file.name.split('.')[-1]

    file_type_dict = {}
    files = list(os.scandir(target_dir))
    for file in files:
        ft = file_type(file)
        if ft in files_to_cat:
            file_type_dict.setdefault(ft, []).append(file)

    for _, files in file_type_dict.items():
        files.sort(key=file_to_number)
    return file_type_dict


def prepare():
    """Handle results of Lattice. Prepare files for ReadBLattice."""

    lattice_codes = os.listdir(lattice_outputs_path)
    os.makedirs(readb_cache_path, exist_ok=True)
    if not lattice_codes:
        raise FileNotFoundError("No lattice result found in {}".format(
            lattice_outputs_path))
    for code in lattice_codes:
        target_dir = os.path.join(lattice_outputs_path, code)
        ft_dict = classify(target_dir)
        for file_type, files in ft_dict.items():
            target_name = "{}.{}".format(code, file_type)
            target_path = os.path.join(readb_cache_path, target_name)
            file_paths = [file.path for file in files]
            cat(file_paths, target_path)


def copy_input():
    return shutil.copy(readb_input, readb_cache_path)


def execute_readb():
    command = os.path.join(readb_path, readb_executable)
    command = os.path.abspath(command)
    subprocess.run([command], cwd=readb_cache_path, check=True)


def save_results():
    ft_dict = {"CX": "XS", "CK": "KIN", "CF": "FORM"}
    dirs = ft_dict.values()
    for dir in dirs:
        dir_path = os.path.join(readb_outputs_path, dir)
        os.makedirs(dir_path, exist_ok=True)
    for file in os.scandir(readb_cache_path):
        ft = file.name[:2]
        if ft in ft_dict:
            target_dir = ft_dict[ft]
            target_path = os.path.join(readb_outputs_path, target_dir)
            shutil.copy(file.path, target_path)


def run():
    prepare()
    copy_input()
    execute_readb()
    save_results()


def main(args):
    parser = argparse.ArgumentParser(prog="bamboo readb",
            description="Handle ReadBLattice.")
    args = parser.parse_args(args)
    try:
        run()
    except (FileNotFoundError,
            subprocess.CalledProcessError) as e:
        error(str(e))


handle_readb = main


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
