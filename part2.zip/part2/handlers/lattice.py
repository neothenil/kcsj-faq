"""
File: lattice.py
Author: Neophyliam
Email: 727549953@qq.com
Github: https://github.com/Neophyliam
"""

import os
import re
import shutil
import argparse
import subprocess
from concurrent.futures import as_completed
from concurrent.futures import ThreadPoolExecutor as tpe

from config import (
        lattice_cache_path,
        lattice_inputs_path,
        lattice_path,
        lattice_executable,
        lattice_outputs_path,
        lattice_results)
from handlers import error

cpu_count = os.cpu_count()
branch_number_pattern = re.compile(r"branch(\d+)")


class ExecutionError(Exception):
    msg_form = """

    Ran {} {} branch{}. {} succeeded. {} failed.

    Error message:\n"""

    def __init__(self, msg, type):
        """Initialize with a message and a type. Arg `type` is either "main"
        or "other".
        """
        self.msg = msg
        self.type = type

    def __str__(self):
        return "Exception raised during executing %s branch." % self.type


class ExecMixin:
    """Methods can be shared by `Main' and `Branch'."""

    def make_cache(self):
        os.makedirs(self.cache_path, exist_ok=True)
        shutil.copy(self.path, os.path.join(self.cache_path, "input.xml"))

    def execute(self):
        """Execute Bamboo-Lattice with given input file.

        This time we don't need --input option, so it's not necessary to use
        `shlex.split' to split the command.

        This will invoke Bamboo-Lattice from
        {lattice_path}/{lattice_executable} with `self.cache_path' as its cwd.

        Refactor from `execute_main' on 2018-03-23.
        """
        command = os.path.abspath(os.path.join(lattice_path,
                                               lattice_executable))
        subprocess.run([command], cwd=self.cache_path, check=True)

    def save_results(self):
        """Rename files in `lattice_results' and save them at
        `self.result_path'.

        Refactor from `save_results' on 2018-03-23.
        """
        os.makedirs(self.result_path, exist_ok=True)
        for result in lattice_results:
            suffix = result.split('.')[-1]
            branch_name = os.path.basename(self.cache_path)
            new_name = "{}-{}.{}".format(self.code, branch_name, suffix)
            result_path = os.path.join(self.cache_path, new_name)
            if os.path.exists(result_path):
                os.remove(result_path)
            os.rename(os.path.join(self.cache_path, result), result_path)
            shutil.copy2(result_path, self.result_path)


class Main(ExecMixin):
    """Executor of main branch.

    Instantiate with a string `code' and Dir_entry instance `dir_entry'.

    Calling the `run' method will do the following stuffs:
    1) Make cache directory (Put input file in it);
    2) Execute Bamboo-Lattice;
    3) Rename and save the results contained in `lattice_results'.

    This class also has a `clean' method to clean the cache optionally.
    """

    def __init__(self, code, dir_entry):
        self.code = code
        self.dir_entry = dir_entry
        self.name = dir_entry.name  # As a convenient attribute.
        self.path = dir_entry.path  # As a convenient attribute.
        self.cache_path = os.path.join(lattice_cache_path, code, "main")
        self.result_path = os.path.join(lattice_outputs_path, code)

    def run(self):
        """Invoke `make_cache', `execute' and `save_results' methods."""
        self.make_cache()
        self.execute()
        self.save_results()

    def clean(self):
        """Clean cache path of the assembly.

        This method is intended to be invoked optionally after all the other
        branches have executed successfully. Do not use it in other situation.
        """
        cache_dir = os.path.dirname(self.cache_path)
        if not os.path.exists(cache_dir):
            return
        shutil.rmtree(cache_dir)

    def make_cache(self):
        """Make cache directory for the main branch.

        The cache will be created at {lattice_cache_path}/{self.code}/main.
        This directory will contain an input file named 'input.xml', and a lib
        directory which has database files in it optionally. Users still can
        use relative path in their input files, but are restricted if they also
        want to use functionality provided by this module. The relative path
        they can use must start with './lib' or './LIB' or any combination of
        lower and upper case character of 'lib'. They also have to provide this
        lib direcotry in `lattice_path'. And if they do, it implies they will
        use this relative path in their input files.

        If the cache directory has already contained a lib directory, this
        method will skip the step of copying lib directory.

        Because this time cache directory will be smaller than before, if the
        user want to execute the main branch again after a successful
        execution, files in this cache directory will be recreated (except the
        lib direcotry).

        Refactor from `make_one_main_cache' on 2018-03-22.
        """
        super().make_cache()
        # Copy lib directory optionnaly. If want to force users to use absolute
        # path, delete below code.
        files_in_bin = os.listdir(lattice_path)
        for file_name in files_in_bin:
            if file_name.upper() == "LIB":
                if file_name not in os.listdir(self.cache_path):
                    shutil.copytree(os.path.join(lattice_path, file_name),
                            os.path.join(self.cache_path, file_name))
                    return


class Branch(ExecMixin):
    """Executor of other branch.

    Instantiate with a string `code', a string `number' and Dir_entry instance
    `dir_entry'.

    Calling the `run' method will do the following stuffs:
    1) Make cache directory (Put input file in it);
    2) Execute Bamboo-Lattice;
    3) Rename and save the results contained in `lattice_results';
    4) Clean the cache directory.
    """

    def __init__(self, code, number, dir_entry):
        self.code = code
        self.number = number
        self.dir_entry = dir_entry
        self.name = dir_entry.name  # As a convenient attribute.
        self.path = dir_entry.path  # As a convenient attribute.
        self.main_cache_path = os.path.join(lattice_cache_path, code, "main")
        self.cache_path = os.path.join(lattice_cache_path, code,
                                       "branch%s" % number)
        self.result_path = os.path.join(lattice_outputs_path, code)

    def run(self):
        """Invoke `make_cache', `execute', `save_results', and `clean' methods
        for this branch.
        """
        self.make_cache()
        self.execute()
        self.save_results()
        self.clean()

    def make_cache(self):
        """Make cache directory for the branch.

        If this is the first time to execute this branch, just copy from
        `self.main_cache_path' and prepare the input file. If it is not the
        first time to execute this branch, and last execution was successful,
        do the same thing as above. If the last execution failed, update this
        cache from `self.main_cache_path'. In summary, recreate cache directory
        at every execution.

        Refactor from `make_one_branch_cache' on 2018-03-23.
        """
        assert os.path.exists(self.main_cache_path),\
            "The main branch has not executed before."
        if os.path.exists(self.cache_path):
            shutil.rmtree(self.cache_path)
        shutil.copytree(self.main_cache_path, self.cache_path)
        super().make_cache()

    def clean(self):
        """Clean the branch cache after a successful execution."""
        if os.path.exists(self.cache_path):
            shutil.rmtree(self.cache_path)


def find_main_branch(files):
    """Find main and branches among files. `files' is a list of instances of
    Dir_entry.

    Return an instance of `Main' and a list of instances of `Branch'.

    To make this function work correctly, the main branch must be named after
    "{code}-main.xml", and the branches must be named after
    "{code}-branch{number}.xml".  {code} is a string that represents the
    assembly. {number} is a integer number to separate a particular branch with
    other branches.

    Refactor from `find_main_branch' on 2018-03-21.
    """
    main_list = []
    branch_list = []
    for file in files:
        if file.name.split('.')[0].endswith("main"):
            code = file.name.split('-')[0]
            main = Main(code, file)
            main_list.append(main)
        if "branch" in file.name:
            code = file.name.split('-')[0]
            number_match = branch_number_pattern.search(file.name)
            assert number_match, \
                "Can't find branch number in name of file {}".format(file.path)
            number = number_match.group(1)
            branch = Branch(code, number, file)
            branch_list.append(branch)

    # Test 1: One main in one directory.
    dir_path = os.path.dirname(file.path)
    assert len(main_list) == 1, "Expect 1 main branch in {}. Found {}.".format(
            dir_path, len(main_list))

    # Test 2: All branches have the same code as main.
    main = main_list[0]
    for branch in branch_list:
        assert branch.code == main.code,\
            "More than one type of assembly found in {}".format(dir_path)

    # Test 3: Directory name must match the assembly code.
    dir_name = os.path.basename(dir_path)
    assert main.code == dir_name,\
        "Directory name {} doesn't match assembly code".format(dir_name)
    return main, branch_list


def find_inputs():
    """Find all `Main' and `Branch' instances from `lattice_inputs_path'.
    Return a list of `Main' instances and a list of `Branch' instances.

    All files in `lattice_inputs_path' must be directories.

    Refactor from `get_lattice' on 2018-03-21.
    """
    abs_inputs_path = os.path.abspath(lattice_inputs_path)
    dirs = os.listdir(abs_inputs_path)
    assert len(dirs) > 0, "No directory in {}".format(lattice_inputs_path)
    main_list, branch_list = [], []
    for dir_name in dirs:
        dir_path = os.path.join(abs_inputs_path, dir_name)
        files = list(os.scandir(dir_path))
        # Test: `files` not empty.
        if len(files) == 0:
            error("Empty directory `{}` found.".format(dir_name))
        main, branches = find_main_branch(files)
        main_list.append(main)
        branch_list += branches
    return main_list, branch_list


def execute(lattices, branches, jobs=cpu_count, clean=False):
    """Execute Bamboo-Lattice according to arguments.

    `lattices' must be an Iterator of str object. Each string represents the
    corresponding assembly code.

    `branches' must be an Iterator of str object. Each string represents the
    corresponding branch number.

    Note: If a non-existing assembly code or branch number was in `lattices' or
    `branches', this function would just ignore it.

    `jobs' must be assigned with an int object.

    `clean' should be True or False.

    Refactor from `execute_main_conc', `execute_one_lattice_branches' and
    `run_main' on 2018-03-23.
    """
    main_list, branch_list = find_inputs()
    if lattices:
        main_list = [main_ins for main_ins in main_list
                if main_ins.code in lattices]
        branch_list = [branch_ins for branch_ins in branch_list
                if branch_ins.code in lattices]
    if branches:
        if '0' not in branches:
            main_list = []
        branch_list = [branch_ins for branch_ins in branch_list
                if branch_ins.number in branches]

    # Execute main inputs first.
    worker_num = min(len(main_list), jobs, cpu_count)
    if worker_num > 0:
        failed = []
        with tpe(max_workers=worker_num) as executor:
            future_to_main = {executor.submit(Main.run, main): main
                    for main in main_list}
            for future in as_completed(future_to_main):
                main_code = future_to_main[future].code
                try:
                    future.result()
                except Exception as e:
                    failed.append((main_code, str(e)))
        if failed:
            msg = ExecutionError.msg_form.format(len(main_list), "main",
                    len(main_list) != 1 and "es" or "",
                    len(main_list)-len(failed), len(failed))
            for code, err in failed:
                msg += "    {}: {}\n".format(code, err)
            raise ExecutionError(msg, "main")

    # Then execute the other branches.
    worker_num = min(len(branch_list), jobs, cpu_count)
    if worker_num > 0:
        failed = []
        with tpe(max_workers=worker_num) as executor:
            future_to_branch = {executor.submit(Branch.run, branch): branch
                    for branch in branch_list}
            for future in as_completed(future_to_branch):
                branch = future_to_branch[future]
                try:
                    future.result()
                except Exception as e:
                    failed.append((branch, str(e)))
        if failed:
            msg = ExecutionError.msg_form.format(len(branch_list), "other",
                    len(branch_list) != 1 and "es" or "",
                    len(branch_list)-len(failed), len(failed))
            for branch, err in failed:
                msg += "    {}-branch{}: {}\n".format(branch.code,
                        branch.number, err)
            raise ExecutionError(msg, "other")

    # Changed on 2018-03-29.
    # Clean whole cache directory optionally.
    if clean and os.path.exists(lattice_cache_path):
        shutil.rmtree(lattice_cache_path)


def main(args):
    """Refactor from `parse_args' on 2018-03-23."""

    parser = argparse.ArgumentParser(prog="bamboo lattice",
            description="Handle Bamboo-Lattice with "
            "lots of input files.")
    parser.add_argument("-l", "--lattice", nargs="+", default=[],
            metavar="code", help="only execute lattice with code")
    parser.add_argument("-b", "--branch", nargs="+", default=[],
            metavar="number", help="only execute branch whose number "
            "is mentioned in this argument (number 0 means main branch)")
    parser.add_argument("-j", "--jobs", type=int, default=cpu_count,
            metavar="x", help="number of parallel jobs (default to {})".format(
                cpu_count))
    parser.add_argument("-c", "--clean", action="store_true",
            help="clean cache directory after all execution")
    args = parser.parse_args(args)
    if args.jobs <= 0:
        error("--jobs/-j argument must be larger than 0")
    try:
        execute(args.lattice, args.branch, args.jobs, args.clean)
    except (AssertionError, FileNotFoundError) as e:
        error(str(e))
    except ExecutionError as e:
        print(e.msg)
        error(str(e))


handle_lattice = main


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
